from datetime import date
from typing import Literal

from pydantic import Field

from cev_ai_core.doc_types import CaregiverDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import Subject

CaregiverType = Literal["guardianship"]


class CareReceiver(Subject):
    """The person receiving care, distinct from the caregiver/member."""

    disability_description: str | None = Field(
        default=None,
        description=(
            "Disability of the person receiving care, only if explicitly described "
            "in the document. Preserve the stated description. Do not infer a "
            "disability from guardianship or generic form instructions. "
            "Use null if no disability is stated; null does not mean no disability."
        ),
    )


class CaregiverDocumentDates(CamelCaseModel):
    start_date: date | None = Field(
        default=None,
        description="The date the document was issued, signed, or granted (e.g. the clerk's signature date on a guardianship letter). Use this as the effective start date.",
    )
    end_date: date | None = Field(
        default=None,
        description="End date or expiration date if stated in the document (YYYY-MM-DD)",
    )


class CaregiverExtractionOutputType(BaseExtractionSchema):
    """Documents supporting a caregiver exemption from community engagement requirements, including court-issued letters of guardianship. The subject is the caregiver/member (the appointed guardian), while careReceiver is the person receiving care (the ward). Extract their identities separately. Only extract DOB, receiver age, and disability when explicitly stated; never infer them from guardianship or generic form wording. These documents do not by themselves establish age-based eligibility."""

    document_type: CaregiverDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )

    subject: Subject = Field(
        description=(
            "The caregiver/member providing care. For guardianship letters, "
            "extract the appointed guardian, not the ward, attorney, or court clerk. "
            "Only use this person's name and DOB for the member identity fields."
        ),
    )
    care_receiver: CareReceiver = Field(
        description=(
            "The person receiving care. For guardianship letters, extract the ward "
            "named under 'Guardianship of' or 'guardian of', not the guardian. "
            "Keep this person's name, DOB, stated age, and disability separate "
            "from the caregiver/member. Use null for each missing value."
        ),
    )
    document_dates: CaregiverDocumentDates
    type: CaregiverType | None = Field(
        default=None,
        description="The type of caregiver exemption claimed in the document",
    )
