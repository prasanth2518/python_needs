from datetime import date

from pydantic import Field

from cev_ai_core.camel_case_base import CamelCaseModel


class Subject(CamelCaseModel):
    extracted_name: str | None = Field(
        default=None,
        description=(
            "Name of the document subject as 'First Last' only. "
            "Always drop middle names, middle initials, suffixes, titles, and honorifics. "
            "Example: 'PATRICIA ANN TAYLOR' → 'Patricia Taylor', "
            "'John R. Smith Jr.' → 'John Smith'."
        ),
    )
    extracted_dob: date | None = Field(
        default=None,
        description="Date of birth of document subject in ISO format (YYYY-MM-DD)",
    )


class DocumentSource(CamelCaseModel):
    name: str | None = Field(
        default=None,
        description=(
            "Name of the organization that is the source of the activity — i.e. the employer, "
            "business, school, training agency, hospital, etc. For self-employment or tax forms, "
            "use the business name, not the government agency that issued the form."
        ),
    )


class DocumentDates(CamelCaseModel):
    start_date: date | None = Field(
        default=None,
        description="Start date of the activity period covered by the document (YYYY-MM-DD)",
    )
    end_date: date | None = Field(
        default=None,
        description="End date of the activity period covered by the document (YYYY-MM-DD)",
    )
