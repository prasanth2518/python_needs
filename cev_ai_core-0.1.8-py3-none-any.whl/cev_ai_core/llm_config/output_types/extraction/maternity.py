from datetime import date
from typing import Literal

from pydantic import Field

from cev_ai_core.doc_types import MaternityDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import Subject

MaternityType = Literal["pregnancy", "postpartum"]


class Provider(CamelCaseModel):
    name: str | None = Field(
        default=None,
        description="Name of the provider who authored or signed the document. Prefer the individual physician/clinician name (e.g. 'Jane A. Smith, MD') over the clinic or organization name. Only use the clinic/facility name if no individual provider is identified.",
    )
    address: str | None = Field(
        default=None,
        description="Address of the healthcare provider or facility. Include the facility/practice name as a prefix if present on the document.",
    )
    npi: str | None = Field(
        default=None,
        description="National Provider Identifier (NPI) of the healthcare provider",
    )


class SupportingCode(CamelCaseModel):
    code: str = Field(description="The diagnostic or procedure code (e.g. ICD-10 code)")
    code_type: str = Field(description="The coding system used (e.g. ICD10, CPT)")


class MaternityCondition(CamelCaseModel):
    type: MaternityType | None = Field(
        default=None,
        description="Whether this is a pregnancy (prenatal) or postpartum document",
    )
    effective_date: date | None = Field(
        default=None,
        description="Extract the effective date of this document if present",
    )
    delivery_date: date | None = Field(
        default=None,
        description="Actual date of delivery, if explicitly stated in the document. Found on postpartum discharge summaries and birth records. Only extract if the document explicitly provides this date.",
    )
    expected_delivery_date: date | None = Field(
        default=None,
        description="Expected delivery date (EDD/due date), if explicitly stated in the document. Found on prenatal records and pregnancy verification letters. Do not calculate or infer — only extract if the document explicitly provides this date.",
    )
    provider: Provider
    supporting_codes: list[SupportingCode] = Field(
        default_factory=list,
        description="Extract ALL diagnostic or procedure codes listed in the document (ICD-10, CPT, etc). Check Diagnoses sections, problem lists, discharge diagnoses, and assessment areas. If codes are present in the document, they must be included here.",
    )


class MaternityExtractionOutputType(BaseExtractionSchema):
    """Documents proving pregnancy or postpartum status. This includes prenatal clinical records documenting pregnancy care and postpartum discharge summaries."""

    document_type: MaternityDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    maternity_condition: MaternityCondition
