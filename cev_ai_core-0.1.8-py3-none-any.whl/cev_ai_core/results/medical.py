from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import MedicalDocType
from cev_ai_core.llm_config.output_types.extraction.medical import (
    HardshipType,
    MedicalExtractionOutputType,
)
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class MedicalClassificationResult(BaseClassificationResult[MedicalDocType]):
    type: HardshipType | None


class MedicalFinalResult(
    BaseFinalResult[MedicalExtractionOutputType, MedicalClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> MedicalClassificationResult:
        return MedicalClassificationResult(
            activity_type=Activity.MEDICAL,
            document_type=self.extraction.document_type,
            type=self.extraction.medical_condition.type,
        )
