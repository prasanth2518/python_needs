from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import CaregiverDocType
from cev_ai_core.llm_config.output_types.extraction.caregiver import (
    CaregiverExtractionOutputType,
)
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class CaregiverClassificationResult(BaseClassificationResult[CaregiverDocType]):
    pass


class CaregiverFinalResult(
    BaseFinalResult[CaregiverExtractionOutputType, CaregiverClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> CaregiverClassificationResult:
        return CaregiverClassificationResult(
            activity_type=Activity.CAREGIVER,
            document_type=self.extraction.document_type,
        )
