from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import MaternityDocType
from cev_ai_core.llm_config.output_types.extraction.maternity import (
    MaternityExtractionOutputType,
    MaternityType,
)
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class MaternityClassificationResult(BaseClassificationResult[MaternityDocType]):
    type: MaternityType | None


class MaternityFinalResult(
    BaseFinalResult[MaternityExtractionOutputType, MaternityClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> MaternityClassificationResult:
        return MaternityClassificationResult(
            activity_type=Activity.MATERNITY,
            document_type=self.extraction.document_type,
            type=self.extraction.maternity_condition.type,
        )
