from cev_ai_core.doc_types.base import BaseDocType


class MaternityDocType(BaseDocType):
    PRENATAL_RECORD = (
        "prenatal_record",
        "An antepartum or prenatal clinical record documenting pregnancy care, "
        "including visit logs, obstetric history, lab results, and estimated delivery date.",
    )
    POSTPARTUM_DISCHARGE = (
        "postpartum_discharge",
        "A hospital obstetric discharge summary documenting delivery details, "
        "maternal and newborn status at discharge, and postpartum follow-up instructions.",
    )
