from cev_ai_core.doc_types.base import BaseDocType


class CaregiverDocType(BaseDocType):
    LETTER_OF_GUARDIANSHIP = (
        "letter_of_guardianship",
        "A court-issued letter of guardianship (e.g. California GC-250) indicating "
        "appointing a guardian for a ward, submitted as evidence of caregiving. "
        "The subject (member identity) is the appointed guardian. Extract the "
        "ward separately as careReceiver. Do not infer the ward's age, DOB, "
        "disability, or eligibility from the form type.",
    )
