from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, cast

import typer
from loguru import logger
from rich.console import Console
from rich.table import Table
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

from case_creation_ai.configs import EXTRACTION_CONFIG
from case_creation_ai.models import ExtractionRecord
from case_creation_ai.pipeline import CaseCreationPipeline
from case_creation_ai.utils import (
    collect_documents,
    default_inputs,
    load_priority_map,
    load_config,
    load_type_map,
    setup_logging,
    build_priority_context,
    ensure_priority_context,
    write_json,
    write_excel,
    flatten_records,
)

console = Console()
app = typer.Typer(
    help="Extract case creation information from legal documents",
    add_completion=False,
)


class CaseCreationCLI:
    EXTRACTION_PREVIEW_KEYS: tuple[str, ...] = (
        "client_name",
        "first_name",
        "last_name",
        "medicaid_id",
        "ma_number",
        "claim_number",
        "case_id",
        "settlement_amount",
        "requested_items",
        "ssn",
    )
    EXTRACTION_PREVIEW_FALLBACK_LIMIT: int = 5

    @staticmethod
    def _as_dict(rec):
        if hasattr(rec, "model_dump"):
            return rec.model_dump()
        return dict(rec)

    @classmethod
    def _render_extraction_table(
        cls, records: Sequence[ExtractionRecord | Dict[str, Any]]
    ) -> None:
        table = Table(title="Extraction Summary", show_lines=False)
        table.add_column("Document", style="cyan", overflow="fold")
        table.add_column("Lien Type", style="green")
        table.add_column("Status", style="yellow")
        table.add_column("Extracted (preview)", style="magenta", overflow="fold")

        for raw in records:
            rec = cls._as_dict(raw)
            error = rec.get("error")
            doc = Path(rec.get("path", "")).name
            lien_type = (
                rec.get("lien_type") or rec.get("data", {}).get("lien_type") or "-"
            )
            status = error or "ok"
            data_preview = ""
            data = rec.get("data") or {}
            if data:
                preview_parts = []
                seen_keys: set[str] = set()
                for key in cls.EXTRACTION_PREVIEW_KEYS:
                    val = data.get(key)
                    if val is None:
                        continue
                    if isinstance(val, list):
                        val = ", ".join(map(str, val))
                    preview_parts.append(f"{key}={val}")
                    seen_keys.add(key)

                # Fallback: if preferred keys are missing, show first few non-null fields.
                if not preview_parts:
                    for key, val in data.items():
                        if key in seen_keys or val is None:
                            continue
                        if isinstance(val, list):
                            val = ", ".join(map(str, val))
                        preview_parts.append(f"{key}={val}")
                        if len(preview_parts) >= cls.EXTRACTION_PREVIEW_FALLBACK_LIMIT:
                            break
                data_preview = "; ".join(preview_parts)
            table.add_row(doc, lien_type, status, data_preview)
        console.print(table)

    @classmethod
    def _render_extraction_details(
        cls, records: Sequence[ExtractionRecord | Dict[str, Any]]
    ) -> None:
        for raw in records:
            rec = cls._as_dict(raw)
            error = rec.get("error")
            doc = Path(rec.get("path", "")).name
            title = f"Extraction Detail - {doc}"
            table = Table(title=title, show_lines=False)
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="green", overflow="fold")
            if error:
                table.add_row("error", error)
                console.print(table)
                continue
            data = rec.get("data") or {}
            if not data:
                table.add_row("status", "No data extracted")
            else:
                for key, val in data.items():
                    if val is None:
                        continue
                    if isinstance(val, list):
                        val = ", ".join(map(str, val))
                    table.add_row(key, str(val))
            console.print(table)

    def extract(
        self,
        inputs: List[Path] = typer.Argument(
            [],
            help="Files or folders to process (defaults to sample synthetic docs).",
            metavar="PATH",
        ),
        config: Optional[Path] = typer.Option(
            None,
            "--config",
            "-c",
            help="Extraction config file (.json/.yaml). Defaults to built-in config.",
            metavar="FILE",
        ),
        output: Path = typer.Option(
            Path("artifacts/extraction_output.json"),
            "--output",
            "-o",
            help="Where to write extraction results.",
        ),
        rolling: Optional[bool] = typer.Option(
            None,
            "--rolling/--no-rolling",
            help="Enable or disable rolling-window processing.",
        ),
        window_size: Optional[int] = typer.Option(
            None,
            "--window-size",
            help="Images per rolling window.",
        ),
        overlap: Optional[int] = typer.Option(
            None,
            "--overlap",
            help="Overlap between rolling windows.",
        ),
        log_level: str = typer.Option(
            "INFO",
            "--log-level",
            help="Console log level (e.g. INFO, DEBUG).",
        ),
    ) -> None:
        """Extract structured fields from documents."""
        setup_logging(log_level.upper())
        documents = collect_documents(default_inputs(inputs))

        logger.info("Extracting {} document(s)...", len(documents))
        cfg = load_config(config, fallback=EXTRACTION_CONFIG)
        pipeline = CaseCreationPipeline(extraction_config=cfg)
        progress = Progress(
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        )
        with progress:
            task_id = progress.add_task("Extracting", total=len(documents))
            results = asyncio.run(
                pipeline.extract_documents(
                    documents,
                    rolling=rolling,
                    window_size=window_size,
                    overlap=overlap,
                    progress=progress,
                    task_id=task_id,
                )
            )
        write_json([r.model_dump(exclude_none=True) for r in results], output)
        self._render_extraction_table(results)
        logger.info("Saved extraction results to {}", output)

    def process(
        self,
        inputs: List[Path] = typer.Argument(
            [],
            help="Files or folders to process (defaults to sample synthetic docs).",
            metavar="PATH",
        ),
        config: Optional[Path] = typer.Option(
            None,
            "--config",
            "-c",
            help="Extraction config file (.json/.yaml). Defaults to built-in config.",
            metavar="FILE",
        ),
        output: Path = typer.Option(
                Path("artifacts/case_creation_input.json"),
                "--output",
                "-o",
                help="Output JSON file.",
                ),
        show_details: bool = typer.Option(
            False,
            "--show-details",
            help="Render per-document extraction details in a table.",
        ),
        rolling: Optional[bool] = typer.Option(
            None,
            "--rolling/--no-rolling",
            help="Enable or disable rolling-window processing.",
        ),
        window_size: Optional[int] = typer.Option(
            None,
            "--window-size",
            help="Images per rolling window.",
        ),
        overlap: Optional[int] = typer.Option(
            None,
            "--overlap",
            help="Overlap between rolling windows.",
        ),
        log_level: str = typer.Option(
            "INFO",
            "--log-level",
            help="Console log level (e.g. INFO, DEBUG).",
        ),
    ) -> None:
        """Run the complete case creation workflow.
           Extract, validate, and build the case creation payload."""
        setup_logging(log_level.upper())
        documents = collect_documents(default_inputs(inputs))
        logger.info("Processing {} document(s)...", len(documents))
        cfg = load_config(config, fallback=EXTRACTION_CONFIG)
        pipeline = CaseCreationPipeline(
            extraction_config=cfg
        )
        progress = Progress(
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        )
        with progress:
            task_id = progress.add_task(
                "Processing",
                total=len(documents),
            )
            result = asyncio.run(
                pipeline.process_documents(
                    documents,
                    rolling=rolling,
                    window_size=window_size,
                    overlap=overlap,
                    progress=progress,
                    task_id=task_id,
                )
            )

        payload = (
            result.model_dump(exclude_none=True)
            if hasattr(result, "model_dump")
            else cast(Dict[str, Any], result)
        )
        write_json(payload, output)
            
        logger.info("Finished. Results saved to {}", output)
        
        # Print summaries plus file paths
        extraction = payload.get("extraction", [])
        if extraction:
            console.print("[bold blue]Extraction results[/bold blue]")
            self._render_extraction_table(extraction)
            if show_details:
                self._render_extraction_details(extraction)
        console.print(
            f"[bold blue]Case Creation input:[/bold blue]     {output}"
        )


cli = CaseCreationCLI()
app.command()(cli.extract)
app.command()(cli.process)


def main(argv: Optional[List[str]] = None) -> None:
    app(prog_name="case-creation-ai", args=argv)


if __name__ == "__main__":  # pragma: no cover
    main()
