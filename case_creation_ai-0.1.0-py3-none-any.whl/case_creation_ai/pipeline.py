from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Sequence

from dv_agent_core import create_extractor
from dotenv import load_dotenv
#from loguru import logger
from rich.progress import Progress, TaskID

from case_creation_ai.configs import EXTRACTION_CONFIG
from case_creation_ai.models import (    
    ExtractionRecord,
    ProcessResult,
)
from case_creation_ai.pipeline_support import (
    build_agent_kwargs,
    complete_extraction_payload,
    prepare_entries,
    resolve_rolling_params,
)
from case_creation_ai.rolling import (
    build_windows,
    extract_document_rolling,
)
from case_creation_ai.utils import (
    advance_progress,
    collect_documents,
    document_to_base64_images,
    write_json,
)

class CaseCreationPipeline:
    """
    Encapsulates document extraction and case creation processing.
    """

    def __init__(
        self,
        *,
        extraction_config: Dict | None = None,
    ) -> None:
        load_dotenv()

        extraction = dict(extraction_config or EXTRACTION_CONFIG)

        extraction_model = os.getenv("SUBRO_EXTRACTION_MODEL")
        if extraction_model:
            extraction["model"] = extraction_model

        self.extraction_config = extraction

    async def extract_documents(
        self,
        documents: Sequence[Path | str],
        *,
        base64_documents: Sequence[Any] | None = None,
        rolling: bool | None = None,
        window_size: int | None = None,
        overlap: int | None = None,
        progress: Progress | None = None,
        task_id: int | None = None,
    ) -> List[ExtractionRecord]:
        extractor = create_extractor(self.extraction_config)
        records: List[ExtractionRecord] = []
        use_rolling, resolved_window_size, resolved_overlap = resolve_rolling_params(
            section="extraction",
            config=self.extraction_config,
            rolling=rolling,
            window_size=window_size,
            overlap=overlap,
        )

        entries = prepare_entries(
            documents,
            base64_documents,
            image_loader=document_to_base64_images,
        )
        for entry in entries:
            # If later you want to pass the upstream document type, you can introduce something like:
            # context = {"document_type": document_type}
            context = None

            try:
                if use_rolling:
                    payload = await extract_document_rolling(
                        document_path=entry.path,
                        base64_images=entry.base64_images,
                        context=context,
                        window_size=resolved_window_size,
                        overlap=resolved_overlap,
                        extractor=extractor,
                    )
                else:
                    extract_kwargs = build_agent_kwargs(entry=entry, context=context)
                    result = await extractor.extract(**extract_kwargs)
                    payload = (
                        result.model_dump() if hasattr(result, "model_dump") else {}
                    )
                if isinstance(payload, dict):
                    payload = complete_extraction_payload(
                        payload, self.extraction_config.get("fields", [])
                    )
                records.append(
                    ExtractionRecord(
                        path=entry.name,
                        data=payload,
                    )
                )
            except Exception as exc:  # pragma: no cover - defensive guard
                records.append(
                    ExtractionRecord(
                        path=entry.name,
                        error=str(exc),
                    )
                )

            advance_progress(progress, task_id)

        return records

    async def process_documents(
        self,
        inputs: Sequence[Path | str] | None = None,
        *,
        output_dir: Path = Path("artifacts/case_creation"),
        base64_documents: Sequence[Any] | None = None,
        rolling: bool | None = None,
        window_size: int | None = None,
        overlap: int | None = None,
        progress: Progress | None = None,
    ) -> ProcessResult:
        documents = collect_documents(inputs) if inputs else []
        entries = prepare_entries(
            documents,
            base64_documents,
            image_loader=document_to_base64_images,
        )
        total_docs = len(entries)
        if total_docs == 0:
            raise FileNotFoundError("No documents found for processing.")

        extraction_task = None
        if progress:
            extraction_task = progress.add_task("Extracting", total=total_docs)

        extraction = await self.extract_documents(
            documents,
            base64_documents=base64_documents,
            rolling=rolling,
            window_size=window_size,
            overlap=overlap,
            progress=progress,
            task_id=extraction_task,
        )

        output_dir.mkdir(parents=True, exist_ok=True)
        write_json(
            [e.model_dump(exclude_none=True) for e in extraction],
            output_dir / "extraction.json",
        )

        return ProcessResult(
            extraction=[e.model_dump(exclude_none=True) for e in extraction],
        )
