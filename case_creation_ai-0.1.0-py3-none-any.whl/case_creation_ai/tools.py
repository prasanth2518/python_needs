from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

from case_creation_ai.models import PriorityRankCandidate, PriorityRankResult
from case_creation_ai.utils import PRIORITY_TYPE_ALIASES, normalize_doc_type


def _parse_priority_list(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, (list, tuple, set)):
        return [str(item).strip() for item in raw if str(item).strip()]
    if isinstance(raw, str):
        # Accept formats like "1) type; 2) other_type" or comma/semicolon separated.
        parts = re.split(r"[;,]", raw)
        cleaned: List[str] = []
        for part in parts:
            token = part.strip()
            if not token:
                continue
            token = re.sub(r"^\d+\)\s*", "", token)
            if token:
                cleaned.append(token)
        return cleaned
    return [str(raw).strip()]


def priority_rank(
    label: Any,
    priority_list: Optional[Iterable[str]] = None,
    min_confidence: float = 0.8,
) -> Dict[str, Any]:
    """
    Tool: return priority ranks for one or more candidate labels.

    Use this when multiple categories plausibly apply and you need to select the highest
    priority label. The tool normalizes labels and applies aliases used in the priority list.

    Args:
        label: The candidate label or list of candidates to rank. Candidates may be:
            - str label (e.g., "interim_lien")
            - dict with a "type" key (e.g., {"type": "interim_lien", "confidence": 0.8})
            - list/tuple/set of the above
        priority_list: The ordered list of labels for the current context. This can be
            a list, a semicolon/comma-separated string (e.g. "1) type; 2) other"), or
            any iterable of labels.
        min_confidence: Minimum confidence required for candidates that supply a
            numeric confidence score. Candidates below this threshold are dropped.

    Returns:
        dict with keys:
          - label: normalized label (single input) or selected label (multi input)
          - priority_rank: 1-based rank or None if not found
          - priority_list: normalized priority list
          - candidates: ranked list of candidates with priority_rank
          - selected: best candidate by priority (and confidence as tiebreaker)

    Example:
        priority_rank("interim_lien", priority_list)
        priority_rank(possible_types, priority_list)
    """
    raw_list = _parse_priority_list(priority_list)
    normalized_list = [
        PRIORITY_TYPE_ALIASES.get(normalize_doc_type(item), normalize_doc_type(item))
        for item in raw_list
        if item
    ]

    def _normalize_candidate(raw: Any) -> Optional[PriorityRankCandidate]:
        if raw is None:
            return None
        if isinstance(raw, dict):
            candidate_label = raw.get("type") or raw.get("label") or raw.get("name")
            confidence = raw.get("confidence")
            if isinstance(confidence, (int, float)) and confidence < min_confidence:
                return None
        else:
            candidate_label = raw
            confidence = None
        if candidate_label is None:
            return None
        normalized = normalize_doc_type(str(candidate_label))
        if not normalized:
            return None
        normalized = PRIORITY_TYPE_ALIASES.get(normalized, normalized)
        try:
            rank = normalized_list.index(normalized) + 1
        except ValueError:
            rank = None
        return PriorityRankCandidate(
            label=normalized,
            priority_rank=rank,
            confidence=confidence,
        )

    is_multi = isinstance(label, (list, tuple, set))
    raw_candidates = list(label) if is_multi else [label]
    by_label: Dict[str, PriorityRankCandidate] = {}
    for raw in raw_candidates:
        normalized = _normalize_candidate(raw)
        if not normalized:
            continue
        key = normalized.label
        existing = by_label.get(key)
        if existing is None:
            by_label[key] = normalized
        else:
            existing_conf = existing.confidence
            new_conf = normalized.confidence
            if isinstance(new_conf, (int, float)) and (
                not isinstance(existing_conf, (int, float)) or new_conf > existing_conf
            ):
                by_label[key] = normalized

    candidates = list(by_label.values())

    def _sort_key(item: PriorityRankCandidate) -> tuple:
        rank = item.priority_rank
        rank_key = rank if rank is not None else float("inf")
        conf = item.confidence
        conf_key = conf if isinstance(conf, (int, float)) else -1.0
        return (rank_key, -conf_key)

    candidates.sort(key=_sort_key)
    selected = candidates[0] if candidates else None

    if is_multi:
        label_out = selected.label if selected else None
        rank_out = selected.priority_rank if selected else None
    else:
        label_out = candidates[0].label if candidates else None
        rank_out = candidates[0].priority_rank if candidates else None

    result = PriorityRankResult(
        label=label_out,
        priority_rank=rank_out,
        priority_list=normalized_list,
        candidates=candidates,
        selected=selected,
    )
    return result.model_dump()


def confirm_verbatim_match(
    sees_verbatim: bool,
    matched_verbatim: Optional[str] = None,
    matched_page_number: Optional[int] = None,
    is_request_context: Optional[bool] = None,
) -> Dict[str, Any]:
    """
    Tool: confirm whether mapped second-pass verbatim cues, or their clear
    semantic equivalents, are visibly present.

    The caller should pass a simple yes/no decision after checking the document
    against the mapped rationale phrases for the proposed flip type. For
    request-driven document types, also indicate whether the matched cue is
    being used in an actual request context rather than an authorization,
    disclosure, or reference-only context.
    """
    normalized_match = (
        str(matched_verbatim).strip() if matched_verbatim is not None else None
    )
    normalized_page_number = (
        int(matched_page_number)
        if isinstance(matched_page_number, int)
        and not isinstance(matched_page_number, bool)
        and matched_page_number > 0
        else None
    )
    return {
        "sees_verbatim": bool(sees_verbatim),
        "matched_verbatim": normalized_match or None,
        "matched_page_number": normalized_page_number,
        "is_request_context": (
            bool(is_request_context) if isinstance(is_request_context, bool) else None
        ),
    }
