"""Configuration for case creation data extraction."""

from pathlib import Path

SAMPLE_DOC_ROOT = Path("data/subro_sample_docs/synthetic")
SUPPORTED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}

PRIORITY_NO_CONTEXTS = {
    "CTSCASGA",
}

EXTRACTION_CONFIG = {
    #"model": "gpt-5-mini-2025-08-07",
    "model": "gpt-5.6-luna",
    "model_settings": {
        "reasoning_effort": "none",
    },
    "retries": 2,
    "extraction_rolling": {
        "enabled": True,
        "window_size": 5,
        "overlap": 2,
    },
    "instruction_template": (
        "Extract the information required to create a new Medicaid casualty case. "
        "The input document has already been classified by an upstream AI system "
        "and will be one of the supported case creation document types only"
        "(Interim Lien, Letter of Representation, Medical/HIPAA Authorization, "
        "Case Information Form). "
        "Extract ONLY information explicitly present in the document. "
        "Do not infer, guess or fabricate values. "
        "Return exactly the JSON schema below and no other keys. "
        "Never omit a section or field. "
        "Never create, rename, alias, or split a schema-defined field. "
        "If a value is unavailable, return null. "
    ),
    "general_guidelines": (
        "- Return every section and every schema-defined field, including every "
        "field inside nested objects. Each field must be present with an extracted "
        "or required default value, or null when no value is available. Never omit "
        "a field from the output.\n"
        "- STRICT SCHEMA ENFORCEMENT: Return exactly and only the sections and field "
        "names declared in the schema. Never create an additional field, even when "
        "it appears useful or more specific. Never rename, alias, move, expand, or "
        "split a declared field into new fields. Place information only in its "
        "declared field; if no declared field applies, ignore that information.\n"
        "- Do not infer missing values.\n"
        "- Never hallucinate or infer injuries or body parts. Populate "
        "individual_injuries and body_parts_involved only when they are explicitly "
        "and clearly stated in the document; otherwise return null.\n"
        "- Populate case_information.mandatory_fields.case_type with exactly one "
        "allowed dropdown value based on the documented accident or incident. If "
        "the type cannot be determined from the document, return OTHER OR UNKNOWN.\n"
        "- Populate case_information.mandatory_fields.case_source with exactly one "
        "allowed dropdown value based on the document's origin, such as its sender, "
        "letterhead, or organization. Use the case-source cues in the schema "
        "description. If the source cannot be determined, return OTHER OR UNKNOWN.\n"
        "- Populate contact_information only with contact and organization details "
        "for the party that submitted or generated the incoming document. Do not "
        "use the contact details of parties that are merely mentioned in the "
        "document.\n"
        "- Treat a person explicitly identified in the email From header, sender's "
        "signature block, attached letter signature, or submitting organization's "
        "letterhead as a source contact. If any such source contact is explicitly "
        "present, contact_information must be a list and must not be null. Include "
        "each unique source contact whose details are shown; do not include the "
        "email recipient merely because the recipient appears in the To header. Do not "
        "include any receiving, addressed-to, copied, referral, RMO, claims-routing, or "
        "other recipient organization as a source contact unless the document separately "
        "identifies that organization as the party submitting or generating the document.\n"
        "- Treat every person or organization appearing in the document's To, To:, "
        "addressed-to, recipient, or similar destination section as a receiver, not a "
        "source contact. This receiver rule takes precedence over contact details such as "
        "an email address or mailing address shown in that section.\n"
        "- Return exactly one contact_information object for each unique "
        "organization_name. Never create two contact objects for the same organization. "
        "Keep contact_name as a single string. When multiple contacts belong to the same "
        "organization, describe the additional contact names and explicitly stated job "
        "titles only in the single-string contact_note field. Never include phone numbers, "
        "email addresses, or fax numbers in contact_note.\n"
        "Normalize organization identity using the complete mailing address and contact "
        "details. Treat abbreviations such as Street/St, Suite/Ste, and state-name versus "
        "state-code variations as equivalent. Normalize organization names similarly: "
        "treat punctuation, capitalization, legal suffixes, and a trade or practice-name "
        "variant as equivalent when the address and contact details identify the same "
        "organization. Return one canonical organization_name, preferring the complete "
        "primary organization or law-firm name shown in the first line, header, logo, or "
        "letterhead branding. The primary name is more important than a longer historical "
        "or legal name. Do not use a comma-separated roster of attorneys as organization_name; "
        "place those attorney names in contact_note instead. For example, if the header says "
        "BlumeForte Attorneys at Law and a later line lists many attorneys, use "
        "BlumeForte Attorneys at Law as organization_name.\n"
        "- contact_information.contact_type identifies the contact's relationship to the"
        " case, such as ATTORNEY FOR PLAINTIFF, return null when it is not explicitly stated.\n"
        "For contacts from a law firm or attorney source, set "
        "contact_information.contact_name to ATTORNEY OF RECORD by default. For all "
        "other source types, extract contact_name from the document when explicitly "
        "stated; otherwise return it as null. When the correspondence body specifically "
        "identifies a particular attorney, paralegal, or other contact, return that "
        "person's explicitly stated name in contact_information.contact_note; otherwise "
        "return contact_note as null.\n"
        "- Return the contact's complete mailing address as one string in "
        "contact_information.address. Combine all explicitly stated address lines, "
        "city, state, and postal code into that field. Do not create address_line_1, "
        "address_line_2, city, state, zip, zip_code, or any other field not defined "
        "in the schema. When multiple contacts belong to the same organization, "
        "all contact objects should reference the same normalized organization address."
        "Differences such as building names, abbreviations (Suite vs STE), punctuation, "
        "or formatting should not result in different address values.\n"
        #"- Always set case_information.mandatory_fields.case_priority to 3 - HIGH, "
        #"case_status to OPEN, case_stage to CASE PENDING CLAIMS TO ACCUMULATE, and "
        #"case_open_date to the current date in YYYY-MM-DD format. These required "
        #"defaults are exceptions to the rule to return null for information not "
        #"present in the document.\n"
        "- Return optional case_information fields when they are explicitly and "
        "unambiguously present in the incoming document; otherwise return null.\n"
        "- Normalize first_name, middle_name and last_name to UPPERCASE.\n"
        "- Normalize all dates to YYYY-MM-DD.\n"
        "- Populate incident_date with the date explicitly identifying the event usually represented by Date of Incident.\n"
        "- Populate incident_information.individual_injuries only with injuries "
        "clearly listed in the document. Return a list of objects with injury and "
        "description keys, using a short explicit description when present and "
        "null otherwise. Do not infer an injury from a body part or accident "
        "narrative.\n"
        "- Populate incident_information.body_parts_involved only with body parts "
        "clearly listed as involved in the accident. Return a list of objects with "
        "body_part and description keys, using a short explicit description when "
        "present and null otherwise. Do not infer a body part from an injury.\n"
        "- Preserve Member IDs, MA Numbers and Subscriber IDs exactly as written.\n"
        "- Never infer insurance_information.insurance_member_id. Populate it only "
        "from a health insurance card when the value is explicitly labeled Member "
        "ID or member # on that card. Never populate insurance_member_id from any other part of "
        "the document, and never copy or substitute a Subscriber ID from the card. "
        "If the health insurance card does not explicitly state a Member ID, return "
        "null for insurance_member_id.\n"
        "- When insurance_information.insurance_member_id is validly extracted "
        "and no separate member_id is directly identified elsewhere in the "
        "document, return insurance_member_id unchanged in "
        "member_information.member_id. If the document explicitly identifies a "
        "different member_id, use that value instead.\n"
        "- Preserve phone numbers and email addresses exactly as written.\n"
        "- Remove spaces and hyphens from SSN values.\n"
        "- Always include the complete SSN object with full, last_6, and last_4 "
        "keys. Populate a key only when that exact SSN representation is explicitly "
        "shown in the document; otherwise return null.\n"
        "- Minimum information for case creation consists of first_name, last_name, "
        "date_of_birth, incident_date, and at least one member identifier: a full "
        "SSN or Member ID.\n"
        "- Extract both SSN and Member ID when both are explicitly present.\n"
        "- A partial SSN does not satisfy the full-SSN requirement, but it must "
        "still be returned in the appropriate SSN field when explicitly present.\n"
        "- The output JSON must exactly match the schema below, with no undeclared "
        "sections or fields.\n"
        "MANDATORY: Output json must contain these fields first_name, last_name, "
        "date_of_birth, incident_date, member_id, and ssn.\n"
        "- Do not move fields between sections.\n"
        "- Retain the order of sections and fields defined in the schema.\n"
    ),
    "fields": [
        #{
        #    "name": "minimum_information",
        #    "type": "object",
        #    "description": (
        #        "Minimum information required for Case Creation"
        #    ),
        #    "fields": {
        #        "first_name": None,
        #        "last_name": None,
        #        "date_of_birth": None,
        #        "incident_date": None,
        #        "member_id": None,
        #        "ssn": {
        #            "full": None,
        #            "last_6": None,
        #            "last_4": None,
        #        },
        #    },
        #},
        {
            "name": "member_information",
            "type": "object",
            "description": "Member demographic information. Do not skip any fields in this section. They are all mandatory. "
            "Only extract the below fields when they are explicitly present in the document; otherwise return null. "
            "Populate member_id only from an explicitly identified Member ID; do not relabel a policy number or SSN as member_id. "
            "Do not add any additional fields to this section. ",
            "fields": {
                "member_id": None,
                "ma_number": None,
                "first_name": None,
                "middle_name": None,
                "last_name": None,
                "ssn": {
                    "full": None,
                    "last_6": None,
                    "last_4": None,
                },
                "date_of_birth": None,
                "gender": None,
                "marital_status": None,
            },
        },
        {
            "name": "incident_information",
            "type": "object",
            "description": (
                "Complete incident information explicitly stated in the document, "
                "including the incident date, incident description, individual "
                "injuries, and body parts involved. individual_injuries is a list "
                "of objects with injury and description keys, for example: "
                '[{"injury": "sprain", "description": "mild cervical sprain"}]. '
                "body_parts_involved is a list of objects with body_part and "
                "description keys, for example: "
                '[{"body_part": "neck", "description": "left side"}].'
            ),
            "fields": {
                "incident_date": None,
                "incident_description": None,
                "individual_injuries": None,
                "body_parts_involved": None,
            },
        },
        {
            "name": "case_information",
            "type": "object",
            "description": (
                "Case information section has a few mandatory fields and "
                "a few optional fields. Mandatory fields: case_type, case_source, "
                #"case_priority, case_status, case_stage, case_open_date, and county. "
                "Optional fields: service_date_from, service_date_to, "
                "insurance_claim_number, and death_date. "
                "Return optional fields only when they are explicitly and "
                "unambiguously present in the incoming document; otherwise return "
                "null. "

                "Allowed case_type values and identifying cues: ABUSE / NEGLECT "
                "(abuse, neglect, abandonment, caregiver misconduct); AUTOMOTIVE "
                "(motor vehicle accident, car or truck crash, motorcycle accident, "
                "collision, driver negligence); ASSAULT (attack, battery, fight, "
                "altercation, intentional injury); BIRTH DEFECT (congenital "
                "condition, prenatal injury, pregnancy complication, genetic or "
                "developmental abnormality); BRAIN INJURY (TBI, concussion, head "
                "injury, loss of consciousness, neurological damage); BUSINESS "
                "RELATED (NON-SLIP AND FALL) (non-fall injury at a business, "
                "negligent security, falling object, equipment malfunction); DOG "
                "BITE (dog or animal attack or bite); HIT BY VEHICLE (pedestrian or "
                "cyclist struck by a vehicle); HOMEOWNERS (residential-property "
                "injury, pool accident, unsafe stairs or railing); MALPRACTICE "
                "(medical negligence, misdiagnosis, surgical, medication, or "
                "treatment error); MASS TORTS (multiple plaintiffs, pharmaceuticals, "
                "medical devices, toxic or environmental exposure); NURSING HOME "
                "NEGLECT / INCIDENT (elder neglect, inadequate care, pressure "
                "ulcers, dehydration, malnutrition, or resident fall); PERSONAL "
                "INJURY (general bodily-injury or negligence claim that fits no "
                "more specific type); POISONING / EXPOSURE TO HARMFUL SUBSTANCES "
                "(chemical, carbon monoxide, asbestos, lead, food poisoning, or "
                "toxic fumes); PRODUCT LIABILITY (defective or unsafe product, "
                "design or manufacturing defect, failure to warn); SCHOOL BASED "
                "(school, student, playground, sports, bullying, or school-staff "
                "incident); SLIP AND FALL (wet floor, slippery surface, trip hazard, "
                "uneven pavement, ice, snow, or poor maintenance); WORK RELATED "
                "(workplace, on-the-job, occupational, construction, equipment, or "
                "workers' compensation injury); OTHER OR UNKNOWN (insufficient "
                "information or no matching type). "
                "The most common case_type values are AUTOMOTIVE, ASSAULT, DOG BITE, "
                "and SLIP AND FALL. Do not select one of these values without "
                "supporting evidence in the document. If case_type cannot be clearly "
                "determined, use OTHER OR UNKNOWN. "

                "Allowed case_source values and identifying cues: TCM (TRAUMA CODE "
                "MAILER) INITIAL OR 2ND PASS (TCM review, second pass, follow-up "
                "request, secondary review, case re-evaluation, or a questionnaire "
                "stating that records indicate recent AHCCCS injury care and "
                "requiring its return within ten days); ATTORNEY "
                "(attorney, law office, Esq., legal counsel, law firm, or "
                "representation letter or attorney-originated settlement notice); "
                "COURT (court order, judgment, probate, "
                "circuit or superior court, docket, filing, subpoena, or hearing); "
                "DMV DATA MATCH (DMV, motor-vehicle record, vehicle registration, "
                "driver record, or license information); HOSPITAL (hospital, medical "
                "center, inpatient, admission or discharge record, or patient "
                "account); INSURANCE COMPANY (AUTOMOBILE) (auto insurer or carrier, "
                "adjuster, liability coverage, PIP, or auto claim); MANAGED CARE "
                "ORGANIZATION (MCO) (MCO, managed care, health plan, care "
                "coordination, member services, or provider network); NURSING HOME "
                "(nursing home, skilled nursing facility, SNF, long-term care, or "
                "facility administrator); PERSONAL REPRESENTATIVE (personal "
                "representative, executor, administrator, estate representative, or "
                "power of attorney); RECIPIENT (Medicaid member, member statement, "
                "self-report, recipient submission, claimant letter, or beneficiary); "
                "STATE (state agency, department of health or human services, state "
                "Medicaid, state records, or AHCCCS); TRAUMA CODE ANALYSIS (trauma "
                "code, ICD-10, external-cause code, injury diagnosis, or "
                "accident-related treatment); WC AGENCY MATCH (WC match, workers' "
                "compensation agency, state WC database, or claim match); WORKERS' "
                "COMPENSATION (workers' compensation insurer, employer, WC claim, "
                "work-related injury, employer report, TPA, or compensation carrier); "
                "OTHER OR UNKNOWN (unidentified, miscellaneous, or insufficient "
                "source information). Determine case_source from evidence identifying "
                "who submitted or generated the incoming document. Do not classify it "
                "solely from parties incidentally mentioned in the document."
                "The most common case_source values are ATTORNEY, HOSPITAL, "
                "INSURANCE COMPANY, MANAGED CARE ORGANIZATION. Do not select one of these "
                "values without supporting evidence in the document. If case_source cannot "
                "be clearly determined, use OTHER OR UNKNOWN. "

                #"Always return case_priority as 3 - HIGH, case_status as OPEN, and "
                #"case_stage to CASE PENDING CLAIMS TO ACCUMULATE. Return current date "
                #"in YYYY-MM-DD format for case_open_date. County information is not"
                #"extracted from the incoming document; it is to be populated from the "
                #"county associated with the member's most recent address "
                #"in the Selected Member section."
                "Return optional fields listed in the case_information section "
                "only when they are explicitly and unambiguously present in the "
                "incoming document; otherwise return null."
            ),
            "fields": {
                "mandatory_fields": {
                    "case_type": None,
                    "case_source": None,
                    #"case_priority": '3 - HIGH',
                    #"case_status": 'OPEN',
                    #"case_stage": 'CASE PENDING CLAIMS TO ACCUMULATE',
                    #"case_open_date": None,
                    #"county": None,
                },
                "optional_fields": {
                    "service_date_from": None,
                    "service_date_to": None,
                    "insurance_claim_number": None,
                    "death_date": None,
                },
            },
        },
        {
            # May not really be needed for case creation, but included for completeness.
            "name": "contact_information",
            "type": "list",
            "description": (
                "Populate contact_information with contact and organization "
                "information for the party that submitted or generated the incoming "
                "document. This may be a law firm, "
                "hospital, insurance company, managed care organization, or "
                "another source. Do not use the contact details of parties that are "
                "merely mentioned in the document. An email From header, sender's "
                "signature block, signed attached letter, or submitting law-firm "
                "letterhead is explicit evidence of a source contact. When such a "
                "contact is present, return a contact object and do not return null. "
                "For example, an email sender shown with a law-firm signature, email, "
                "phone, and address is a valid contact even if the email body itself "
                "is brief. Include each unique source contact, such as both the email "
                "sender and the signer of an attached representation letter, when "
                "their details are explicitly shown. Do not treat the To-header "
                "recipient as the source contact. Also exclude receiving, addressed-to, "
                "copied, referral, RMO, claims-routing, and other recipient organizations "
                "unless the document separately identifies them as the submitting or "
                "generating source. Treat every person or organization in the document's "
                "To, To:, addressed-to, recipient, or similar destination section as a "
                "receiver, never as a source contact, even when that section includes an "
                "email address or mailing address. Return organization_name, "
                "address, contact_type, contact_name, contact_note, email, "
                "phone, and fax. contact_type describes the contact's "
                "relationship to the case (for example, ATTORNEY FOR PLAINTIFF); "
                "For a law firm or attorney source, set contact_name to ATTORNEY OF "
                "RECORD by default. For all other source types, extract contact_name "
                "from the document when explicitly stated; otherwise return it as null. "
                "When the body of the correspondence specifically identifies a particular "
                "attorney, paralegal, or other contact, extract that person's explicitly "
                "stated name in contact_note; otherwise return contact_note as null. "
                "contact_title is the person's professional or job title "
                "as written in the document (for example, LEGAL SUPPORT ASSOCIATE). "
                "Do not place a job title in contact_type. Return null when either "
                "value is not explicitly stated. Return the complete mailing address "
                "as one string in address; never split it into additional fields. "
                "Normalize organization addresses before returning contact_information. "
                "If multiple contacts belong to the same organization and the document "
                "contains equivalent representations of the organization's mailing address "
                "(for example, one includes the building name while another omits it), "
                "return a single normalized mailing address for all contacts from that organization."
                "Use the most complete valid address by combining explicitly stated address "
                "components (street, suite/unit, city, state, and ZIP code). Do not create "
                "multiple address variants for the same organization."
                "Use the primary organization or law-firm name shown in the first line, "
                "header, logo, or letterhead branding as organization_name. The primary "
                "name is more important than a longer historical or legal name. Never use "
                "a comma-separated roster of attorneys as organization_name; put those names "
                "in contact_note. For example, if the header says BlumeForte Attorneys at "
                "Law and a later line lists many attorneys, use BlumeForte Attorneys at Law. "
                "contact_information must always be returned as a LIST of contact objects. "
                "Return exactly one object for each unique organization_name. Never return "
                "two objects for the same organization. If multiple explicitly identified "
                "contacts belong to one organization, keep one contact object, keep "
                "contact_name as a single string, and describe the additional contact "
                "names and explicitly stated job titles only in the single-string "
                "contact_note field. Never include phone numbers, email addresses, or "
                "fax numbers in contact_note.\n"
                "Every contact object MUST contain every schema-defined field. Never omit "
                "contact_type or contact_title. If either value cannot be determined from the "
                "document, return null.\n"
                #"contact_type is a dropdown with allowed values: To be updated"
            ),
            "fields": {
                "organization_name": None,
                "address": None,
                "contact_type": None,
                "contact_name": None,
                "contact_note": None,
                "email": None,
                "phone": None,
                "fax": None,
            },
        },
        {
            # May not really be needed for case creation, but included for completeness. The downstream system will ignore this section.
            "name": "insurance_information",
            "type": "object",
            "description": (
                "Insurance information from a health insurance card, coverage "
                "overview, eligibility screen, representation letter, or another "
                "document that explicitly identifies the member's health coverage. "
                "Populate insurance_carrier with the insurance company, health plan, "
                "or Medicaid program name prominently identifying the coverage, such "
                "as Amerigroup RealSolutions or Arkansas Medicaid / AR Medicaid-PCP "
                "Referral Req. A health plan whose subrogation interest is explicitly "
                "requested in a member-specific representation letter is an insurance "
                "carrier even when no insurance card is attached. Populate member_name "
                "with the person explicitly shown "
                "as Member Name, Member, Subscriber, or the covered person. "
                "Populate subscriber_id only from a value explicitly labeled "
                "Subscriber ID, Subscriber #, or equivalent; the word Subscriber "
                "beneath a person's name identifies the member_name and is not an ID. "
                "insurance_member_id and subscriber_id are distinct fields. Never "
                "infer insurance_member_id. Populate insurance_member_id only from a "
                "health insurance card or coverage record where the value is "
                "explicitly labeled Member ID or Member #. Do not copy or substitute "
                "a Subscriber ID into insurance_member_id. If no value is explicitly "
                "identified as Member ID or Member #, return null for "
                "insurance_member_id. Populate ma_number with an explicitly shown "
                "Medicaid/MA identifier. When the coverage is explicitly a Medicaid "
                "program, a value labeled Medicaid ID, MA Number, Member ID, Member "
                "number, or program-specific beneficiary number is the ma_number. "
                "Preserve all identifiers exactly as written. Extract each available "
                "field independently; a null insurance_member_id does not require "
                "insurance_carrier, member_name, subscriber_id, or ma_number to be null."
                #"if insurance_member_id is not present on the insurance card and the rest of the document,"
                #"subscriber_id is the member ID on the minimum information section unless specified otherwise in the document."
            ),
            "fields": {
                "insurance_carrier": None,
                "member_name": None,
                "insurance_member_id": None, 
                "subscriber_id": None,
                "ma_number": None,
            },
        },
        
    ],
}
