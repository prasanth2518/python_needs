"""Configuration for case creation data extraction."""

from pathlib import Path

SAMPLE_DOC_ROOT = Path("data/subro_sample_docs/synthetic")
SUPPORTED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}

PRIORITY_NO_CONTEXTS = {
    "CTSCASGA",
}

# Exact UI dropdown values
SPECIFIC_INJURY_CODES = {
    "(800-804) FRACTURE OF SKULL": "",
    "(805-809) FRACTURE OF NECK AND TRUNK": "",
    "(810-819) FRACTURE OF UPPER LIMB": "",
    "(820-829) FRACTURE OF LOWER LIMB": "",
    "(830-839) DISLOCATION": "",
    "(840-848) SPRAINS AND STRAINS OF JOINTS AND ADJACENT MUSCLES": "",
    "(850-854) INTRACRANIAL INJURY, EXCLUDING THOSE WITH SKULL FRACTURE": "",
    "(860-869) INTERNAL INJURY OF THORAX, ABDOMEN, AND PELVIS": "",
    "(870-879) OPEN WOUND OF HEAD, NECK, AND TRUNK": "",
    "(870-897) OPEN WOUND": "",
    "(880-887) OPEN WOUND OF UPPER LIMB": "",
    "(890-897) OPEN WOUND OF LOWER LIMB": "",
    "(900-904) INJURY TO BLOOD VESSELS": "",
    "(905-909) LATE EFF. OF INJ., POISON., TOXIC EFF., AND OTHER EXT CAUSES": "",
    "(910-919) SUPERFICIAL INJURY": "",
    "(920-924) CONTUSION WITH INTACT SKIN SURFACE": "",
    "(925-929) CRUSHING INJURY": "",
    "(930-939) EFFECTS OF FOREIGN BODY ENTERING THROUGH ORIFICE": "",
    "(940-949) BURNS": "",
    "(950-957) INJURY TO NERVES AND SPINAL CORD": "",
    "(958-959) CERTAIN TRAUMATIC COMPLICATIONS AND UNSPECIFIED INJURIES": "",
    "(960-979) POISONING BY DRUGS, MEDICINAL AND BIOLOGICAL SUBSTANCES": "",
    "(980-989) TOXIC EFF. OF SUBSTANCES CHIEFLY NONMED. AS TO SOURCE": "",
    "(990-995) OTHER AND UNSPECIFIED EFFECTS OF EXTERNAL CAUSES": "",
    "(996-999) COMPLIC. OF SURG. AND MED. CARE, NOT ELSEWHERE CLASSIFIED": "",
    "(E800-E809) RAILWAY ACCIDENTS": "",
    "(E810-E819) MOTOR VEHICLE TRAFFIC ACCIDENTS": "",
    "(E820-E825) MOTOR VEHICLE NON-TRAFFIC ACCIDENTS": "",
    "(E826-E829) OTHER ROAD VEHICLE ACCIDENTS": "",
    "(E830-E839) WATER TRANSPORT ACCIDENTS": "",
    "(E840-E845) AIR AND SPACE TRANSPORT ACCIDENTS": "",
    "(E846-E849) VEHICLE ACCIDENTS, NOT ELSEWHERE CLASSIFIABLE": "",
    "(E850-E858) ACCIDENTAL POIS BY DRUGS, MED SUBSTANCES, AND BIOLOGICALS": "",
    "(E860-E869) ACCIDENTAL POIS BY OTHR SOL AND LIQ SUB, GASES, AND VAPORS": "",
    "(E870-E876) MISADVENTURES TO PATIENTS DURING SURGICAL AND MEDICAL CARE": "",
    "(E878-E879) SURG AND MEDICAL PROC AS THE CAUSE OF ABNORMAL REACTION": "",
    "(E880-E888) ACCIDENTAL FALLS": "",
    "(E890-E899) ACCIDENTS CAUSED BY FIRE AND FLAMES": "",
    "(E900-E909) ACCIDENTS DUE TO NATURAL AND ENVIRONMENTAL FACTORS": "",
    "(E910-E915) ACCIDENTS CAUSED BY SUBMERSION, SUFFOC., & FOREIGN BODIES": "",
    "(E916-E929) OTHER ACCIDENTS": "",
    "(E930-E949) DRGS, MEDIC & BIOL. SUBST CAUS ADVRS EFFCTS IN THERAP USE": "",
    "(E950-E959) SUICIDE AND SELF-INFLICTED INJURY": "",
    "(E960-E969) HOMICIDE AND INJURY PURPOSELY INFLICTED BY OTHER PERSONS": "",
    "(E970-E978) LEGAL INTERVENTION": "",
    "(E980-E989) INJ UNDET WHETHER ACCIDENTALLY OR PURPOSELY INFLICTED": "",
    "(E990-E999) INJURY RESULTING FROM OPERATION OF WAR": "",
}

# Exact UI dropdown values and their corresponding descriptions.
GENERAL_INJURY_CODES = {
    "(800-829) FRACTURE": "Fracture - Broken bone.",
    "(830-839) DISLOCATION": "Dislocation - Joint out of place.",
    "(840-848) SPRAIN AND/OR STRAIN": (
        "Sprain and/or Strain - Ligament or muscle injury."
    ),
    "(850-854) INTRACRANIAL": "Intracranial - Brain/head injury.",
    "(860-869) INTERNAL INJURY CHEST / ABDOMEN / PELVIS": (
        "Internal Injury (Chest/Abdomen/Pelvis) - Damage to internal organs."
    ),
    "(870-879) OPEN WOUND HEAD NECK TRUNK": (
        "Open Wound (Head/Neck/Trunk) - Cut or laceration to upper body."
    ),
    "(880-887) OPEN WOUND UPPER LIMB": (
        "Open Wound (Upper Limb) - Cut or laceration to arm/hand."
    ),
    "(890-897) OPEN WOUND LOWER LIMB": (
        "Open Wound (Lower Limb) - Cut or laceration to leg/foot."
    ),
    "(900-904) BLOOD VESSEL": "Blood Vessel - Injury to veins or arteries.",
    "(905-909) LATE EFFECT OF INJURIES": (
        "Late Effect of Injuries - Ongoing complications from prior injury."
    ),
    "(910-919) SUPERFICIAL INJURY": (
        "Superficial Injury - Minor surface injury (scrape, abrasion)."
    ),
    "(920-924) CONTUSION": "Contusion - Bruise or blunt impact injury.",
    "(925-929) CRUSHING INJURY": "Crushing Injury - Body part compressed or crushed.",
    "(930-939) FOREIGN BODY": "Foreign Body - Object lodged in body.",
    "(940-949) BURN": "Burn - Heat, chemical, or electrical burn.",
    "(950-957) NERVE DAMAGE": "Nerve Damage - Injury affecting nerves.",
    "(958-959) TRAUMATIC COMPLICATIONS": (
        "Traumatic Complications - Complications resulting from trauma."
    ),
    "(960-979) POISONING": "Poisoning - Harmful substance exposure.",
    "(980-989) TOXIC EFFECTS NON MEDICAL": (
        "Toxic Effects (Non-Medical) - Injury from toxic chemicals or substances."
    ),
    "(990-998) OTHER": "Other - Injury not fitting another category.",
    "(999-999) UNKNOWN": "Unknown - Injury type not identified.",
    "(E800-E809) RAILWAY ACCIDENTS": "Railway Accidents - Train-related incident.",
    "(E810-E819) MOTOR VEHICLE TRAFFIC ACCIDENTS": (
        "Motor Vehicle Traffic Accidents - Roadway vehicle crash."
    ),
    "(E820-E825) MOTOR VEHICLE NON-TRAFFIC ACCIDENTS": (
        "Motor Vehicle Non-Traffic Accidents - Vehicle accident off public roads."
    ),
    "(E826-E829) OTHER ROAD VEHICLE ACCIDENTS": (
        "Other Road Vehicle Accidents - Non-standard road vehicle incident."
    ),
    "(E830-E839) WATER TRANSPORT ACCIDENTS": (
        "Water Transport Accidents - Boat or watercraft accident."
    ),
    "(E840-E845) AIR AND SPACE TRANSPORT ACCIDENTS": (
        "Air and Space Transport Accidents - Aircraft-related accident."
    ),
    "(E846-E849) VEHICLE ACCIDENTS, NOT ELSEWHERE CLASSIFIABLE": (
        "Vehicle Accidents, NEC - Vehicle accident not otherwise classified."
    ),
    "(E850-E858) ACCIDENTAL POIS BY DRUGS, MED SUBSTANCES, AND BIOLOGICALS": (
        "Accidental Poisoning (Drugs/Biologicals) - Unintentional drug/substance poisoning."
    ),
    "(E860-E869) ACCIDENTAL POIS BY OTHR SOL AND LIQ SUB, GASES, AND VAPORS": (
        "Accidental Poisoning (Gases/Liquids/Solids) - Unintentional exposure to hazardous substances."
    ),
    "(E870-E876) MISADVENTURES TO PATIENTS DURING SURGICAL AND MEDICAL CARE": (
        "Medical/Surgical Misadventures - Preventable issue during treatment."
    ),
    "(E878-E879) SURG AND MEDICAL PROC AS THE CAUSE OF ABNORMAL REACTION": (
        "Medical Procedure Reaction - Adverse reaction from medical care."
    ),
    "(E880-E888) ACCIDENTAL FALLS": "Accidental Falls - Slip, trip, or fall injury.",
    "(E890-E899) ACCIDENTS CAUSED BY FIRE AND FLAMES": (
        "Fire and Flames - Burn injury from fire."
    ),
    "(E900-E909) ACCIDENTS DUE TO NATURAL AND ENVIRONMENTAL FACTORS": (
        "Natural/Environmental Factors - Weather or environmental injury."
    ),
    "(E910-E915) ACCIDENTS CAUSED BY SUBMERSION, SUFFOC., & FOREIGN BODIES": (
        "Submersion/Suffocation/Foreign Bodies - Breathing-related accident."
    ),
    "(E916-E929) OTHER ACCIDENTS": "Other Accidents - Miscellaneous accidental injury.",
    "(E930-E949) DRGS, MEDIC & BIOL. SUBST CAUS ADVRS EFFCTS IN THERAP USE": (
        "Drug/Medical Adverse Effects - Negative reaction to treatment or medication."
    ),
    "(E950-E959) SUICIDE AND SELF-INFLICTED INJURY": (
        "Suicide/Self-Inflicted Injury - Self-caused injury."
    ),
    "(E960-E969) HOMICIDE AND INJURY PURPOSELY INFLICTED BY OTHER PERSONS": (
        "Homicide/Injury by Others - Injury intentionally caused by another person."
    ),
    "(E970-E978) LEGAL INTERVENTION": (
        "Legal Intervention - Injury involving law enforcement action."
    ),
    "(E980-E989) INJ UNDET WHETHER ACCIDENTALLY OR PURPOSELY INFLICTED": (
        "Injury Undetermined - Cause cannot be determined."
    ),
    "(E990-E999) INJURY RESULTING FROM OPERATION OF WAR": (
        "War Operations - Injury resulting from war-related activity."
    ),
}

# Specific-to-general relationships derived from the supplied code ranges.
# Entries spanning multiple general ranges require document-supported selection.
SPECIFIC_TO_GENERAL_INJURY_CODES = {
    "(800-804) FRACTURE OF SKULL": (
        "(800-829) FRACTURE"
    ),
    "(805-809) FRACTURE OF NECK AND TRUNK": (
        "(800-829) FRACTURE"
    ),
    "(810-819) FRACTURE OF UPPER LIMB": (
        "(800-829) FRACTURE"
    ),
    "(820-829) FRACTURE OF LOWER LIMB": (
        "(800-829) FRACTURE"
    ),
    "(830-839) DISLOCATION": (
        "(830-839) DISLOCATION"
    ),
    "(840-848) SPRAINS AND STRAINS OF JOINTS AND ADJACENT MUSCLES": (
        "(840-848) SPRAIN AND/OR STRAIN"
    ),
    "(850-854) INTRACRANIAL INJURY, EXCLUDING THOSE WITH SKULL FRACTURE": (
        "(850-854) INTRACRANIAL"
    ),
    "(860-869) INTERNAL INJURY OF THORAX, ABDOMEN, AND PELVIS": (
        "(860-869) INTERNAL INJURY CHEST / ABDOMEN / PELVIS"
    ),
    "(870-879) OPEN WOUND OF HEAD, NECK, AND TRUNK": (
        "(870-879) OPEN WOUND HEAD NECK TRUNK"
    ),
    "(880-887) OPEN WOUND OF UPPER LIMB": (
        "(880-887) OPEN WOUND UPPER LIMB"
    ),
    "(890-897) OPEN WOUND OF LOWER LIMB": (
        "(890-897) OPEN WOUND LOWER LIMB"
    ),
    "(900-904) INJURY TO BLOOD VESSELS": (
        "(900-904) BLOOD VESSEL"
    ),
    "(905-909) LATE EFF. OF INJ., POISON., TOXIC EFF., AND OTHER EXT CAUSES": (
        "(905-909) LATE EFFECT OF INJURIES"
    ),
    "(910-919) SUPERFICIAL INJURY": (
        "(910-919) SUPERFICIAL INJURY"
    ),
    "(920-924) CONTUSION WITH INTACT SKIN SURFACE": (
        "(920-924) CONTUSION"
    ),
    "(925-929) CRUSHING INJURY": (
        "(925-929) CRUSHING INJURY"
    ),
    "(930-939) EFFECTS OF FOREIGN BODY ENTERING THROUGH ORIFICE": (
        "(930-939) FOREIGN BODY"
    ),
    "(940-949) BURNS": (
        "(940-949) BURN"
    ),
    "(950-957) INJURY TO NERVES AND SPINAL CORD": (
        "(950-957) NERVE DAMAGE"
    ),
    "(958-959) CERTAIN TRAUMATIC COMPLICATIONS AND UNSPECIFIED INJURIES": (
        "(958-959) TRAUMATIC COMPLICATIONS"
    ),
    "(960-979) POISONING BY DRUGS, MEDICINAL AND BIOLOGICAL SUBSTANCES": (
        "(960-979) POISONING"
    ),
    "(980-989) TOXIC EFF. OF SUBSTANCES CHIEFLY NONMED. AS TO SOURCE": (
        "(980-989) TOXIC EFFECTS NON MEDICAL"
    ),
    "(990-995) OTHER AND UNSPECIFIED EFFECTS OF EXTERNAL CAUSES": (
        "(990-998) OTHER"
    ),
    "(E800-E809) RAILWAY ACCIDENTS": (
        "(E800-E809) RAILWAY ACCIDENTS"
    ),
    "(E810-E819) MOTOR VEHICLE TRAFFIC ACCIDENTS": (
        "(E810-E819) MOTOR VEHICLE TRAFFIC ACCIDENTS"
    ),
    "(E820-E825) MOTOR VEHICLE NON-TRAFFIC ACCIDENTS": (
        "(E820-E825) MOTOR VEHICLE NON-TRAFFIC ACCIDENTS"
    ),
    "(E826-E829) OTHER ROAD VEHICLE ACCIDENTS": (
        "(E826-E829) OTHER ROAD VEHICLE ACCIDENTS"
    ),
    "(E830-E839) WATER TRANSPORT ACCIDENTS": (
        "(E830-E839) WATER TRANSPORT ACCIDENTS"
    ),
    "(E840-E845) AIR AND SPACE TRANSPORT ACCIDENTS": (
        "(E840-E845) AIR AND SPACE TRANSPORT ACCIDENTS"
    ),
    "(E846-E849) VEHICLE ACCIDENTS, NOT ELSEWHERE CLASSIFIABLE": (
        "(E846-E849) VEHICLE ACCIDENTS, NOT ELSEWHERE CLASSIFIABLE"
    ),
    "(E850-E858) ACCIDENTAL POIS BY DRUGS, MED SUBSTANCES, AND BIOLOGICALS": (
        "(E850-E858) ACCIDENTAL POIS BY DRUGS, MED SUBSTANCES, AND BIOLOGICALS"
    ),
    "(E860-E869) ACCIDENTAL POIS BY OTHR SOL AND LIQ SUB, GASES, AND VAPORS": (
        "(E860-E869) ACCIDENTAL POIS BY OTHR SOL AND LIQ SUB, GASES, AND VAPORS"
    ),
    "(E870-E876) MISADVENTURES TO PATIENTS DURING SURGICAL AND MEDICAL CARE": (
        "(E870-E876) MISADVENTURES TO PATIENTS DURING SURGICAL AND MEDICAL CARE"
    ),
    "(E878-E879) SURG AND MEDICAL PROC AS THE CAUSE OF ABNORMAL REACTION": (
        "(E878-E879) SURG AND MEDICAL PROC AS THE CAUSE OF ABNORMAL REACTION"
    ),
    "(E880-E888) ACCIDENTAL FALLS": (
        "(E880-E888) ACCIDENTAL FALLS"
    ),
    "(E890-E899) ACCIDENTS CAUSED BY FIRE AND FLAMES": (
        "(E890-E899) ACCIDENTS CAUSED BY FIRE AND FLAMES"
    ),
    "(E900-E909) ACCIDENTS DUE TO NATURAL AND ENVIRONMENTAL FACTORS": (
        "(E900-E909) ACCIDENTS DUE TO NATURAL AND ENVIRONMENTAL FACTORS"
    ),
    "(E910-E915) ACCIDENTS CAUSED BY SUBMERSION, SUFFOC., & FOREIGN BODIES": (
        "(E910-E915) ACCIDENTS CAUSED BY SUBMERSION, SUFFOC., & FOREIGN BODIES"
    ),
    "(E916-E929) OTHER ACCIDENTS": (
        "(E916-E929) OTHER ACCIDENTS"
    ),
    "(E930-E949) DRGS, MEDIC & BIOL. SUBST CAUS ADVRS EFFCTS IN THERAP USE": (
        "(E930-E949) DRGS, MEDIC & BIOL. SUBST CAUS ADVRS EFFCTS IN THERAP USE"
    ),
    "(E950-E959) SUICIDE AND SELF-INFLICTED INJURY": (
        "(E950-E959) SUICIDE AND SELF-INFLICTED INJURY"
    ),
    "(E960-E969) HOMICIDE AND INJURY PURPOSELY INFLICTED BY OTHER PERSONS": (
        "(E960-E969) HOMICIDE AND INJURY PURPOSELY INFLICTED BY OTHER PERSONS"
    ),
    "(E970-E978) LEGAL INTERVENTION": (
        "(E970-E978) LEGAL INTERVENTION"
    ),
    "(E980-E989) INJ UNDET WHETHER ACCIDENTALLY OR PURPOSELY INFLICTED": (
        "(E980-E989) INJ UNDET WHETHER ACCIDENTALLY OR PURPOSELY INFLICTED"
    ),
    "(E990-E999) INJURY RESULTING FROM OPERATION OF WAR": (
        "(E990-E999) INJURY RESULTING FROM OPERATION OF WAR"
    ),
}

SPECIFIC_INJURY_GENERAL_CANDIDATES = {
    "(870-897) OPEN WOUND": (
        "(870-879) OPEN WOUND HEAD NECK TRUNK",
        "(880-887) OPEN WOUND UPPER LIMB",
        "(890-897) OPEN WOUND LOWER LIMB",
    ),
    "(996-999) COMPLIC. OF SURG. AND MED. CARE, NOT ELSEWHERE CLASSIFIED": (
        "(990-998) OTHER",
        "(999-999) UNKNOWN",
    ),
}

BODY_PART_CODES = {
    "450 SHOULDER": "Shoulder/Collarbone",
    "830 MUSCULO SKELETAL SYSTEM": "Bones/Joints/Muscles",
    "840 NERVOUS SYSTEM": "Nerves",
    "305 ARM NOT SPECIFIED": "Arm",
    "810 DIGESTIVE SYSTEM": "Stomach/Digestive",
    "310 ARM ABOVE WRIST": "Arm",
    "820 EXCRETORY SYSTEM": "Kidneys/Bladder",
    "805 CIRCULATORY SYSTEM": "Heart/Blood Vessels",
    "498 TRUNK MULTIPLE PARTS": "Multiple Trunk Areas",
    "398 UPPER EXTREMITIES": "Arms/Hands",
    "801 BODY SYSTEM NOT SPECIFIED": "Unspecified Body System",
    "330 HAND": "Hand",
    "340 FINGERS": "Fingers",
    "319 ARM": "Arm",
    "430 CHEST": "Chest/Lungs",
    "320 WRIST": "Wrist",
    "440 HIPS/PELVIS": "Hip/Pelvis",
    "315 FOREARM": "Forearm",
    "410 ABDOMEN": "Abdomen/Groin",
    "318 ARM MULTIPLE PARTS": "Multiple Arm Areas",
    "420 BACK": "Back/Spine",
    "PSY PSYCH": "Mental Health",
    "405 TRUNK NOT SPECIFIED": "Trunk/Torso",
    "210 NECK": "Neck",
    "220 THROAT": "Throat",
    "540 TOES": "Toes",
    "598 LOWER EXTREMITIES MULTIPLE PARTS": "Multiple Leg Areas",
    "530 FOOT": "Foot",
    "519 LEG": "Leg",
    "520 ANKLE": "Ankle",
    "515 LOWER LEG": "Shin/Calf",
    "518 LEG MULTIPLE PARTS": "Multiple Leg Areas",
    "511 UPPER LEG": "Thigh",
    "513 KNEE": "Knee",
    "505 LOWER EXTREMITIES NOT SPECIFIED": "Leg/Foot",
    "510 LEGS ABOVE ANKLES": "Upper/Lower Leg",
    "198 HEAD MULTIPLE INJURY": "Multiple Head Areas",
    "146 NOSE": "Nose/Sinuses",
    "150 SCALP/SKULL": "Skull/Scalp",
    "144 MOUTH": "Mouth/Lips/Tongue",
    "145 TEETH": "Teeth",
    "313 ELBOW": "Elbow",
    "311 UPPER ARM": "Upper Arm",
    "140 FACE NOT SPECIFIED": "Face",
    "141 JAW": "Jaw/Chin",
    "124 INNER EAR": "Inner Ear/Hearing",
    "130 EYE": "Eye/Vision",
    "120 EAR NOT SPECIFIED": "Ear",
    "121 OUTER EAR": "Outer Ear",
    "110 BRAIN": "Brain",
    "880 OTHER BODY SYSTEMS": "Other System",
    "105 HEAD NOT SPECIFIED": "Head",
    "841 NERVOUS SYSTEM STRESS": "Stress-Related",
    "850 RESPIRATORY SYSTEM": "Lungs/Breathing",
}

INJURY_CODE_GUIDELINES = (
    "Always include both general_injury_code and specific_injury_code in every "
    "individual_injuries object. Both codes must describe the same documented injury. "
    "Match the explicitly documented injury description against "
    "SPECIFIC_INJURY_CODES first. Use an exact catalog value, including its range "
    "and label, only when the document supports the distinguishing injury type "
    "and anatomical details or other qualifiers required by that specific entry. "
    "Literal dropdown wording is not required when the documented meaning is clear. "
    "Prefer the narrowest supported specific entry over an overlapping broad entry. "
    "When a specific code matches, derive general_injury_code from its supplied "
    "specific-to-general relationship; do not select an unrelated general category. "
    "For entries spanning multiple general categories, select a general candidate "
    "only when the injury's documented details support that candidate. If no "
    "compatible general parent can be established, retain the supported "
    "specific_injury_code and return general_injury_code as null; do not guess "
    "a parent or discard the injury. Omit an injury object only when both "
    "general_injury_code and specific_injury_code are null. If the description "
    "is broad enough for a general category "
    "but does not support any specific entry, return the general code and "
    "specific_injury_code as null. Never reverse-map a general code to a specific "
    "code or invent anatomy or qualifiers to obtain a specific match. Match using "
    "the source document, not the generic catalog text appended to "
    "injury_description. A general-only fracture is not enough to select skull, "
    "neck/trunk, upper-limb, or lower-limb fracture; a documented tibia fracture "
    "supports (820-829) FRACTURE OF LOWER LIMB and derives (800-829) FRACTURE. "
    "When a specific entry shares the general category's range and requires no "
    "additional details, it may match independently from the documented description, "
    "but must not be selected merely because the general code was populated. "
)

# Exact UI organization-type dropdown codes and descriptions.
ORGANIZATION_TYPE_CODES = {
    "BANK": "BANK",
    "CNTO": "COUNTY OFFICE",
    "CNTY": "COUNTY",
    "CRO": "CLERK RECORDER OFFICE",
    "CRT": "COURT",
    "EMPR": "EMPLOYER",
    "HMO": "MA HMO/MCO",
    "HMS": "HMS",
    "HMSLAW": "HMS REFERRED LAW FIRM",
    "INS": "INSURANCE CO.",
    "JUR": "JURY COURT",
    "LAW": "LAW FIRM",
    "OTHR": "OTHER/UNKNOWN",
    "PRB": "PROBATE COURT",
    "PRV": "PROVIDER",
    "PSRE": "PERSONAL REP.",
    "REPA": "RESPONSIBLE PARTY",
    "RSP": "LIABLE 3RD PARTY",
    "WCAB": "WCAB OFFICE",
    "WCCAR": "WC CARRIER",
}

# Exact UI contact-type dropdown codes and descriptions (CTCNT).
CONTACT_TYPE_CODES = {
    "BNFCRY": "RECIPIENT/BENEFICIARY",
    "CLRK": "COURT CLERK",
    "CNTW": "COUNTY WORKER",
    "CNTY": "COUNTY",
    "CRT": "COURT",
    "GRDN": "GUARDIAN",
    "HMOP": "HMO CONTRACTOR",
    "INSA": "Attorney for Ins Co",
    "INSD": "INSURANCE ADJUSTER",
    "LAWD": "ATTORNEY FOR DEFENSE",
    "LAWP": "ATTORNEY FOR PLAINTIFF",
    "LGAST": "LEGAL ASSISTANT",
    "LTP1": "LIABLE 3RD PARTY",
    "OTHR": "OTHER/UNKNOWN",
    "PSRE": "PERSONAL REP",
    "RECUST": "RECORDS CUSTODIAN",
}

CONTACT_TYPE_GUIDELINES = (
    "Always include contact_type and contact_description in every contact object. "
    "Return exactly one CONTACT_TYPE_CODES key, such as LAWP, as contact_type; "
    "never return a description, job-title text, combined code/description, or list. "
    "Return the exact corresponding catalog value as contact_description. When "
    "the contact's role cannot be determined, return both fields as null; do not "
    "default to OTHR or LAWP. OTHR is allowed only when the document establishes "
    "an actual contact role that does not fit another category. "
    "Determine the represented contact's role from the document's representation "
    "statements, signature, titles, sender identity, and relationship to the case. "
    "Equivalent wording is sufficient; the dropdown label need not appear verbatim. "
    "Use organization_type as supporting context, not as a one-to-one contact-type "
    "mapping. Explicit role evidence takes precedence over organization category. "
    "For LAW or HMSLAW, use LAWP when the attorney or firm explicitly represents "
    "the injured member/plaintiff/claimant, including wording such as we represent "
    "the member in this injury claim. Use LAWD for documented defense counsel, "
    "and INSA when the attorney explicitly represents an insurance company. "
    "Prefer INSA over LAWD when the insurer representation is explicit. A law-firm "
    "name, LAW/HMSLAW organization_type, or default ATTORNEY OF RECORD contact_name "
    "alone does not establish LAWP, LAWD, or INSA. "
    "Use LGAST for a contact explicitly identified as a legal assistant, paralegal, "
    "or equivalent legal support role. With the single-contact-per-organization "
    "rule and ATTORNEY OF RECORD contact_name, classify the firm's represented "
    "attorney relationship when documented; do not replace that relationship with "
    "a staff role merely because a staff member appears in contact_note. "
    "Use INSD for an explicitly identified insurance adjuster (often INS or WCCAR), "
    "and HMOP for an explicitly identified HMO contractor; HMO organization_type "
    "alone is insufficient to establish contractor status. "
    "Use CLRK for a documented court clerk and CRT when the source contact is the "
    "court institution itself (such as CRT, PRB, or JUR organization_type). "
    "Use CNTW for a documented county worker and CNTY when the contact represents "
    "the county institution itself (such as CNTY or CNTO organization_type). "
    "Use RECUST for an explicitly identified records custodian, regardless of "
    "whether the organization is a provider, insurer, or another source. "
    "Use BNFCRY only when the source contact is the documented recipient/beneficiary "
    "or member; do not use a merely mentioned member to classify another source. "
    "Use GRDN for a documented guardian, PSRE for a documented personal or estate "
    "representative, and LTP1 for a source identified as the liable third party. "
    "Do not assume guardianship from a parent relationship, personal-representative "
    "status from a sender name, or liability from an employer/organization category. "
    "Preserve the existing source-contact and recipient-exclusion rules. "
    "Allowed contact_type codes and contact descriptions: "
    + "; ".join(
        f"{code}: {description}" for code, description in CONTACT_TYPE_CODES.items()
    )
    + ". "
)

ORGANIZATION_TYPE_GUIDELINES = (
    "Always include organization_type and organization_description in every "
    "contact_information object. Populate organization_description with the exact "
    "ORGANIZATION_TYPE_CODES description for the selected organization_type "
    "(for example LAW gives LAW FIRM, and OTHR gives OTHER/UNKNOWN). Return "
    "organization_description as null when organization_type is null. Do not "
    "substitute an organization name or invent a free-text description. "
    "Classify the source organization using its explicitly documented name, "
    "letterhead, role, or other identifying details. Return exactly one "
    "ORGANIZATION_TYPE_CODES key (for example LAW), not its description, a "
    "combined code/description, or multiple values. organization_type identifies "
    "the organization category; contact_type separately identifies the contact's "
    "relationship to the case. Do not use medical_authorization.entity_authorization "
    "as the organization type. Use LAW for a documented law firm; use HMSLAW only "
    "when an HMS referral of that law firm is explicitly documented. Use HMO for "
    "a documented Medicaid/medical-assistance HMO or managed care organization, "
    "WCCAR for an explicitly documented workers compensation carrier, and INS "
    "for another documented insurance company. Prefer a supported specialized "
    "category, such as PRB for a probate court or WCAB for a WCAB office, over "
    "a broader category. Classify each source organization independently; do not "
    "copy the incident's case_type, case_source, or a recipient organization's "
    "category into organization_type. Use OTHR when an identified organization "
    "has an unsupported or unclear category. Return null when no organization "
    "can be identified. Allowed organization_type codes and descriptions: "
    + "; ".join(
        f"{code}: {description}"
        for code, description in ORGANIZATION_TYPE_CODES.items()
    )
    + ". "
)

MEDICAL_AUTHORIZATION_GUIDELINES = (
    "Medical release extraction: Include medical_authorization inside an applicable "
    "contact_information object only when an actual medical/HIPAA release form or "
    "authorization is present in the incoming document or its attachments. A reference "
    "to a release, request for a release, or promise to send one is not a release. "
    "An unsigned or incomplete form is still a present release and must be evaluated. "
    "Associate the release only with the contact attorney or organization it explicitly "
    "covers; do not copy it to unrelated contacts. Use existing source-contact rules "
    "to identify contact records. Authorization recipients may be used to evaluate "
    "recipient_disclosed without becoming additional source contacts. "
    "When no release is present or no release applies to a contact, omit the entire "
    "medical_authorization key; do not return null or an empty object for it. "
    "When present, always return release_type and the six boolean checklist fields "
    "info_diclosed, authorizing_party_disclosed, recipient_disclosed, purpose_disclosed, "
    "comes_with_valid_expiration_date, and signed_and_date. Use JSON true/false, "
    "not strings. Evaluate all seven checklist requirements on the same release; "
    "never combine incomplete forms to construct a full release. Accept meaningful "
    "free-format wording, abbreviations, and shorthand; exact example wording is "
    "not required. Set each flag true only with clear document evidence, otherwise "
    "false, including missing, blank, illegible, or ambiguous evidence. "
    "info_diclosed: a meaningful description of the information to be disclosed, "
    "such as medical records, injury claim listings, or payment information, is "
    "provided. Preserve the exact field spelling info_diclosed. "
    "authorizing_party_disclosed: the individual/entity authorized to disclose the "
    "information is identified, for example Medicaid, HMS, or Gainwell; this is "
    "the disclosing party, not merely the member signing the authorization. "
    "recipient_disclosed: the person/entity authorized to receive the information "
    "is identified, for example the plaintiff's attorney. "
    "purpose_disclosed: the purpose of disclosure is stated, for example workers "
    "compensation. comes_with_valid_expiration_date: a meaningful, unambiguous "
    "expiration date, expiration event, or computable duration from an explicitly "
    "stated effective date is provided. An expiration event can satisfy this "
    "checklist item without yielding a calendar date; preserve the event in "
    "disclosure_notes and return disclosure_expiration_date as null when not computable. "
    "signed_and_date combines two separate mandatory requirements: the member or "
    "authorized representative actually signed the release AND a legible, "
    "unambiguous signature date is present. A blank signature line, printed name "
    "alone, or unsigned template does not establish a signature. Accept a visible "
    "handwritten or electronic signature. A signature without its date, or a date "
    "without its signature, makes signed_and_date false. "
    "Set release_type to FULL VALID RELEASE only when every checklist flag is true "
    "(all seven requirements are met); otherwise set INCOMPLETE RELEASE. These are "
    "the only allowed release_type values, evaluated using this supplied checklist. "
    "Always include disclosure_effective_date and disclosure_expiration_date whenever "
    "medical_authorization is present. Return null for an unavailable effective "
    "date or an expiration date that is neither stated nor computable from "
    "explicit inputs; never omit either date key. Optional fields: "
    "entity_authorization and disclosure_notes. Omit each unavailable optional "
    "field rather than returning null. "
    "Extract disclosure_effective_date only when the effective "
    "date is explicitly stated or the release explicitly defines the signature "
    "date as its effective date; do not substitute the incident or document date. "
    "Use quoted MM/DD/YYYY strings for both disclosure dates. If an explicit fixed "
    "expiration date and a duration are both provided, use only the fixed date. "
    "Otherwise compute disclosure_expiration_date from an explicitly documented "
    "effective date plus an explicitly documented duration, using calendar arithmetic "
    "for months/years (for example 09/30/2026 plus one year is 09/30/2027). This "
    "calculation and checklist evaluation are permitted exceptions to the general "
    "no-inference rule. Do not guess a missing date, duration, or expiration event. "
    "entity_authorization is the Entity Authorization Covers radio-button field. "
    "Its only allowed values are exactly Attorney and Organization. Populate "
    "it whenever the release identifies the attorney or organization covered "
    "as the authorized recipient or representative, even if the release is "
    "incomplete or unsigned. Select Attorney when an individual attorney, "
    "legal counsel, or plaintiff's attorney is explicitly named or designated "
    "as covered. Select Organization when the release covers a law firm, "
    "company, agency, or other organization as an entity. When a named "
    "individual attorney is the covered recipient and a firm name is also "
    "shown as that attorney's affiliation, select Attorney; when only the "
    "firm or organizational recipient is covered, select Organization. Use "
    "the release's own wording and recipient identification; the literal "
    "radio-button labels need not appear in the document. Do not classify "
    "from the disclosing insurer/Medicaid entity or contact_name's default "
    "ATTORNEY OF RECORD alone. Never return both options, alternate labels, "
    "or a boolean. Omit only when the covered entity cannot be established. "
    "Use "
    "disclosure_notes for short document-supported notes, missing checklist items, "
    "signature/date limitations, expiration events, or the basis of a computed "
    "expiration date; do not invent notes. "
)

EXTRACTION_CONFIG = {
    "model": "gpt-5.6-luna",
    "model_settings": {
        "reasoning_effort": "none",
    },
    "retries": 2,
    "extraction_rolling": {
        "enabled": True,
        "window_size": 5,
        "overlap": 2,
    },
    "instruction_template": (
        "Extract Medicaid casualty case information from documents for both "
        "new and existing cases. "
        "The input document has already been classified by an upstream AI system "
        "and will be one of the supported case creation document types only"
        "(Interim Lien, Letter of Representation, Medical/HIPAA Authorization, "
        "Case Information Form). "
        "Extract ONLY information explicitly present in the document. "
        "Do not infer, guess or fabricate values. The incident code and description "
        "mappings explicitly defined below are permitted normalization of documented "
        "information, even when the document does not print the dropdown code. "
        "Return exactly the JSON schema below and no other keys. "
        "Never omit a section or field except medical_authorization when no "
        "applicable release is present, and unavailable optional fields inside it. "
        "Never create, rename, alias, or split a schema-defined field. "
        "If a value is unavailable, return null except for the conditional medical "
        "authorization omissions defined below. Medical release checklist evaluation "
        "and expiration-date calculation from explicit inputs are permitted. "
    ),
    "general_guidelines": (
        "- Return every section and every schema-defined field, including every "
        "field inside nested objects. Each field must be present with an extracted "
        "or required default value, or null when no value is available. Never omit "
        "a field from the output except medical_authorization when no applicable "
        "release is present, and unavailable optional fields inside it. These "
        "conditional omissions take precedence over the general completeness rule.\n"
        "- STRICT SCHEMA ENFORCEMENT: Return exactly and only the sections and field "
        "names declared in the schema. Never create an additional field, even when "
        "it appears useful or more specific. Never rename, alias, move, expand, or "
        "split a declared field into new fields. Place information only in its "
        "declared field; if no declared field applies, ignore that information.\n"
        "- Do not infer missing values.\n"
        "- Never hallucinate or infer injuries or body parts. Populate "
        "individual_injuries and each injury's nested individual_body_parts only "
        "when they are explicitly "
        "and clearly stated in the document; otherwise return null.\n"
        "- Always include case_information.case_id. For a new case, return null; "
        "never generate a case identifier. For an existing case, extract the primary "
        "case identifier only when explicitly identified by labels such as Case ID, "
        "Case #, HMS Case ID, or File # in the incoming document. Return it as a "
        "string of exactly 6 or 7 digits, preserving leading zeros. Return null for "
        "more than 7 digits, fewer than 6 digits, letters, internal separators, "
        "ambiguous values, conflicting primary identifiers, or an unavailable ID. "
        "Do not truncate, pad, remove internal characters, or substitute a member "
        "ID, policy number, insurance claim number, or unrelated reference number.\n"
        "- Populate case_information.mandatory_fields.case_type with exactly one "
        "allowed dropdown value based on the documented accident or incident. If "
        "the type cannot be determined from the document, return OTHER OR UNKNOWN.\n"
        "- Populate case_information.mandatory_fields.case_source with exactly one "
        "allowed dropdown value based on the document's origin, such as its sender, "
        "letterhead, or organization. Use the case-source cues in the schema "
        "description. If the source cannot be determined, return OTHER OR UNKNOWN.\n"
        "- Populate contact_information only with contact and organization details "
        "for the party that submitted or generated the incoming document. Do not "
        "use the contact details of parties that are merely mentioned in the "
        "document.\n"
        "- Treat a person explicitly identified in the email From header, sender's "
        "signature block, attached letter signature, or submitting organization's "
        "letterhead as a source contact. If any such source contact is explicitly "
        "present, contact_information must be a list and must not be null. Include "
        "each unique source contact whose details are shown; do not include the "
        "email recipient merely because the recipient appears in the To header. Do not "
        "include any receiving, addressed-to, copied, referral, RMO, claims-routing, or "
        "other recipient organization as a source contact unless the document separately "
        "identifies that organization as the party submitting or generating the document.\n"
        "- Treat every person or organization appearing in the document's To, To:, "
        "addressed-to, recipient, or similar destination section as a receiver, not a "
        "source contact. This receiver rule takes precedence over contact details such as "
        "an email address or mailing address shown in that section.\n"
        "- Return exactly one contact_information object for each unique "
        "organization_name. Never create two contact objects for the same organization. "
        "Keep contact_name as a single string. When multiple contacts belong to the same "
        "organization, describe the additional contact names and explicitly stated job "
        "titles only in the single-string contact_note field. Never include phone numbers, "
        "email addresses, or fax numbers in contact_note.\n"
        "Normalize organization identity using the complete mailing address and contact "
        "details. Treat abbreviations such as Street/St, Suite/Ste, and state-name versus "
        "state-code variations as equivalent. Normalize organization names similarly: "
        "treat punctuation, capitalization, legal suffixes, and a trade or practice-name "
        "variant as equivalent when the address and contact details identify the same "
        "organization. Return one canonical organization_name, preferring the complete "
        "primary organization or law-firm name shown in the first line, header, logo, or "
        "letterhead branding. The primary name is more important than a longer historical "
        "or legal name. Do not use a comma-separated roster of attorneys as organization_name; "
        "place those attorney names in contact_note instead. For example, if the header says "
        "BlumeForte Attorneys at Law and a later line lists many attorneys, use "
        "BlumeForte Attorneys at Law as organization_name.\n"
        "- Populate contact_information.organization_type with exactly one "
        "allowed organization-type code based on the documented source organization, "
        "for example LAW for a law firm. Use the organization-type rules in the "
        "contact description; always include the key, using null when no "
        "organization is identifiable.\n"
        "- Populate contact_information.contact_type with an allowed contact-type "
        "code based on the documented role and supporting organization_type; "
        "populate contact_description with its exact catalog description. If "
        "the role cannot be determined, return both fields as null. Follow "
        "the detailed contact-type rules in the contact section.\n"
        "For contacts from a law firm or attorney source, set "
        "contact_information.contact_name to ATTORNEY OF RECORD by default. For all "
        "other source types, extract contact_name from the document when explicitly "
        "stated; otherwise return it as null. When the correspondence body specifically "
        "identifies a particular attorney, paralegal, or other contact, return that "
        "person's explicitly stated name in contact_information.contact_note; otherwise "
        "return contact_note as null.\n"
        "- Return the contact's complete mailing address as one string in "
        "contact_information.address. Combine all explicitly stated address lines, "
        "city, state, and postal code into that field. Do not create address_line_1, "
        "address_line_2, city, state, zip, zip_code, or any other field not defined "
        "in the schema. When multiple contacts belong to the same organization, "
        "all contact objects should reference the same normalized organization address."
        "Differences such as building names, abbreviations (Suite vs STE), punctuation, "
        "or formatting should not result in different address values.\n"
        #"- Always set case_information.mandatory_fields.case_priority to 3 - HIGH, "
        #"case_status to OPEN, case_stage to CASE PENDING CLAIMS TO ACCUMULATE, and "
        #"case_open_date to the current date in YYYY-MM-DD format. These required "
        #"defaults are exceptions to the rule to return null for information not "
        #"present in the document.\n"
        "- Return optional case_information fields when they are explicitly and "
        "unambiguously present in the incoming document; otherwise return null.\n"
        "- Normalize first_name, middle_name and last_name to UPPERCASE.\n"
        "- Normalize all dates to YYYY-MM-DD except individual_injuries.treatment_start "
        "and individual_injuries.treatment_end, plus medical_authorization."
        "disclosure_effective_date and disclosure_expiration_date, which must use "
        "MM/DD/YYYY as quoted strings.\n"
        "- Populate incident_date with the date explicitly identifying the event usually represented by Date of Incident.\n"
        "- Populate incident_information.individual_injuries only with injuries "
        "clearly listed in the document or explicitly documented incident categories "
        "matching the supplied external-cause dropdown values. Each object must contain "
        "general_injury_code, specific_injury_code, injury_description, treatment_start, "
        "treatment_end, "
        "treatment_description, and individual_body_parts. Always include "
        "individual_body_parts inside each injury object, as a list or null. "
        "Always include both injury-code keys, using null for an unsupported code. "
        "Every non-null code must exactly match its allowed dropdown value, "
        "including its code and label. Either a supported general or specific "
        "code is sufficient to retain an injury entry. "
        "Map only clearly documented information to the supplied catalog; do not infer "
        "an injury from a body part or accident narrative. Omit an injury entry only "
        "when both general_injury_code and specific_injury_code are null; return "
        "individual_injuries as null if none qualify. Do not "
        "use OTHER or UNKNOWN as a default for missing information.\n"
        + INJURY_CODE_GUIDELINES
        + "\n"
        + "- When general_injury_code is not null, populate injury_description "
        "with its description from GENERAL_INJURY_CODES, then append a short "
        "description of the injury explicitly stated in the document when available. "
        "Prefer the general-code description even when specific_injury_code is also "
        "present. When general_injury_code is null and specific_injury_code is "
        "supported, populate injury_description only with a short description "
        "of the injury explicitly stated in the document; return null if no "
        "document-supported description is available. SPECIFIC_INJURY_CODES "
        "contains code labels only; its empty values are not descriptions. Do not "
        "substitute a specific-code label for missing document details. Preserve "
        "documented anatomy, laterality, and severity in the document-derived note; "
        "do not invent details or duplicate the same description. "
        "The catalog descriptions are permitted defaults for supported codes. "
        "Populate treatment_start and treatment_end independently only from explicitly "
        "stated, unambiguous treatment dates in MM/DD/YYYY; otherwise return null. "
        "Do not substitute incident dates, document dates, or service dates unless "
        "explicitly identified as treatment start or end. Populate treatment_description "
        "only with a short description of explicitly documented treatment; otherwise "
        "return null. Never infer treatment from an injury or code description.\n"
        "- Populate individual_body_parts inside each object in "
        "incident_information.individual_injuries only with body parts explicitly "
        "associated with that injury. Never return individual_body_parts directly "
        "under incident_information. Do not copy all incident body parts to every "
        "injury or guess an association. If no supported body part can be associated "
        "with an injury, retain the injury and return its individual_body_parts as "
        "null. Each body-part object must contain "
        "body_part_code and body_part_description. body_part_code must exactly match "
        "one allowed dropdown value, including its code and label. Select the most "
        "specific code supported by the explicitly named anatomy (for example, "
        "fibula or tibia maps to 515 LOWER LEG). An anatomical location explicitly "
        "named within an injury description or incident narrative counts as a "
        "documented body part; a separate body-parts list is not required. Relate "
        "the named anatomy to the broader body regions represented by the allowed "
        "dropdown options, even when the exact anatomical term is not a dropdown "
        "label. For example, forehead relates to the face/head region. This is "
        "anatomical normalization of documented information, not inference of an "
        "undocumented injury. Select the most specific supported dropdown option "
        "and preserve the original anatomical term in body_part_description. Do "
        "not return null merely because the named anatomy has no exact dropdown "
        "label. Avoid adding overlapping broader and narrower codes for the same "
        "injury location unless distinct injured regions are documented. Do not "
        "infer a body part from a "
        "generic injury or accident narrative. Omit entries without a supported code; "
        "return that injury's individual_body_parts as null if none qualify. Populate "
        "body_part_description with the selected code's mapped description, optionally "
        "followed by a short explicitly documented body-part note such as laterality.\n"
        "- Preserve Member IDs, MA Numbers and Subscriber IDs exactly as written.\n"
        "- Never infer insurance_information.insurance_member_id. Populate it only "
        "from a health insurance card when the value is explicitly labeled Member "
        "ID or member # on that card. Never populate insurance_member_id from any other part of "
        "the document, and never copy or substitute a Subscriber ID from the card. "
        "If the health insurance card does not explicitly state a Member ID, return "
        "null for insurance_member_id.\n"
        "- When insurance_information.insurance_member_id is validly extracted "
        "and no separate member_id is directly identified elsewhere in the "
        "document, return insurance_member_id unchanged in "
        "member_information.member_id. If the document explicitly identifies a "
        "different member_id, use that value instead.\n"
        "- Preserve phone numbers and email addresses exactly as written.\n"
        "- Remove spaces and hyphens from SSN values.\n"
        "- Always include the complete SSN object with full, last_6, and last_4 "
        "keys. Populate a key only when that exact SSN representation is explicitly "
        "shown in the document; otherwise return null.\n"
        "- Minimum information for case creation consists of first_name, last_name, "
        "date_of_birth, incident_date, and at least one member identifier: a full "
        "SSN or Member ID.\n"
        "- Extract both SSN and Member ID when both are explicitly present.\n"
        "- A partial SSN does not satisfy the full-SSN requirement, but it must "
        "still be returned in the appropriate SSN field when explicitly present.\n"
        "- The output JSON must exactly match the schema below, with no undeclared "
        "sections or fields.\n"
        "MANDATORY: Output json must contain these fields first_name, last_name, "
        "date_of_birth, incident_date, member_id, and ssn.\n"
        "- Do not move fields between sections.\n"
        "- Retain the order of sections and fields defined in the schema.\n"
    ),
    "fields": [
        #{
        #    "name": "minimum_information",
        #    "type": "object",
        #    "description": (
        #        "Minimum information required for Case Creation"
        #    ),
        #    "fields": {
        #        "first_name": None,
        #        "last_name": None,
        #        "date_of_birth": None,
        #        "incident_date": None,
        #        "member_id": None,
        #        "ssn": {
        #            "full": None,
        #            "last_6": None,
        #            "last_4": None,
        #        },
        #    },
        #},
        {
            "name": "member_information",
            "type": "object",
            "description": "Member demographic information. Do not skip any fields in this section. They are all mandatory. "
            "Only extract the below fields when they are explicitly present in the document; otherwise return null. "
            "Populate member_id only from an explicitly identified Member ID; do not relabel a policy number or SSN as member_id. "
            "Do not add any additional fields to this section. ",
            "fields": {
                "member_id": None,
                "ma_number": None,
                "first_name": None,
                "middle_name": None,
                "last_name": None,
                "ssn": {
                    "full": None,
                    "last_6": None,
                    "last_4": None,
                },
                "date_of_birth": None,
                "gender": None,
                "marital_status": None,
            },
        },
        {
            "name": "incident_information",
            "type": "object",
            "description": (
                "Complete incident information explicitly stated in the document. "
                "Return incident_date in YYYY-MM-DD and incident_description as a short "
                "document-supported description, or null when unavailable. "
                "individual_injuries is a list of objects containing exactly "
                "general_injury_code, specific_injury_code, injury_description, "
                "treatment_start, treatment_end, "
                "treatment_description, and individual_body_parts. Always include "
                "individual_body_parts in every injury object as a list or null. "
                "Every entry needs at least one supported injury code. Always include "
                "general_injury_code and specific_injury_code, using null when a code "
                "is unsupported. Retain a specific-only injury with general_injury_code "
                "as null when no compatible general parent can be established. Omit "
                "an injury entry only when both codes are null, and return "
                "individual_injuries as null when none qualify. Use exact catalog "
                "values for non-null codes. If general_injury_code is not null, "
                "injury_description must start with its GENERAL_INJURY_CODES "
                "description, even when a specific code is also present. Append a "
                "short description of the injury from the document when available. "
                "If general_injury_code is null, populate injury_description only "
                "from the injury details explicitly stated in the document, or "
                "return null if no description is available. Specific-code catalog "
                "values are empty and must not be used as descriptions; do not "
                "use the code label to fabricate a missing description. Preserve "
                "documented anatomy, laterality, "
                "and severity without inventing details or duplicating descriptions. "
                "Only use explicitly documented "
                "injuries or incident categories; the external-cause codes may be "
                "selected for an explicitly documented matching incident, but must "
                "not be used to invent a medical injury. OTHER and UNKNOWN require "
                "documented support and are not defaults for missing information. "
                "Treatment dates must be explicitly identified as treatment start or "
                "end, use MM/DD/YYYY, and otherwise be null. Treatment notes must be "
                "explicitly documented; otherwise treatment_description is null. "
                "individual_body_parts belongs inside each individual_injuries "
                "object, never directly under incident_information. Include only "
                "body parts explicitly associated with the enclosing injury; do not "
                "copy all incident body parts to every injury or invent associations. "
                "Retain an otherwise supported injury with individual_body_parts "
                "set to null when no supported body part can be associated with it. "
                "Each nested individual_body_parts list contains objects with exactly "
                "body_part_code and body_part_description. Map explicitly named "
                "anatomy to the most specific supported dropdown value; for example, "
                "fibula and tibia map to 515 LOWER LEG, and ankle maps to 520 ANKLE. "
                "Recognize anatomical locations explicitly named within injury "
                "descriptions or incident narratives, even without a separate "
                "body-parts list. Relate a named anatomical subregion to the broader "
                "body regions represented in the dropdown; for example, forehead "
                "relates to the face/head region. Select the most specific supported "
                "dropdown option and retain the original anatomical term in "
                "body_part_description. This anatomical normalization is permitted "
                "and does not invent an injury. Do not return null solely because "
                "the exact anatomical term is absent from the dropdown. Avoid "
                "overlapping broader and narrower codes for the same injury location "
                "unless distinct injured regions are explicitly documented. "
                "Use the exact dropdown value as body_part_code and its mapped "
                "description as body_part_description, optionally appending a short "
                "body-part note explicitly stated in the document. Do not infer "
                "anatomy from a generic injury or accident narrative. Omit unsupported "
                "body-part entries and return the enclosing injury's "
                "individual_body_parts as null when none qualify. "
                "Example for a documented head laceration with no treatment details: "
                '{"individual_injuries": [{"general_injury_code": '
                '"(870-879) OPEN WOUND HEAD NECK TRUNK", '
                '"specific_injury_code": "(870-879) OPEN WOUND OF HEAD, NECK, AND TRUNK", '
                '"injury_description": "Open Wound (Head/Neck/Trunk) - Cut or laceration '
                'to upper body. Head laceration.", "treatment_start": null, '
                '"treatment_end": null, "treatment_description": null, '
                '"individual_body_parts": [{"body_part_code": "105 HEAD NOT SPECIFIED", '
                '"body_part_description": "Head"}]}]}. '
                + INJURY_CODE_GUIDELINES
                + " Allowed specific_injury_code values (code labels only): "
                + "; ".join(SPECIFIC_INJURY_CODES)
                + ". Specific-to-general parent relationships: "
                + "; ".join(
                    f"{specific} -> {general}"
                    for specific, general in SPECIFIC_TO_GENERAL_INJURY_CODES.items()
                )
                + ". Specific entries requiring a documented general candidate: "
                + "; ".join(
                    f"{specific} -> {' or '.join(general_codes)}"
                    for specific, general_codes in SPECIFIC_INJURY_GENERAL_CANDIDATES.items()
                )
                + ". Allowed general_injury_code values and mapped injury descriptions: "
                + "; ".join(
                    f"{code}: {description}"
                    for code, description in GENERAL_INJURY_CODES.items()
                )
                + ". Allowed body_part_code values and mapped body-part descriptions: "
                + "; ".join(
                    f"{code}: {description}"
                    for code, description in BODY_PART_CODES.items()
                )
                + "."
            ),
            "fields": {
                "incident_date": None,
                "incident_description": None,
                "individual_injuries": None,
            },
        },
        {
            "name": "case_information",
            "type": "object",
            "description": (
                "This section applies to both new and existing cases. Always include "
                "case_id directly inside case_information as a string or null. "
                "Primary case identifier from labels like Case ID, Case #, HMS Case ID, "
                "or File #. STRICT: return case_id only if it is exactly 6 or 7 digits. "
                "If more than 7 digits, fewer than 6 digits, contains letters or "
                "internal separators, or is ambiguous, return null. Preserve leading "
                "zeros; never truncate, pad, or remove internal characters. Return "
                "case_id as null for a new case or when no qualifying existing-case "
                "identifier is found. Never generate an ID or substitute a member ID, "
                "policy number, insurance claim number, or unrelated reference number. "
                "If multiple conflicting primary case identifiers appear and the "
                "correct case cannot be determined, return null. "
                "Case information section has a few mandatory fields and "
                "a few optional fields. Mandatory fields: case_type, case_source, "
                #"case_priority, case_status, case_stage, case_open_date, and county. "
                "Optional fields: service_date_from, service_date_to, "
                "insurance_claim_number, and death_date. "
                "Return optional fields only when they are explicitly and "
                "unambiguously present in the incoming document; otherwise return "
                "null. "

                "Allowed case_type values and identifying cues: ABUSE / NEGLECT "
                "(abuse, neglect, abandonment, caregiver misconduct); AUTOMOTIVE "
                "(motor vehicle accident, car or truck crash, motorcycle accident, "
                "collision, driver negligence); ASSAULT (attack, battery, fight, "
                "altercation, intentional injury); BIRTH DEFECT (congenital "
                "condition, prenatal injury, pregnancy complication, genetic or "
                "developmental abnormality); BRAIN INJURY (TBI, concussion, head "
                "injury, loss of consciousness, neurological damage); BUSINESS "
                "RELATED (NON-SLIP AND FALL) (non-fall injury at a business, "
                "negligent security, falling object, equipment malfunction); DOG "
                "BITE (dog or animal attack or bite); HIT BY VEHICLE (pedestrian or "
                "cyclist struck by a vehicle); HOMEOWNERS (residential-property "
                "injury, pool accident, unsafe stairs or railing); MALPRACTICE "
                "(medical negligence, misdiagnosis, surgical, medication, or "
                "treatment error); MASS TORTS (multiple plaintiffs, pharmaceuticals, "
                "medical devices, toxic or environmental exposure); NURSING HOME "
                "NEGLECT / INCIDENT (elder neglect, inadequate care, pressure "
                "ulcers, dehydration, malnutrition, or resident fall); PERSONAL "
                "INJURY (general bodily-injury or negligence claim that fits no "
                "more specific type); POISONING / EXPOSURE TO HARMFUL SUBSTANCES "
                "(chemical, carbon monoxide, asbestos, lead, food poisoning, or "
                "toxic fumes); PRODUCT LIABILITY (defective or unsafe product, "
                "design or manufacturing defect, failure to warn); SCHOOL BASED "
                "(school, student, playground, sports, bullying, or school-staff "
                "incident); SLIP AND FALL (wet floor, slippery surface, trip hazard, "
                "uneven pavement, ice, snow, or poor maintenance); WORK RELATED "
                "(workplace, on-the-job, occupational, construction, equipment, or "
                "workers' compensation injury); OTHER OR UNKNOWN (insufficient "
                "information or no matching type). "
                "The most common case_type values are AUTOMOTIVE, ASSAULT, DOG BITE, "
                "and SLIP AND FALL. Do not select one of these values without "
                "supporting evidence in the document. If case_type cannot be clearly "
                "determined, use OTHER OR UNKNOWN. "

                "Allowed case_source values and identifying cues: TCM (TRAUMA CODE "
                "MAILER) INITIAL OR 2ND PASS (TCM review, second pass, follow-up "
                "request, secondary review, case re-evaluation, or a questionnaire "
                "stating that records indicate recent AHCCCS injury care and "
                "requiring its return within ten days); ATTORNEY "
                "(attorney, law office, Esq., legal counsel, law firm, or "
                "representation letter or attorney-originated settlement notice); "
                "COURT (court order, judgment, probate, "
                "circuit or superior court, docket, filing, subpoena, or hearing); "
                "DMV DATA MATCH (DMV, motor-vehicle record, vehicle registration, "
                "driver record, or license information); HOSPITAL (hospital, medical "
                "center, inpatient, admission or discharge record, or patient "
                "account); INSURANCE COMPANY (AUTOMOBILE) (auto insurer or carrier, "
                "adjuster, liability coverage, PIP, or auto claim); MANAGED CARE "
                "ORGANIZATION (MCO) (MCO, managed care, health plan, care "
                "coordination, member services, or provider network); NURSING HOME "
                "(nursing home, skilled nursing facility, SNF, long-term care, or "
                "facility administrator); PERSONAL REPRESENTATIVE (personal "
                "representative, executor, administrator, estate representative, or "
                "power of attorney); RECIPIENT (Medicaid member, member statement, "
                "self-report, recipient submission, claimant letter, or beneficiary); "
                "STATE (state agency, department of health or human services, state "
                "Medicaid, state records, or AHCCCS); TRAUMA CODE ANALYSIS (trauma "
                "code, ICD-10, external-cause code, injury diagnosis, or "
                "accident-related treatment); WC AGENCY MATCH (WC match, workers' "
                "compensation agency, state WC database, or claim match); WORKERS' "
                "COMPENSATION (workers' compensation insurer, employer, WC claim, "
                "work-related injury, employer report, TPA, or compensation carrier); "
                "OTHER OR UNKNOWN (unidentified, miscellaneous, or insufficient "
                "source information). Determine case_source from evidence identifying "
                "who submitted or generated the incoming document. Do not classify it "
                "solely from parties incidentally mentioned in the document."
                "The most common case_source values are ATTORNEY, HOSPITAL, "
                "INSURANCE COMPANY, MANAGED CARE ORGANIZATION. Do not select one of these "
                "values without supporting evidence in the document. If case_source cannot "
                "be clearly determined, use OTHER OR UNKNOWN. "

                #"Always return case_priority as 3 - HIGH, case_status as OPEN, and "
                #"case_stage to CASE PENDING CLAIMS TO ACCUMULATE. Return current date "
                #"in YYYY-MM-DD format for case_open_date. County information is not"
                #"extracted from the incoming document; it is to be populated from the "
                #"county associated with the member's most recent address "
                #"in the Selected Member section."
                "Return optional fields listed in the case_information section "
                "only when they are explicitly and unambiguously present in the "
                "incoming document; otherwise return null."
            ),
            "fields": {
                "case_id": None,
                "mandatory_fields": {
                    "case_type": None,
                    "case_source": None,
                    #"case_priority": '3 - HIGH',
                    #"case_status": 'OPEN',
                    #"case_stage": 'CASE PENDING CLAIMS TO ACCUMULATE',
                    #"case_open_date": None,
                    #"county": None,
                },
                "optional_fields": {
                    "service_date_from": None,
                    "service_date_to": None,
                    "insurance_claim_number": None,
                    "death_date": None,
                },
            },
        },
        {
            # May not really be needed for case creation, but included for completeness.
            "name": "contact_information",
            "type": "list",
            "description": (
                "Populate contact_information with contact and organization "
                "information for the party that submitted or generated the incoming "
                "document. This may be a law firm, "
                "hospital, insurance company, managed care organization, or "
                "another source. Do not use the contact details of parties that are "
                "merely mentioned in the document. An email From header, sender's "
                "signature block, signed attached letter, or submitting law-firm "
                "letterhead is explicit evidence of a source contact. When such a "
                "contact is present, return a contact object and do not return null. "
                "For example, an email sender shown with a law-firm signature, email, "
                "phone, and address is a valid contact even if the email body itself "
                "is brief. Include each unique source contact, such as both the email "
                "sender and the signer of an attached representation letter, when "
                "their details are explicitly shown. Do not treat the To-header "
                "recipient as the source contact. Also exclude receiving, addressed-to, "
                "copied, referral, RMO, claims-routing, and other recipient organizations "
                "unless the document separately identifies them as the submitting or "
                "generating source. Treat every person or organization in the document's "
                "To, To:, addressed-to, recipient, or similar destination section as a "
                "receiver, never as a source contact, even when that section includes an "
                "email address or mailing address. Return organization_name, "
                "organization_type, organization_description, "
                "address, contact_type, contact_description, contact_name, "
                "contact_note, email, "
                "phone, and fax. contact_type describes the contact's "
                "relationship to the case as a dropdown code (for example LAWP); "
                "contact_description is its exact catalog description. "
                "For a law firm or attorney source, set contact_name to ATTORNEY OF "
                "RECORD by default. For all other source types, extract contact_name "
                "from the document when explicitly stated; otherwise return it as null. "
                "When the body of the correspondence specifically identifies a particular "
                "attorney, paralegal, or other contact, extract that person's explicitly "
                "stated name in contact_note; otherwise return contact_note as null. "
                "Use documented job titles as evidence for matching a supported "
                "contact-type code, but never return free-text titles in "
                "contact_type. Return null for contact_type and contact_description "
                "when the role cannot be determined. Return the complete mailing address "
                "as one string in address; never split it into additional fields. "
                "Normalize organization addresses before returning contact_information. "
                "If multiple contacts belong to the same organization and the document "
                "contains equivalent representations of the organization's mailing address "
                "(for example, one includes the building name while another omits it), "
                "return a single normalized mailing address for all contacts from that organization."
                "Use the most complete valid address by combining explicitly stated address "
                "components (street, suite/unit, city, state, and ZIP code). Do not create "
                "multiple address variants for the same organization."
                "Use the primary organization or law-firm name shown in the first line, "
                "header, logo, or letterhead branding as organization_name. The primary "
                "name is more important than a longer historical or legal name. Never use "
                "a comma-separated roster of attorneys as organization_name; put those names "
                "in contact_note. For example, if the header says BlumeForte Attorneys at "
                "Law and a later line lists many attorneys, use BlumeForte Attorneys at Law. "
                "contact_information must always be returned as a LIST of contact objects. "
                "Return exactly one object for each unique organization_name. Never return "
                "two objects for the same organization. If multiple explicitly identified "
                "contacts belong to one organization, keep one contact object, keep "
                "contact_name as a single string, and describe the additional contact "
                "names and explicitly stated job titles only in the single-string "
                "contact_note field. Never include phone numbers, email addresses, or "
                "fax numbers in contact_note.\n"
                "Every contact object MUST contain every schema-defined field except "
                "medical_authorization when no applicable release is present and "
                "unavailable optional fields inside it. Never omit "
                "contact_type or contact_description. If the role cannot be determined from the "
                "document, return null.\n"
                + ORGANIZATION_TYPE_GUIDELINES
                + CONTACT_TYPE_GUIDELINES
                + MEDICAL_AUTHORIZATION_GUIDELINES
            ),
            "fields": {
                "organization_name": None,
                "organization_type": None,
                "organization_description": None,
                "address": None,
                "contact_type": None,
                "contact_description": None,
                "contact_name": None,
                "contact_note": None,
                "email": None,
                "phone": None,
                "fax": None,
                "medical_authorization": {
                    "release_type": None,
                    "info_diclosed": None,
                    "authorizing_party_disclosed": None,
                    "recipient_disclosed": None,
                    "purpose_disclosed": None,
                    "comes_with_valid_expiration_date": None,
                    "signed_and_date": None,
                    "disclosure_effective_date": None,
                    "disclosure_expiration_date": None,
                    "entity_authorization": None,
                    "disclosure_notes": None,
                },
            },
            # Nested optional-field metadata controls omission during completion.
            "optional_fields": {
                "medical_authorization": {
                    "entity_authorization": {},
                    "disclosure_notes": {},
                },
            },
        },
        {
            # May not really be needed for case creation, but included for completeness. The downstream system will ignore this section.
            "name": "insurance_information",
            "type": "object",
            "description": (
                "Insurance information from a health insurance card, coverage "
                "overview, eligibility screen, representation letter, or another "
                "document that explicitly identifies the member's health coverage. "
                "Populate insurance_carrier with the insurance company, health plan, "
                "or Medicaid program name prominently identifying the coverage, such "
                "as Amerigroup RealSolutions or Arkansas Medicaid / AR Medicaid-PCP "
                "Referral Req. A health plan whose subrogation interest is explicitly "
                "requested in a member-specific representation letter is an insurance "
                "carrier even when no insurance card is attached. Populate member_name "
                "with the person explicitly shown "
                "as Member Name, Member, Subscriber, or the covered person. "
                "Populate subscriber_id only from a value explicitly labeled "
                "Subscriber ID, Subscriber #, or equivalent; the word Subscriber "
                "beneath a person's name identifies the member_name and is not an ID. "
                "insurance_member_id and subscriber_id are distinct fields. Never "
                "infer insurance_member_id. Populate insurance_member_id only from a "
                "health insurance card or coverage record where the value is "
                "explicitly labeled Member ID or Member #. Do not copy or substitute "
                "a Subscriber ID into insurance_member_id. If no value is explicitly "
                "identified as Member ID or Member #, return null for "
                "insurance_member_id. Populate ma_number with an explicitly shown "
                "Medicaid/MA identifier. When the coverage is explicitly a Medicaid "
                "program, a value labeled Medicaid ID, MA Number, Member ID, Member "
                "number, or program-specific beneficiary number is the ma_number. "
                "Preserve all identifiers exactly as written. Extract each available "
                "field independently; a null insurance_member_id does not require "
                "insurance_carrier, member_name, subscriber_id, or ma_number to be null."
                #"if insurance_member_id is not present on the insurance card and the rest of the document,"
                #"subscriber_id is the member ID on the minimum information section unless specified otherwise in the document."
            ),
            "fields": {
                "insurance_carrier": None,
                "member_name": None,
                "insurance_member_id": None, 
                "subscriber_id": None,
                "ma_number": None,
            },
        },
        
    ],
}
