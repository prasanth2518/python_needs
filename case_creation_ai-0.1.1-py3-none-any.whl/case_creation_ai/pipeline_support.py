from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Sequence

from case_creation_ai.configs import (
    CONTACT_TYPE_CODES,
    GENERAL_INJURY_CODES,
    SPECIFIC_INJURY_CODES,
    SPECIFIC_INJURY_GENERAL_CANDIDATES,
    SPECIFIC_TO_GENERAL_INJURY_CODES,
)
from case_creation_ai.models import ClassificationRecord, PipelineEntry


def _normalize_contact_text(value: Any) -> str:
    """Normalize organization, address, and contact identifiers for comparison."""
    if not isinstance(value, str):
        return ""
    normalized = re.sub(r"[^a-z0-9 ]+", " ", value.lower())
    replacements = {
        "street": "st",
        "road": "rd",
        "avenue": "ave",
        "boulevard": "blvd",
        "drive": "dr",
        "suite": "ste",
        "fort worth": "fortworth",
        "texas": "tx",
    }
    for source, replacement in replacements.items():
        normalized = re.sub(rf"\b{re.escape(source)}\b", replacement, normalized)
    return re.sub(r"\s+", "", normalized)


def _contact_identity(contact: Mapping[str, Any]) -> set[str]:
    """Return strong identifiers used to recognize duplicate organization contacts."""
    identifiers: set[str] = set()
    for field_name in ("address", "email", "phone", "fax"):
        normalized = _normalize_contact_text(contact.get(field_name))
        if normalized:
            identifiers.add(f"{field_name}:{normalized}")
    organization = _normalize_contact_text(contact.get("organization_name"))
    if organization:
        identifiers.add(f"organization_name:{organization}")
    return identifiers


def _organization_name_score(value: Any) -> tuple[int, int]:
    """Prefer formal legal names, then the most complete name spelling."""
    normalized = _normalize_contact_text(value)
    legal_suffixes = ("llc", "pllc", "inc", "corp", "corporation", "ltd")
    has_legal_suffix = int(any(normalized.endswith(suffix) for suffix in legal_suffixes))
    return has_legal_suffix, len(normalized)


def _merge_contact_information(value: Any) -> Any:
    """Collapse duplicate organization contacts while preserving distinct details."""
    if not isinstance(value, list):
        return value

    merged: list[Dict[str, Any]] = []
    identities: list[set[str]] = []
    for raw_contact in value:
        if not isinstance(raw_contact, Mapping):
            merged.append(raw_contact)
            identities.append(set())
            continue

        contact = dict(raw_contact)
        # Schema completion can turn an empty model placeholder into an all-null
        # object. Classification labels or release flags alone are not identity.
        detail_fields = (
            "organization_name", "contact_name", "contact_note", "address",
            "email", "phone", "fax",
        )
        if not any(
            isinstance(contact.get(field), str) and contact[field].strip()
            for field in detail_fields
        ):
            continue
        identity = _contact_identity(contact)
        match_index = next(
            (
                index
                for index, existing_identity in enumerate(identities)
                if identity and existing_identity.intersection(identity)
            ),
            None,
        )
        if match_index is None:
            merged.append(contact)
            identities.append(identity)
            continue

        existing = merged[match_index]
        if _organization_name_score(contact.get("organization_name")) > _organization_name_score(
            existing.get("organization_name")
        ):
            existing["organization_name"] = contact.get("organization_name")

        for field_name, field_value in contact.items():
            if existing.get(field_name) in (None, "") and field_value not in (None, ""):
                existing[field_name] = field_value

        existing_note = existing.get("contact_note")
        new_note = contact.get("contact_note")
        if new_note and new_note != existing_note:
            if existing_note:
                existing["contact_note"] = f"{existing_note}; {new_note}"
            else:
                existing["contact_note"] = new_note

        identities[match_index].update(identity)

    return merged


def _remove_recipient_contacts(value: Any) -> Any:
    """Remove obvious recipient-only records when a submitting source is present."""
    if not isinstance(value, list) or len(value) < 2:
        return value

    recipient_pattern = re.compile(
        r"\b(?:rmo|operated\s+by|claims?\s+routing|recipient|receiver)\b",
        re.IGNORECASE,
    )
    contacts = [contact for contact in value if isinstance(contact, Mapping)]
    has_source_contact = any(
        contact.get("contact_name")
        or contact.get("contact_type")
        or contact.get("email")
        for contact in contacts
        if not recipient_pattern.search(str(contact.get("organization_name") or ""))
    )
    if not has_source_contact:
        return value

    filtered = [
        contact
        for contact in value
        if not recipient_pattern.search(str(contact.get("organization_name") or ""))
    ]
    return filtered or value


def _complete_object_fields(
    value: Any,
    field_schema: Mapping[str, Any],
    optional_fields: Mapping[str, Any] | None = None,
) -> Dict[str, Any]:
    """Complete required fields while omitting unavailable optional fields.

    optional_fields mirrors the schema hierarchy; a named field is omitted when
    absent or null, and its nested metadata applies to its child fields.
    """
    optional_fields = optional_fields or {}
    source = dict(value) if isinstance(value, Mapping) else {}
    completed: Dict[str, Any] = {}
    relocated_fields: set[str] = set()

    for field_name, nested_schema in field_schema.items():
        field_value = source.get(field_name)
        if field_name in optional_fields and field_value is None:
            continue
        if isinstance(nested_schema, Mapping):
            nested_value = (
                dict(field_value) if isinstance(field_value, Mapping) else {}
            )
            for nested_name in nested_schema:
                if nested_name in source:
                    relocated_fields.add(nested_name)
                    misplaced_value = source[nested_name]
                    if (
                        nested_value.get(nested_name) is None
                        and misplaced_value is not None
                    ):
                        nested_value[nested_name] = misplaced_value
            completed[field_name] = _complete_object_fields(
                nested_value, nested_schema, optional_fields.get(field_name)
            )
        else:
            completed[field_name] = field_value

    # Retain unexpected model output for backward compatibility. The extractor
    # prompt remains responsible for preventing undeclared fields.
    for field_name, field_value in source.items():
        if (
            field_name not in completed
            and field_name not in relocated_fields
            and not (field_name in optional_fields and field_value is None)
        ):
            completed[field_name] = field_value

    # add strict unknown-key removal here
    allowed = set(field_schema.keys())
    completed = {k: v for k, v in completed.items() if k in allowed}

    return completed


def _complete_medical_authorizations(contacts: list[Any]) -> list[Any]:
    """Derive release classification from actual JSON boolean checklist values."""
    checklist = (
        "info_diclosed", "authorizing_party_disclosed", "recipient_disclosed",
        "purpose_disclosed", "comes_with_valid_expiration_date", "signed_and_date",
    )
    completed = []
    for raw in contacts:
        if not isinstance(raw, Mapping):
            completed.append(raw)
            continue
        contact = dict(raw)
        authorization = contact.get("medical_authorization")
        if isinstance(authorization, Mapping):
            authorization = dict(authorization)
            if authorization.get("disclosure_expiration_date") == "VALID TILL CLOSURE":
                authorization["comes_with_valid_expiration_date"] = True
            authorization["release_type"] = (
                "FULL VALID RELEASE"
                if all(authorization.get(flag) is True for flag in checklist)
                else "INCOMPLETE RELEASE"
            )
            contact["medical_authorization"] = authorization
        completed.append(contact)
    return completed


def _complete_contact_types(contacts: list[Any]) -> list[Any]:
    """Keep each contact's dropdown code and description consistent."""
    completed = []
    for raw_contact in contacts:
        if not isinstance(raw_contact, Mapping):
            completed.append(raw_contact)
            continue
        contact = dict(raw_contact)
        code = contact.get("contact_type")
        if isinstance(code, str) and code in CONTACT_TYPE_CODES:
            contact["contact_description"] = CONTACT_TYPE_CODES[code]
        else:
            contact["contact_type"] = None
            contact["contact_description"] = None
        completed.append(contact)
    return completed


def _complete_injury_codes(incident: Dict[str, Any]) -> Dict[str, Any]:
    """Retain injuries with either supported code and keep code pairs compatible.

    Document evidence remains the extractor's responsibility. This only validates
    catalog membership and relationships; it never derives a specific code from a
    general code or generated injury-description text.
    """
    injuries = incident.get("individual_injuries")
    if not isinstance(injuries, list) or not injuries:
        return incident
    completed_injuries = []
    for raw_injury in injuries:
        if not isinstance(raw_injury, Mapping):
            continue
        injury = dict(raw_injury)
        general = injury.get("general_injury_code")
        injury["general_injury_code"] = (
            general if isinstance(general, str) and general in GENERAL_INJURY_CODES
            else None
        )
        specific = injury.get("specific_injury_code")
        if not isinstance(specific, str) or specific not in SPECIFIC_INJURY_CODES:
            injury["specific_injury_code"] = None
        elif specific in SPECIFIC_TO_GENERAL_INJURY_CODES:
            injury["general_injury_code"] = SPECIFIC_TO_GENERAL_INJURY_CODES[specific]
        elif injury["general_injury_code"] not in (
            SPECIFIC_INJURY_GENERAL_CANDIDATES.get(specific, ())
        ):
            # Keep the supported specific selection without guessing its parent.
            injury["general_injury_code"] = None
        if (
            injury["general_injury_code"] is None
            and injury["specific_injury_code"] is None
        ):
            continue
        description = injury.get("injury_description")
        catalog_description = GENERAL_INJURY_CODES.get(injury["general_injury_code"])
        if catalog_description:
            detail = description.strip() if isinstance(description, str) else ""
            if detail.startswith(catalog_description):
                detail = detail[len(catalog_description):].strip()
            description = catalog_description + (" " + detail if detail else "")
        if isinstance(description, str) and len(description) > 200:
            # The prompt selects useful details; this is a final length safeguard.
            # Keep whole words and the complete catalog prefix, without an ellipsis.
            shortened = description[:200]
            if not description[200].isspace() and not shortened[-1].isspace():
                shortened = shortened.rsplit(" ", 1)[0]
            description = shortened.rstrip(" ,;:-")
        injury["injury_description"] = description
        completed_injuries.append(injury)
    return {**incident, "individual_injuries": completed_injuries or None}


def _has_extracted_value(value: Any) -> bool:
    """Find non-null leaves without treating valid false/zero values as empty."""
    if isinstance(value, Mapping):
        return any(_has_extracted_value(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_has_extracted_value(item) for item in value)
    return value is not None


def complete_extraction_payload(
    payload: Mapping[str, Any], field_specs: Sequence[Mapping[str, Any]]
) -> Dict[str, Any]:
    """Materialize omitted schema fields as null in an extracted payload."""
    source = dict(payload)

    # Legacy minimum_information compatibility is intentionally disabled because
    # the active extraction schema now uses member_information exclusively.
    # minimum_information = source.get("minimum_information")
    # member_information = source.get("member_information")
    # if isinstance(minimum_information, Mapping):
    #     legacy_member_id = minimum_information.get("member_id")
    #     if legacy_member_id is not None:
    #         if not isinstance(member_information, Mapping):
    #             member_information = {}
    #         if member_information.get("member_id") is None:
    #             member_information = dict(member_information)
    #             member_information["member_id"] = legacy_member_id
    #             source["member_information"] = member_information

    completed: Dict[str, Any] = {}
    for spec in field_specs:
        name = spec.get("name")
        if not isinstance(name, str):
            continue

        value = source.get(name)
        schema = spec.get("fields")
        field_type = spec.get("type")
        if field_type in {"array", "list"} and isinstance(value, str):
            try:
                parsed_value = json.loads(value)
            except json.JSONDecodeError:
                parsed_value = value
            if isinstance(parsed_value, list):
                value = parsed_value

        if field_type == "object" and isinstance(schema, Mapping):
            completed[name] = _complete_object_fields(
                value, schema, spec.get("optional_fields")
            )
            if name == "incident_information":
                completed[name] = _complete_injury_codes(completed[name])
            elif name == "case_information" and "case_id" in schema:
                case_id = completed[name].get("case_id")
                if not (
                    isinstance(case_id, str)
                    and re.fullmatch(r"[0-9]{6,7}", case_id)
                ):
                    completed[name]["case_id"] = None
        elif field_type in {"array", "list"} and isinstance(value, list) and isinstance(
            schema, Mapping
        ):
            completed[name] = [
                _complete_object_fields(item, schema, spec.get("optional_fields"))
                if isinstance(item, Mapping)
                else item
                for item in value
            ]
            if name == "contact_information":
                completed[name] = _remove_recipient_contacts(
                    _merge_contact_information(completed[name])
                )
                completed[name] = _complete_medical_authorizations(completed[name])
                if "contact_description" in schema:
                    completed[name] = _complete_contact_types(completed[name])
        else:
            completed[name] = value

    for name, value in source.items():
        if name not in completed:
            completed[name] = value

    # add strict unknown-key removal here
    allowed = {
    spec.get("name")
    for spec in field_specs
    if isinstance(spec.get("name"), str)
    }
    completed = {k: v for k, v in completed.items() if k in allowed}

    # Omit empty top-level sections after completion and source-key retention.
    # Inspect nested leaves, but keep required/null fields inside populated sections.
    section_names = {
        spec.get("name") for spec in field_specs
        if spec.get("type") in {"object", "array", "list"}
    }
    return {
        name: value for name, value in completed.items()
        if name not in section_names or _has_extracted_value(value)
    }


def build_value_map(
    classification_records: Sequence[ClassificationRecord | Mapping[str, Any]],
    *,
    value_field: str = "type",
) -> Dict[str, str]:
    """
    Build a lookup of document path -> arbitrary value from classification records.
    Defaults to the 'type' field.
    """
    mapping: Dict[str, str] = {}
    for rec in classification_records:
        doc_path: Optional[str] = None
        value: Optional[str] = None
        if isinstance(rec, ClassificationRecord):
            doc_path = rec.path
            value = getattr(rec, value_field, None)
        else:
            doc_path = rec.get("path")
            raw_value = rec.get(value_field)
            value = str(raw_value) if raw_value is not None else None
        if doc_path and value:
            mapping[doc_path] = value
    return mapping


def prepare_entries(
    documents: Optional[Sequence[Path | str]] = None,
    base64_documents: Optional[Sequence[Any]] = None,
    *,
    image_loader: Callable[[Path], Sequence[str]],
) -> list[PipelineEntry]:
    """
    Normalize mixed inputs into entries with either a filesystem path or base64 images.

    base64_documents can be one of:
    - list[str]: list of base64 images
    - tuple(name, list[str])
    - dict with keys: name (optional), images/base64_images/data
    """
    entries: list[PipelineEntry] = []

    if documents:
        for doc in documents:
            path_obj = Path(doc)
            if path_obj.suffix.lower() in {".tif", ".tiff"}:
                entries.append(
                    PipelineEntry(
                        name=str(path_obj),
                        path=None,
                        base64_images=list(image_loader(path_obj)),
                    )
                )
                continue
            entries.append(
                PipelineEntry(name=str(path_obj), path=path_obj, base64_images=None)
            )

    if base64_documents:
        for idx, item in enumerate(base64_documents):
            name = f"base64_doc_{idx}"
            images: Optional[list[str]] = None

            if isinstance(item, dict):
                raw_name = item.get("name")
                name = str(raw_name) if raw_name else name
                raw_images = (
                    item.get("images") or item.get("base64_images") or item.get("data")
                )
                images = list(raw_images) if raw_images else None
            elif isinstance(item, (list, tuple)):
                if (
                    len(item) == 2
                    and isinstance(item[0], str)
                    and isinstance(item[1], (list, tuple))
                ):
                    name = item[0]
                    images = list(item[1])
                else:
                    images = list(item)

            if images:
                entries.append(
                    PipelineEntry(name=name, path=None, base64_images=images)
                )

    return entries


def build_agent_kwargs(
    *,
    entry: PipelineEntry,
    context: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build kwargs for classifier/extractor single-pass calls."""
    kwargs: Dict[str, Any] = {
        "document_path": entry.path,
        "context": context,
    }
    if entry.base64_images is not None:
        kwargs["base64_images"] = entry.base64_images
    return kwargs


def resolve_rolling_params(
    *,
    section: str,
    config: Mapping[str, Any],
    rolling: Optional[bool],
    window_size: Optional[int],
    overlap: Optional[int],
) -> tuple[bool, int, int]:
    """Resolve rolling-window settings from method args and config defaults."""
    if section not in {"classification", "extraction"}:
        raise ValueError(f"Unsupported rolling section: {section}")

    rolling_config = config.get(f"{section}_rolling")

    default_enabled = True
    default_window_size = 5
    default_overlap = 2

    if isinstance(rolling_config, dict):
        enabled_default = bool(rolling_config.get("enabled", default_enabled))
        window_default = int(rolling_config.get("window_size", default_window_size))
        overlap_default = int(rolling_config.get("overlap", default_overlap))
    else:
        enabled_default = default_enabled
        window_default = default_window_size
        overlap_default = default_overlap

    resolved_rolling = enabled_default if rolling is None else rolling
    resolved_window_size = window_default if window_size is None else window_size
    resolved_overlap = overlap_default if overlap is None else overlap

    if resolved_window_size <= 0:
        raise ValueError("window_size must be > 0")
    if resolved_overlap < 0:
        raise ValueError("overlap must be >= 0")
    if resolved_overlap >= resolved_window_size:
        raise ValueError("overlap must be < window_size")

    return bool(resolved_rolling), resolved_window_size, resolved_overlap
