from datetime import date
from typing import Literal

from pydantic import Field, model_validator

from cev_ai_core.doc_types import VolunteeringDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class Bucket(CamelCaseModel):
    """A single time period with associated hours data."""

    start_date: date | None = Field(
        default=None,
        description="Start date of this period (YYYY-MM-DD)",
    )
    end_date: date | None = Field(
        default=None,
        description="End date of this period (YYYY-MM-DD)",
    )
    hours: float | None = Field(
        default=None,
        description="Total hours volunteered in this period. Extract from totals if present. If no totals are shown but individual time entries exist, calculate by summing them.",
    )


Grain = Literal["monthly", "weekly", "daily", "period"]


class Allocations(CamelCaseModel):
    """Time-bucketed breakdown of volunteer hours extracted from the document."""

    grain: Grain | None = Field(
        default=None,
        description=(
            "The time grain of each bucket. Pick the coarsest grain that matches "
            "what the document actually shows, in this priority order: "
            "monthly > weekly > daily. "
            "For example, a form showing monthly totals = 'monthly'. "
            "A timesheet with weekly totals = 'weekly'. "
            "Only use 'daily' if the document has no subtotals at any coarser level. "
            "Use 'period' if the document covers a single span that does not align "
            "to any standard grain (e.g. 3 days, 5 weeks)."
        ),
    )
    buckets: list[Bucket] = Field(
        default_factory=list,
        description=(
            "Time-bucketed breakdown of volunteer hours. "
            "For single-period documents (verification letters with one date range and total hours), "
            "use one bucket covering the full period with grain 'period'. "
            "If the document states hours per recurring period (e.g., monthly hours) over a range, "
            "use one bucket per period with calendar-month boundaries. "
            "For timesheets with weekly sections, use one bucket per week."
        ),
    )


class VolunteeringExtractionOutputType(BaseExtractionSchema):
    """Documents proving unpaid volunteer or community service participation"""

    reasoning: str = Field(
        description=(
            "Think step-by-step before extracting any fields:\n"
            "1. DOCUMENT TYPE: What kind of document is this? (verification letter, timesheet, log, etc.)\n"
            "2. SUBJECT: Who is the volunteer? Extract their name exactly as written.\n"
            "3. ORGANIZATION: Who issued this document? What organization is named?\n"
            "4. DATE RANGE: What is the overall period covered? Identify explicit start/end dates.\n"
            "5. HOURS STRUCTURE: How are hours presented?\n"
            "   - Single total for the whole period (e.g. 'completed 100 hours') → grain='period', one bucket\n"
            "   - A per-month rate or monthly schedule over a multi-month range → grain='monthly', one bucket PER MONTH in the range\n"
            "   - Weekly totals → grain='weekly', one bucket per week\n"
            "   - Daily entries only (no subtotals) → grain='daily', one bucket per day\n"
            "   IMPORTANT: When a document shows a monthly schedule (e.g. '20 hours/month') and a date range spanning multiple months,\n"
            "   you MUST create one bucket for EACH month in the range, each with that month's hours.\n"
            "   This is NOT 'multiplying a rate by duration' — it is replicating the stated per-period amount across the covered period.\n"
            "6. BUCKET BOUNDARIES: For each bucket, what are the exact start/end dates?\n"
            "   - Monthly: use calendar month boundaries (1st to last day of each month)\n"
            "   - If the overall range starts/ends mid-month, use the actual start/end date for those edge months\n"
            "   - Weekly: use the actual dates shown (first entry to last entry of that week)\n"
            "   - Period: use the full date range from step 4\n"
            "7. HOURS CALCULATION: For each bucket, what is the hours value?\n"
            "   - Use the stated hours for that period (e.g. monthly hours = that value for each monthly bucket)\n"
            "   - If only individual entries exist, sum them (show the addition)\n"
            "   - NEVER extrapolate from a different grain (e.g., don't convert daily rate to monthly by multiplying × 30)\n"
            "8. SANITY CHECK: Do the buckets cover the full date range without gaps or overlaps?\n"
            "   Is there one bucket for every period unit in the range?"
        ),
        exclude=True,
    )
    document_type: VolunteeringDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    document_date: DocumentDates
    document_source: DocumentSource
    allocations: Allocations

    @model_validator(mode="after")
    def _drop_incomplete_buckets(self):
        self.allocations.buckets = [
            b
            for b in self.allocations.buckets
            if (
                b.start_date is not None
                and b.end_date is not None
                and b.hours is not None
            )
        ]
        return self
