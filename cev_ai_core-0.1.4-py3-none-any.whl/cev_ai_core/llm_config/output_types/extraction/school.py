from datetime import date
from typing import Literal

from pydantic import Field, model_validator

from cev_ai_core.doc_types import SchoolDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class Bucket(CamelCaseModel):
    """A single time period (semester/year) with associated enrollment and credit data."""

    start_date: date | None = Field(
        default=None,
        description=(
            "The start date of the current time bucket. "
            "Only extract if explicitly stated on the document — do not infer or calculate."
        ),
    )
    end_date: date | None = Field(
        default=None,
        description=(
            "The end date of the current time bucket. "
            "Only extract if explicitly stated on the document — do not infer or calculate."
        ),
    )
    credits: float | None = Field(
        default=None, description="The credit for the current time bucket"
    )
    enrollment_status: (
        Literal["full-time", "half-time", "quarter-time", "unknown"] | None
    ) = Field(
        default=None,
        description=(
            "The student's enrollment status for this time bucket. "
            "Use 'unknown' only if the document mentions enrollment but does not specify a level."
        ),
    )


class Allocations(CamelCaseModel):
    """Time-bucketed breakdown of academic enrollment extracted from the document."""

    grain: Literal["year", "semester", "unknown"] | None = Field(
        default=None,
        description=(
            "The grain of each bucket, only one grain level can exist. "
            "Use the one that makes the most sense"
        ),
    )
    buckets: list[Bucket] = Field(
        default_factory=list,
        description="The logical time bucket that we can break the document down into",
    )


class SchoolExtractionOutputType(BaseExtractionSchema):
    """Documents proving university or college enrollment"""

    document_type: SchoolDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject = Field(
        description="The student named on the document",
    )
    document_date: DocumentDates = Field(
        description=(
            "Overall date range covered by this academic document. "
            "If allocations buckets are present, startDate and endDate should span "
            "the earliest bucket start to the latest bucket end. "
            "Only extract dates that are clearly printed on the document — "
            "do not infer, calculate, or fabricate dates. "
            "For certificates of completion, use the completion/issue date as endDate "
            "and leave startDate null unless a program start date is explicitly stated."
        ),
    )
    document_source: DocumentSource = Field(
        description="The educational institution that issued this document",
    )
    allocations: Allocations = Field(
        description=(
            "Time-bucketed enrollment and credit data extracted from the document. "
            "Only populate buckets if the document explicitly provides per-period "
            "breakdowns (e.g., semester-by-semester credit hours). "
            "Leave buckets empty if the document only states aggregate totals "
            "without clear time-period boundaries."
        ),
    )

    @model_validator(mode="after")
    def _drop_incomplete_buckets(self):
        self.allocations.buckets = [
            b
            for b in self.allocations.buckets
            if (b.start_date is not None and b.end_date is not None)
        ]
        return self
