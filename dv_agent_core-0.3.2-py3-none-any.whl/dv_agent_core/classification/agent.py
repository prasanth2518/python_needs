from typing import List, Dict, Any, Optional, Callable, Union, cast
from pathlib import Path
from pydantic import BaseModel, Field, model_validator
from pydantic_ai.settings import ModelSettings
from dv_agent_core.base import DocumentAgent, build_model_settings
from dv_agent_core.utils.llm import normalize_provider


class TypeCandidate(BaseModel):
    type: str = Field(..., description="A possible classification of the document.")
    confidence: float = Field(..., description="Confidence score between 0.0 and 1.0")


class ClassifiedDocument(BaseModel):
    type: str = Field(..., description="The primary classification of the document.")
    confidence: float = Field(..., description="Confidence score between 0.0 and 1.0")
    reasoning: str = Field(..., description="Explanation for the classification.")
    possible_types: List[TypeCandidate] = Field(
        default_factory=list,
        description=(
            "Ranked list of possible document types (most likely first). "
            "Must include the primary type."
        ),
    )

    @model_validator(mode="after")
    def _ensure_possible_types(self) -> "ClassifiedDocument":
        primary = TypeCandidate(type=self.type, confidence=self.confidence)
        if not self.possible_types:
            self.possible_types = [primary]
            return self

        found_primary = False
        for idx, candidate in enumerate(self.possible_types):
            if candidate.type == self.type:
                self.possible_types[idx] = primary
                found_primary = True
                break
        if not found_primary:
            self.possible_types.insert(0, primary)
            return self

        for idx, candidate in enumerate(self.possible_types):
            if candidate.type == self.type:
                if idx != 0:
                    self.possible_types.insert(0, self.possible_types.pop(idx))
                break
        return self

class ClassificationResult(BaseModel):
    documents: List[ClassifiedDocument]

class SimpleClassifier(DocumentAgent[ClassificationResult]):
    def __init__(
        self,
        system_prompt: str,
        model: str,
        retries: int = 1,
        model_settings: Optional[ModelSettings] = None,
        tools: Optional[List[Callable]] = None,
        system_prompt_template: Optional[str] = None,
        default_base64_images: Optional[List[str]] = None,
        default_document_path: Optional[Union[str, Path]] = None,
        max_images: Optional[int] = None,
        possible_types_max: Optional[int] = 3,
        possible_types_min_confidence: float = 0.2,
        possible_types_include_all: bool = False,
        type_catalog: Optional[List[str]] = None,
        provider: str = "openai",
        provider_settings: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(
            model=model,
            system_prompt=system_prompt,
            output_type=ClassificationResult,
            image_instruction="Classify the document provided in the images.",
            retries=retries,
            model_settings=model_settings,
            tools=tools,
            system_prompt_template=system_prompt_template,
            max_images=max_images,
            provider=provider,
            provider_settings=provider_settings,
        )
        # Store default document sources from config
        self._default_base64_images = default_base64_images
        self._default_document_path = default_document_path
        self._possible_types_max = possible_types_max
        self._possible_types_min_confidence = possible_types_min_confidence
        self._possible_types_include_all = possible_types_include_all
        self._type_catalog = type_catalog or []

    def _normalize_possible_types(self, result: ClassificationResult) -> None:
        max_candidates = None if self._possible_types_include_all else self._possible_types_max
        min_confidence = 0.0 if self._possible_types_include_all else self._possible_types_min_confidence

        for doc in result.documents:
            primary = TypeCandidate(type=doc.type, confidence=doc.confidence)
            candidates = doc.possible_types or []

            # Deduplicate by type, keeping highest confidence
            by_type: Dict[str, TypeCandidate] = {}
            for cand in candidates:
                existing = by_type.get(cand.type)
                if existing is None or cand.confidence > existing.confidence:
                    by_type[cand.type] = cand

            by_type[primary.type] = primary
            if self._possible_types_include_all and self._type_catalog:
                for type_name in self._type_catalog:
                    by_type.setdefault(type_name, TypeCandidate(type=type_name, confidence=0.0))

            filtered = [c for c in by_type.values() if c.confidence >= min_confidence]
            others = [c for c in filtered if c.type != primary.type]
            catalog_index = {name: idx for idx, name in enumerate(self._type_catalog)}
            others.sort(
                key=lambda c: (-c.confidence, catalog_index.get(c.type, len(catalog_index)))
            )

            ordered = [primary] + others
            if max_candidates is not None:
                ordered = ordered[:max_candidates]

            doc.possible_types = ordered

    async def classify(
        self,
        images: Optional[List[bytes]] = None,
        *,
        document_path: Optional[Union[str, Path]] = None,
        base64_images: Optional[List[str]] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> ClassificationResult:
        """
        Classify a document from images.

        Provide ONE of the following input options (or use defaults from config):
        - images: List of raw image bytes (PNG format)
        - document_path: Path to a PDF or image file
        - base64_images: List of base64-encoded image strings

        If no input is provided, uses base64_images or document_path from config.

        Args:
            images: List of image bytes to process
            document_path: Path to PDF or image file
            base64_images: List of base64-encoded images (with or without data URI prefix)
            context: Optional dictionary for resolving ${key} placeholders in prompts

        Returns:
            ClassificationResult with document type, confidence, and reasoning
        """
        # Fall back to config defaults if no input provided
        if images is None and document_path is None and base64_images is None:
            base64_images = self._default_base64_images
            document_path = self._default_document_path

        result = await self.process_document(
            images=images,
            document_path=document_path,
            base64_images=base64_images,
            context=context
        )
        typed = cast(ClassificationResult, result)
        self._normalize_possible_types(typed)
        return typed

    async def chat(self, text: str, context: Optional[Dict[str, Any]] = None) -> ClassificationResult:
        """
        Classify text content directly.

        Args:
            text: Text content to process
            context: Optional dictionary for resolving ${key} placeholders in prompts
        """
        result = await self.process_text(text, context=context)
        typed = cast(ClassificationResult, result)
        self._normalize_possible_types(typed)
        return typed


def create_classifier(
    config: Dict[str, Any],
    model: str = "gpt-4o",
    provider: str = "openai",
    tools: Optional[List[Callable]] = None,
    provider_settings: Optional[Dict[str, Any]] = None,
) -> SimpleClassifier:
    """
    Creates a unified classification agent based on a runtime configuration.

    Args:
        config: Configuration dict with types, instruction_template, etc.
        model: Model name (default: gpt-4o)
        provider: Model provider (default: openai)
        provider_settings: Provider-specific settings (e.g., api_key, base_url)
        tools: List of tool functions to register

    Template Resolution:
        Type descriptions and other text can include ${key} placeholders
        that will be resolved at classification time using the context dict
        passed to classify() or chat().

        Example:
            config = {
                "types": [
                    {"name": "Invoice",
                     "description": "Invoices from vendors: ${allowed_vendors}"}
                ]
            }
            classifier = create_classifier(config)
            # Context resolved at classification time:
            result = await classifier.classify(images, context={"allowed_vendors": ["ACME", "Globex"]})

    Automatically adds an "Other" fallback type if not present in the config,
    ensuring documents that don't match any configured types are classified appropriately.

    Tools can be added via:
        1. config["tools"]: List of dicts with "name", "description", "function" (dotted path)
        2. tools parameter: List of callable functions
        3. After creation: classifier.add_tool(func) or @classifier.agent.tool decorator
    """
    # 1. Parse config (keep templates unresolved for runtime resolution)
    types = config.get("types", [])
    instruction_template = config.get(
        "instruction_template",
        "Classify the document based on the following catalog:\n{catalog}\n\n{fallback_instruction}"
    )

    # Override provider/model if specified in config
    provider = config.get("provider", provider)
    provider_settings = config.get("provider_settings", provider_settings)
    model = config.get("model", model)
    normalized_provider = normalize_provider(provider)
    if "model" not in config and normalized_provider != "openai" and model == "gpt-4o":
        raise ValueError(
            f"Provider '{provider}' requires an explicit model in config or via create_classifier(model=...)."
        )
    retries = config.get("retries", 1)

    # 2. Add "Other" fallback type if not present
    type_names_lower = [t.get("name", "").lower() for t in types]
    has_other = "other" in type_names_lower

    if not has_other:
        types = types.copy()  # Don't mutate the original config
        types.append({
            "name": "Other",
            "description": "Any document that does not match the categories listed above."
        })

    # 3. Generate Catalog (keep ${key} placeholders intact)
    type_catalog = [t.get("name", "Unknown") for t in types]
    catalog_parts = []
    for t in types:
        name = t.get("name", "Unknown")
        desc = t.get("description", "No description provided.")
        catalog_parts.append(f"### {name}\n{desc}")

    catalog = "\n\n".join(catalog_parts)

    # 4. Construct Prompt template with fallback instruction
    fallback_instruction = (
        "IMPORTANT: If the document does not clearly match any of the specific categories above, "
        "classify it as 'Other'. Only use the defined categories when there is a clear match."
    )
    possible_types_max = config.get("possible_types_max", 3)
    possible_types_min_confidence = config.get("possible_types_min_confidence", 0.2)
    possible_types_include_all = config.get("possible_types_include_all", False)

    if possible_types_include_all:
        possible_types_instruction = (
            "Return the primary classification in `type` and include all categories in "
            "`possible_types` with confidence scores. The first entry in `possible_types` must "
            "match `type`."
        )
    else:
        possible_types_instruction = (
            "Return the primary classification in `type` and include only the most likely alternatives "
            "in `possible_types` with confidence scores. Do not list every category—include only "
            f"likely types (max {possible_types_max}). The first entry in `possible_types` must match `type`."
        )

    # Handle templates that may or may not have {fallback_instruction}
    if "{fallback_instruction}" in instruction_template:
        system_prompt_template = instruction_template.format(
            catalog=catalog,
            fallback_instruction=f"{fallback_instruction}\n\n{possible_types_instruction}",
        )
    else:
        system_prompt_template = (
            instruction_template.format(catalog=catalog)
            + f"\n\n{fallback_instruction}\n\n{possible_types_instruction}"
        )

    # 5. Build model settings
    model_settings = build_model_settings(config.get("model_settings"))

    # 6. Resolve tools from config and/or parameter
    all_tools: List[Callable] = list(tools) if tools else []

    # Parse tools from config (Option 1)
    config_tools = config.get("tools", [])
    for tool_config in config_tools:
        tool_func = DocumentAgent.resolve_tool_function(tool_config)
        all_tools.append(tool_func)

    # 7. Extract document source from config (if provided)
    default_base64_images = config.get("base64_images")
    default_document_path = config.get("document_path")

    # 8. Get max_images limit from config
    max_images = config.get("max_images")

    # 9. Create Agent (with template stored for runtime resolution)
    return SimpleClassifier(
        system_prompt_template,
        model,
        retries=retries,
        model_settings=model_settings,
        tools=all_tools if all_tools else None,
        system_prompt_template=system_prompt_template,
        default_base64_images=default_base64_images,
        default_document_path=default_document_path,
        max_images=max_images,
        possible_types_max=possible_types_max,
        possible_types_min_confidence=possible_types_min_confidence,
        possible_types_include_all=possible_types_include_all,
        type_catalog=type_catalog,
        provider=provider,
        provider_settings=provider_settings,
    )
