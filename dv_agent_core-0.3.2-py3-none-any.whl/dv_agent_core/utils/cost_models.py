from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ModelPricing:
    input_per_million: float
    output_per_million: float


@dataclass(frozen=True)
class TokenUsage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

    @classmethod
    def from_raw(cls, raw: object) -> Optional["TokenUsage"]:
        if raw is None:
            return None

        prompt = _get_attr_or_key(raw, "prompt_tokens")
        completion = _get_attr_or_key(raw, "completion_tokens")
        if prompt is None and completion is None:
            prompt = _get_attr_or_key(raw, "input_tokens")
            completion = _get_attr_or_key(raw, "output_tokens")

        total = _get_attr_or_key(raw, "total_tokens")

        if prompt is None and completion is None and total is None:
            return None

        prompt_val = int(prompt or 0)
        completion_val = int(completion or 0)
        total_val = int(total or (prompt_val + completion_val))
        return cls(
            prompt_tokens=prompt_val,
            completion_tokens=completion_val,
            total_tokens=total_val,
        )


@dataclass(frozen=True)
class CostEstimate:
    input_cost: float
    output_cost: float
    total_cost: float


def _get_attr_or_key(raw: object, name: str) -> Optional[int]:
    if isinstance(raw, dict):
        value = raw.get(name)
    else:
        value = getattr(raw, name, None)
    return None if value is None else int(value)
