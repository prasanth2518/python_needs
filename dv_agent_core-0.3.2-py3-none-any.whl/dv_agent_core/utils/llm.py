import os
from typing import Any, Dict, Optional

from dotenv import find_dotenv, load_dotenv

import httpx
from openai import AsyncOpenAI
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

load_dotenv(find_dotenv(usecwd=True), override=False)

DEFAULT_PROVIDER = "openai"

_PROVIDER_ALIASES = {
    "openai": "openai",
    "oai": "openai",
    "google": "google-gla",
    "gemini": "google-gla",
    "gla": "google-gla",
    "google-gla": "google-gla",
    "google-vertex": "google-vertex",
    "google_vertex": "google-vertex",
    "vertex": "google-vertex",
    "vertexai": "google-vertex",
    "vertex-ai": "google-vertex",
}

_GOOGLE_PROVIDERS = {"google-gla", "google-vertex"}

ProviderSettings = Optional[Dict[str, Any]]


def normalize_provider(provider: Optional[str]) -> str:
    if not provider:
        return DEFAULT_PROVIDER
    key = provider.strip().lower()
    return _PROVIDER_ALIASES.get(key, key)

def get_httpx_client() -> httpx.AsyncClient:
    insecure = os.getenv("CEV_OPENAI_INSECURE") == "1"

    if insecure:
        return httpx.AsyncClient(verify=False)
    else:
        ca_bundle = (
            os.getenv("OPENAI_CA_BUNDLE")
            or os.getenv("SSL_CERT_FILE")
            or os.getenv("REQUESTS_CA_BUNDLE")
        )
        return httpx.AsyncClient(verify=ca_bundle) if ca_bundle else httpx.AsyncClient(verify=False)

def get_openai_client() -> AsyncOpenAI:
    return AsyncOpenAI(
        base_url=os.getenv("OPENAI_BASE_URL"),
        api_key=os.getenv("OPENAI_API_KEY"),
        http_client=get_httpx_client(),
    )

def get_google_client(provider: str = "google", provider_settings: ProviderSettings = None):
    provider_key = normalize_provider(provider)
    if provider_key not in _GOOGLE_PROVIDERS:
        raise ValueError(f"Unsupported Google provider: {provider}. Use 'google' or 'google-vertex'.")
    google_provider = _build_google_provider(provider_key, provider_settings)
    return google_provider.client


def _build_openai_provider(provider_settings: ProviderSettings) -> OpenAIProvider:
    settings = dict(provider_settings or {})
    if "openai_client" in settings:
        return OpenAIProvider(openai_client=settings["openai_client"])
    if "http_client" not in settings:
        settings["http_client"] = get_httpx_client()
    settings.setdefault("base_url", os.getenv("OPENAI_BASE_URL"))
    settings.setdefault("api_key", os.getenv("OPENAI_API_KEY"))
    return OpenAIProvider(**settings)


def _build_google_provider(provider_key: str, provider_settings: ProviderSettings):
    try:
        from pydantic_ai.providers.google import GoogleProvider
    except Exception as exc:  # pragma: no cover - only triggers if deps missing
        raise ImportError(
            "Google/Gemini support requires the 'google-genai' package. "
            "Install it and try again."
        ) from exc

    settings = dict(provider_settings or {})
    if "client" not in settings and "http_client" not in settings:
        settings["http_client"] = get_httpx_client()
    if provider_key == "google-vertex" and "vertexai" not in settings:
        settings["vertexai"] = True
    if provider_key == "google-gla" and "vertexai" not in settings:
        settings["vertexai"] = False
    return GoogleProvider(**settings)


def build_model(model_id: str, provider: str = DEFAULT_PROVIDER, provider_settings: ProviderSettings = None):
    """
    Build a pydantic_ai model for the requested provider.
    """
    provider_key = normalize_provider(provider)

    if provider_key == "openai":
        provider_obj = _build_openai_provider(provider_settings)
        return OpenAIChatModel(model_name=model_id, provider=provider_obj)

    if provider_key in _GOOGLE_PROVIDERS:
        try:
            from pydantic_ai.models.google import GoogleModel
        except Exception as exc:  # pragma: no cover - only triggers if deps missing
            raise ImportError(
                "Google/Gemini support requires the 'google-genai' package. "
                "Install it and try again."
            ) from exc
        provider_obj = _build_google_provider(provider_key, provider_settings)
        return GoogleModel(model_name=model_id, provider=provider_obj)

    raise ValueError(
        f"Unsupported provider '{provider}'. Supported: {', '.join(sorted(_PROVIDER_ALIASES))}."
    )
