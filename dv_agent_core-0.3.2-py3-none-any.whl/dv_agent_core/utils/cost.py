from typing import Mapping, Optional

from dv_agent_core.utils.cost_constants import DEFAULT_PRICING
from dv_agent_core.utils.cost_models import CostEstimate, ModelPricing, TokenUsage


def estimate_cost(
    model: str,
    usage: object,
    pricing: Optional[Mapping[str, ModelPricing]] = None,
) -> Optional[CostEstimate]:
    pricing_table = pricing or DEFAULT_PRICING
    model_pricing = pricing_table.get(model)
    if model_pricing is None:
        return None

    token_usage = TokenUsage.from_raw(usage)
    if token_usage is None:
        return None

    input_cost = (token_usage.prompt_tokens / 1_000_000) * model_pricing.input_per_million
    output_cost = (token_usage.completion_tokens / 1_000_000) * model_pricing.output_per_million
    return CostEstimate(
        input_cost=input_cost,
        output_cost=output_cost,
        total_cost=input_cost + output_cost,
    )
