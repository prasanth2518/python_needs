from dv_agent_core.utils.cost_models import ModelPricing

# Default pricing uses standard on-demand input/output rates per 1M tokens.
# Sources: OpenAI pricing (developers.openai.com) and Gemini API pricing (ai.google.dev).
# Retrieved 2026-02-12. Gemini uses the <=200k prompt tier. Models without
# output token pricing are excluded.
DEFAULT_PRICING: dict[str, ModelPricing] = {
    # OpenAI GPT-5 family (text tokens)
    "gpt-5.2": ModelPricing(input_per_million=1.75, output_per_million=14.00),
    "gpt-5.2-pro": ModelPricing(input_per_million=21.00, output_per_million=168.00),
    "gpt-5.2-chat-latest": ModelPricing(input_per_million=1.75, output_per_million=14.00),
    "gpt-5.2-codex": ModelPricing(input_per_million=1.75, output_per_million=14.00),
    "gpt-5.1": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5.1-chat-latest": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5.1-codex-max": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5.1-codex": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5.1-codex-mini": ModelPricing(input_per_million=0.25, output_per_million=2.00),
    "gpt-5": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5-chat-latest": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5-codex": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5-pro": ModelPricing(input_per_million=15.00, output_per_million=120.00),
    "gpt-5-mini": ModelPricing(input_per_million=0.25, output_per_million=2.00),
    "gpt-5-nano": ModelPricing(input_per_million=0.05, output_per_million=0.40),
    "codex-mini-latest": ModelPricing(input_per_million=1.50, output_per_million=6.00),
    "gpt-5-search-api": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    # OpenAI GPT-4.x family (text tokens)
    "gpt-4.1": ModelPricing(input_per_million=2.00, output_per_million=8.00),
    "gpt-4.1-mini": ModelPricing(input_per_million=0.40, output_per_million=1.60),
    "gpt-4.1-nano": ModelPricing(input_per_million=0.10, output_per_million=0.40),
    "gpt-4o": ModelPricing(input_per_million=2.50, output_per_million=10.00),
    "gpt-4o-mini": ModelPricing(input_per_million=0.15, output_per_million=0.60),
    "gpt-4o-2024-05-13": ModelPricing(input_per_million=5.00, output_per_million=15.00),
    # OpenAI realtime/audio variants (text tokens)
    "gpt-realtime": ModelPricing(input_per_million=4.00, output_per_million=16.00),
    "gpt-realtime-mini": ModelPricing(input_per_million=0.60, output_per_million=2.40),
    "gpt-4o-realtime-preview": ModelPricing(input_per_million=5.00, output_per_million=20.00),
    "gpt-4o-mini-realtime-preview": ModelPricing(input_per_million=0.60, output_per_million=2.40),
    "gpt-audio": ModelPricing(input_per_million=2.50, output_per_million=10.00),
    "gpt-audio-mini": ModelPricing(input_per_million=0.60, output_per_million=2.40),
    "gpt-4o-audio-preview": ModelPricing(input_per_million=2.50, output_per_million=10.00),
    "gpt-4o-mini-audio-preview": ModelPricing(input_per_million=0.15, output_per_million=0.60),
    # OpenAI reasoning models (text tokens)
    "o1": ModelPricing(input_per_million=15.00, output_per_million=60.00),
    "o1-pro": ModelPricing(input_per_million=150.00, output_per_million=600.00),
    "o3-pro": ModelPricing(input_per_million=20.00, output_per_million=80.00),
    "o3": ModelPricing(input_per_million=2.00, output_per_million=8.00),
    "o3-deep-research": ModelPricing(input_per_million=10.00, output_per_million=40.00),
    "o4-mini": ModelPricing(input_per_million=1.10, output_per_million=4.40),
    "o4-mini-deep-research": ModelPricing(input_per_million=2.00, output_per_million=8.00),
    "o3-mini": ModelPricing(input_per_million=1.10, output_per_million=4.40),
    "o1-mini": ModelPricing(input_per_million=1.10, output_per_million=4.40),
    # OpenAI search/computer-use previews (text tokens)
    "gpt-4o-mini-search-preview": ModelPricing(input_per_million=0.15, output_per_million=0.60),
    "gpt-4o-search-preview": ModelPricing(input_per_million=2.50, output_per_million=10.00),
    "computer-use-preview": ModelPricing(input_per_million=3.00, output_per_million=12.00),
    # OpenAI image models (text tokens)
    "gpt-image-1.5": ModelPricing(input_per_million=5.00, output_per_million=10.00),
    "chatgpt-image-latest": ModelPricing(input_per_million=5.00, output_per_million=10.00),
    # Google Gemini models (text tokens)
    "gemini-3-pro-preview": ModelPricing(input_per_million=2.00, output_per_million=12.00),
    "gemini-3-flash-preview": ModelPricing(input_per_million=0.50, output_per_million=3.00),
    "gemini-2.5-pro": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gemini-2.5-flash": ModelPricing(input_per_million=0.30, output_per_million=2.50),
    "gemini-2.5-flash-preview-09-2025": ModelPricing(input_per_million=0.30, output_per_million=2.50),
    "gemini-2.5-flash-lite": ModelPricing(input_per_million=0.10, output_per_million=0.40),
    "gemini-2.5-flash-lite-preview-09-2025": ModelPricing(input_per_million=0.10, output_per_million=0.40),
    "gemini-2.0-flash": ModelPricing(input_per_million=0.10, output_per_million=0.40),
    "gemini-2.0-flash-lite": ModelPricing(input_per_million=0.075, output_per_million=0.30),
}
