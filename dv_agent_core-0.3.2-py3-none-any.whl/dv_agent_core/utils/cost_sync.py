from __future__ import annotations

from datetime import date
from pathlib import Path
import json
from typing import Mapping

import dv_agent_core.utils.cost_constants as cost_constants_module
from dv_agent_core.utils.cost_fetch import fetch_latest_pricing
from dv_agent_core.utils.cost_models import ModelPricing


def pricing_to_json(pricing: Mapping[str, ModelPricing]) -> str:
    payload = {
        model: {
            "input_per_million": model_pricing.input_per_million,
            "output_per_million": model_pricing.output_per_million,
        }
        for model, model_pricing in sorted(pricing.items())
    }
    return json.dumps(payload, indent=2, sort_keys=True) + "\n"


def render_cost_constants(
    pricing: Mapping[str, ModelPricing],
    *,
    retrieved_on: date | None = None,
) -> str:
    resolved_date = (retrieved_on or date.today()).isoformat()
    lines = [
        "from dv_agent_core.utils.cost_models import ModelPricing",
        "",
        "# Default pricing uses standard on-demand input/output rates per 1M tokens.",
        "# Sources: OpenAI pricing (developers.openai.com) and Gemini API pricing (ai.google.dev).",
        f"# Retrieved {resolved_date} from official pricing pages.",
        "DEFAULT_PRICING: dict[str, ModelPricing] = {",
    ]
    for model_name in sorted(pricing):
        model_pricing = pricing[model_name]
        lines.append(
            f'    "{model_name}": ModelPricing('
            f"input_per_million={model_pricing.input_per_million!r}, "
            f"output_per_million={model_pricing.output_per_million!r}"
            "),"
        )
    lines.append("}")
    return "\n".join(lines) + "\n"


def get_default_cost_constants_path() -> Path:
    return Path(cost_constants_module.__file__).resolve()


def update_default_pricing_file(
    *,
    output_path: Path | None = None,
    timeout: float = 10.0,
    allow_fail: bool = False,
) -> Path:
    pricing = fetch_latest_pricing(timeout=timeout, allow_fail=allow_fail)
    rendered = render_cost_constants(pricing)
    target_path = output_path or get_default_cost_constants_path()
    target_path.write_text(rendered, encoding="utf-8")
    return target_path
