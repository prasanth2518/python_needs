OPENAI_PRICING_URL = "https://developers.openai.com/api/docs/pricing"
GEMINI_PRICING_URL = "https://ai.google.dev/gemini-api/docs/pricing"

GEMINI_SECTION_TITLES: dict[str, str] = {
    "gemini-3-pro-preview": "Gemini 3 Pro Preview",
    "gemini-3-flash-preview": "Gemini 3 Flash Preview",
    "gemini-2.5-pro": "Gemini 2.5 Pro",
    "gemini-2.5-flash": "Gemini 2.5 Flash",
    "gemini-2.5-flash-preview-09-2025": "Gemini 2.5 Flash Preview",
    "gemini-2.5-flash-lite": "Gemini 2.5 Flash-Lite",
    "gemini-2.5-flash-lite-preview-09-2025": "Gemini 2.5 Flash-Lite Preview",
    "gemini-2.0-flash": "Gemini 2.0 Flash",
    "gemini-2.0-flash-lite": "Gemini 2.0 Flash-Lite",
}
