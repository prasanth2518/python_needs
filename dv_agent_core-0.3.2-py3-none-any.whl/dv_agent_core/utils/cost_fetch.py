from __future__ import annotations

from html.parser import HTMLParser
import re
from typing import Callable, Iterable, Mapping, Optional

import httpx

from dv_agent_core.utils.cost_constants import DEFAULT_PRICING
from dv_agent_core.utils.cost_fetch_constants import (
    GEMINI_PRICING_URL,
    GEMINI_SECTION_TITLES,
    OPENAI_PRICING_URL,
)
from dv_agent_core.utils.cost_models import ModelPricing

_BLOCK_TAGS = {
    "p",
    "br",
    "div",
    "li",
    "tr",
    "th",
    "td",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
}


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:  # noqa: D401
        if tag in _BLOCK_TAGS:
            self._parts.append("\n")

    def handle_data(self, data: str) -> None:
        if data:
            self._parts.append(data)

    def text(self) -> str:
        return "".join(self._parts)


def _html_to_text(html: str) -> str:
    parser = _TextExtractor()
    parser.feed(html)
    return parser.text()


def _normalize_lines(text: str) -> list[str]:
    lines: list[str] = []
    for raw in text.splitlines():
        line = " ".join(raw.strip().split())
        if line:
            lines.append(line)
    return lines


def _find_line(lines: list[str], target: str, start: int = 0) -> Optional[int]:
    for idx in range(start, len(lines)):
        if lines[idx] == target:
            return idx
    return None


def _extract_section(lines: list[str], title: str) -> list[str]:
    start = _find_line(lines, title)
    if start is None:
        return []
    section: list[str] = []
    for line in lines[start + 1 :]:
        if line.startswith("Gemini ") and line != title:
            break
        section.append(line)
    return section


def _first_dollar_amount(line: str) -> Optional[float]:
    match = re.search(r"\$(\d+(?:\.\d+)?)", line)
    if not match:
        return None
    return float(match.group(1))


def parse_openai_standard_text_pricing(text: str) -> dict[str, ModelPricing]:
    lines = _normalize_lines(text)
    start = _find_line(lines, "Text tokens")
    if start is None:
        return {}
    standard = _find_line(lines, "Standard", start=start)
    if standard is None:
        return {}

    pricing: dict[str, ModelPricing] = {}
    for line in lines[standard + 1 :]:
        if line in {"Priority", "Audio tokens", "Video", "Image tokens", "Fine-tuning"}:
            break
        if line.startswith("Model "):
            continue
        if "$" not in line:
            continue
        if line.rstrip().endswith("-"):
            continue

        model, rest = line.split("$", 1)
        model = model.strip()
        if not model:
            continue

        numbers = re.findall(r"\d+(?:\.\d+)?", rest)
        if len(numbers) < 2:
            continue
        input_price = float(numbers[0])
        output_price = float(numbers[-1])
        pricing[model] = ModelPricing(
            input_per_million=input_price,
            output_per_million=output_price,
        )

    return pricing


def parse_gemini_standard_pricing(text: str) -> dict[str, ModelPricing]:
    lines = _normalize_lines(text)
    pricing: dict[str, ModelPricing] = {}
    for model_id, title in GEMINI_SECTION_TITLES.items():
        section = _extract_section(lines, title)
        if not section:
            continue

        input_line = next((line for line in section if line.startswith("Input price")), None)
        output_line = next((line for line in section if line.startswith("Output price")), None)
        if not input_line or not output_line:
            continue

        input_price = _first_dollar_amount(input_line)
        output_price = _first_dollar_amount(output_line)
        if input_price is None or output_price is None:
            continue

        pricing[model_id] = ModelPricing(
            input_per_million=input_price,
            output_per_million=output_price,
        )

    return pricing


def _fetch_url(url: str, client: Optional[httpx.Client], timeout: float) -> str:
    if client is None:
        response = httpx.get(url, timeout=timeout)
    else:
        response = client.get(url, timeout=timeout)
    response.raise_for_status()
    return response.text


def fetch_openai_standard_text_pricing(
    *,
    client: Optional[httpx.Client] = None,
    timeout: float = 10.0,
) -> dict[str, ModelPricing]:
    html = _fetch_url(OPENAI_PRICING_URL, client, timeout)
    text = _html_to_text(html)
    return parse_openai_standard_text_pricing(text)


def fetch_gemini_standard_pricing(
    *,
    client: Optional[httpx.Client] = None,
    timeout: float = 10.0,
) -> dict[str, ModelPricing]:
    html = _fetch_url(GEMINI_PRICING_URL, client, timeout)
    text = _html_to_text(html)
    return parse_gemini_standard_pricing(text)


def fetch_latest_pricing(
    *,
    base: Optional[Mapping[str, ModelPricing]] = None,
    client: Optional[httpx.Client] = None,
    timeout: float = 10.0,
    allow_fail: bool = True,
) -> dict[str, ModelPricing]:
    pricing: dict[str, ModelPricing] = dict(base or DEFAULT_PRICING)
    fetchers: Iterable[Callable[..., dict[str, ModelPricing]]] = (
        fetch_openai_standard_text_pricing,
        fetch_gemini_standard_pricing,
    )
    for fetcher in fetchers:
        try:
            pricing.update(fetcher(client=client, timeout=timeout))
        except Exception:
            if not allow_fail:
                raise
    return pricing
