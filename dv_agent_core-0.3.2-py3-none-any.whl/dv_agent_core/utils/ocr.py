import base64
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from dv_agent_core.utils.llm import get_openai_client
from dv_agent_core.utils.document import extract_document_text, load_document_as_images

class VLMOpenAIOCREngine:
    """OCR via OpenAI vision model."""

    def __init__(self, model: Optional[str] = None):
        self.model = model or os.getenv("OPENAI_MODEL") or "gpt-4o-mini"
        self.client = get_openai_client()

    def _image_content(self, image_bytes: bytes, media_type: str = "image/png") -> Dict[str, Any]:
        b64 = base64.b64encode(image_bytes).decode("utf-8")
        return {
            "type": "image_url",
            "image_url": {"url": f"data:{media_type};base64,{b64}"},
        }

    async def extract_text(self, path: Path) -> str:
        path = Path(path).expanduser()
        if not path.exists():
            raise FileNotFoundError(path)

        native_text = extract_document_text(path)
        # Use the shared document loader
        # Note: load_document_as_images currently returns PNG bytes for everything
        # so we can safely assume image/png
        try:
            images = load_document_as_images(path)
        except Exception as e:
            raise RuntimeError(f"Failed to load document for OCR: {e}")

        if not images:
            return ""

        texts: List[str] = []
        for idx, img_bytes in enumerate(images, start=1):
            page_label = f"Page {idx}"
            if native_text:
                page_label += (
                    "\nSupplemental native PDF text from the original document is available below. "
                    "Use it to recover text that may be hard to read in the rendered page image, "
                    "but do not omit text that only appears in filled form fields or annotations.\n\n"
                    f"{native_text}"
                )
            messages: List[Any] = [
                {
                    "role": "system",
                    "content": "Extract all readable text from this document image in natural reading order. Return plain text only.",
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": page_label},
                        self._image_content(img_bytes, "image/png"),
                    ],
                },
            ]

            resp = await self.client.chat.completions.create(
                model=self.model,
                messages=messages  # type: ignore[arg-type]
            )
            content = resp.choices[0].message.content if resp.choices else ""
            texts.append(content or "")

        return "\n\n".join(texts)
