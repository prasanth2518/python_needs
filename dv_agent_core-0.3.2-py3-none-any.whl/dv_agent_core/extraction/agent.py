from typing import Type, TypeVar, Dict, Any, List, Optional, Callable, Union
from pathlib import Path
from pydantic import BaseModel
from pydantic_ai.settings import ModelSettings
from dv_agent_core.models.dynamic_schema import create_dynamic_schema, generate_schema_prompt
from dv_agent_core.base import DocumentAgent, build_model_settings
from dv_agent_core.models.bbox import BBoxExtractionResult
from dv_agent_core.utils.llm import normalize_provider

T = TypeVar("T", bound=BaseModel)


class SimpleExtractor(DocumentAgent[T]):
    def __init__(
        self,
        schema: Type[T],
        model: str,
        system_prompt: str = "Extract the following information from the document.",
        retries: int = 1,
        model_settings: Optional[ModelSettings] = None,
        tools: Optional[List[Callable]] = None,
        system_prompt_template: Optional[str] = None,
        default_base64_images: Optional[List[str]] = None,
        default_document_path: Optional[Union[str, Path]] = None,
        max_images: Optional[int] = None,
        provider: str = "openai",
        provider_settings: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(
            model=model,
            system_prompt=system_prompt,
            output_type=schema,
            image_instruction="Extract the information from the document provided in the images.",
            retries=retries,
            model_settings=model_settings,
            tools=tools,
            system_prompt_template=system_prompt_template,
            max_images=max_images,
            provider=provider,
            provider_settings=provider_settings,
        )
        # Store default document sources from config
        self._default_base64_images = default_base64_images
        self._default_document_path = default_document_path

    async def extract(
        self,
        images: Optional[List[bytes]] = None,
        *,
        document_path: Optional[Union[str, Path]] = None,
        base64_images: Optional[List[str]] = None,
        context: Optional[Dict[str, Any]] = None,
        with_bboxes: bool = False,
        include_images: bool = True,
        schema_fields: Optional[List[str]] = None,
    ) -> Union[T, "BBoxExtractionResult"]:
        """
        Extract information from document images.

        Provide ONE of the following input options (or use defaults from config):
        - images: List of raw image bytes (PNG format)
        - document_path: Path to a PDF or image file
        - base64_images: List of base64-encoded image strings

        If no input is provided, uses base64_images or document_path from config.

        Args:
            images: List of image bytes to process
            document_path: Path to PDF or image file
            base64_images: List of base64-encoded images (with or without data URI prefix)
            context: Optional dictionary for resolving ${key} placeholders in prompts
            with_bboxes: If True, also return field-level bounding boxes (BBoxExtractionResult)
            include_images: When with_bboxes=True, attach rendered page images to the result for annotation
            schema_fields: Override the set of fields to localize (defaults to schema field names)

        Returns:
            Extracted data as the configured schema type, or BBoxExtractionResult when with_bboxes=True
        """
        # Fall back to config defaults if no input provided
        if images is None and document_path is None and base64_images is None:
            base64_images = self._default_base64_images
            document_path = self._default_document_path

        return await self.process_document(
            images=images,
            document_path=document_path,
            base64_images=base64_images,
            context=context,
            with_bboxes=with_bboxes,
            include_images=include_images,
            schema_fields=schema_fields,
        )

    async def extract_with_bboxes(
        self,
        images: Optional[List[bytes]] = None,
        *,
        document_path: Optional[Union[str, Path]] = None,
        base64_images: Optional[List[str]] = None,
        context: Optional[Dict[str, Any]] = None,
        include_images: bool = True,
    ) -> "BBoxExtractionResult":
        """Extract data and field-level bounding boxes.

        This is an opt-in API; it does not change the standard `extract()` output.
        """

        # Fall back to config defaults if no input provided
        if images is None and document_path is None and base64_images is None:
            base64_images = self._default_base64_images
            document_path = self._default_document_path

        return await self.process_document_with_bboxes(
            images=images,
            document_path=document_path,
            base64_images=base64_images,
            context=context,
            include_images=include_images,
        )

    async def chat(self, text: str, context: Optional[Dict[str, Any]] = None) -> T:
        """
        Extract information from text content directly.

        Args:
            text: Text content to process
            context: Optional dictionary for resolving ${key} placeholders in prompts
        """
        return await self.process_text(text, context=context)


def create_extractor(
    config: Dict[str, Any],
    model: str = "gpt-4o",
    provider: str = "openai",
    tools: Optional[List[Callable]] = None,
    provider_settings: Optional[Dict[str, Any]] = None,
) -> SimpleExtractor[BaseModel]:
    """
    Creates a unified extraction agent based on a runtime configuration.

    Args:
        config: Configuration dict with fields, instruction_template, etc.
        model: Model name (default: gpt-4o)
        provider: Model provider (default: openai)
        provider_settings: Provider-specific settings (e.g., api_key, base_url)
        tools: List of tool functions to register

    Template Resolution:
        Field descriptions and other text can include ${key} placeholders
        that will be resolved at extraction time using the context dict
        passed to extract() or chat().

        Example:
            config = {
                "instruction_template": "Extract amounts. Max allowed: ${max_amount}",
                "fields": [...]
            }
            extractor = create_extractor(config)
            # Context resolved at extraction time:
            result = await extractor.extract(images, context={"max_amount": 10000})

    Tools can be added via:
        1. config["tools"]: List of dicts with "name", "description", "function" (dotted path)
        2. tools parameter: List of callable functions
        3. After creation: extractor.add_tool(func) or @extractor.agent.tool decorator
    """
    # 1. Parse config (keep templates unresolved)
    fields_config = config.get("fields", [])
    instruction_template = config.get(
        "instruction_template",
        "Extract the following information from the document."
    )

    # Override provider/model if specified in config
    provider = config.get("provider", provider)
    provider_settings = config.get("provider_settings", provider_settings)
    model = config.get("model", model)
    normalized_provider = normalize_provider(provider)
    if "model" not in config and normalized_provider != "openai" and model == "gpt-4o":
        raise ValueError(
            f"Provider '{provider}' requires an explicit model in config or via create_extractor(model=...)."
        )
    retries = config.get("retries", 1)

    # Build a text description of fields to include in the prompt
    schema_prompt = generate_schema_prompt(fields_config)

    # Build system prompt template (with ${key} placeholders intact)
    system_prompt_template = instruction_template

    # Add general guidelines if present
    general_guidelines = config.get("general_guidelines")
    if general_guidelines:
        system_prompt_template += f"\n\nGeneral Guidelines:\n{general_guidelines}"

    system_prompt_template += f"\n\n{schema_prompt}"

    # 2. Create Schema
    schema = create_dynamic_schema(fields_config, model_name="DynamicExtractionSchema")

    # 3. Build model settings
    model_settings = build_model_settings(config.get("model_settings"))

    # 4. Resolve tools from config and/or parameter
    all_tools: List[Callable] = list(tools) if tools else []

    # Parse tools from config (Option 1)
    config_tools = config.get("tools", [])
    for tool_config in config_tools:
        tool_func = DocumentAgent.resolve_tool_function(tool_config)
        all_tools.append(tool_func)

    # 5. Extract document source from config (if provided)
    default_base64_images = config.get("base64_images")
    default_document_path = config.get("document_path")

    # 6. Get max_images limit from config
    max_images = config.get("max_images")

    # 7. Create Agent (with template stored for runtime resolution)
    return SimpleExtractor(
        schema,
        model,
        system_prompt_template,  # Use as default prompt
        retries=retries,
        model_settings=model_settings,
        tools=all_tools if all_tools else None,
        system_prompt_template=system_prompt_template,  # Store for runtime resolution
        default_base64_images=default_base64_images,
        default_document_path=default_document_path,
        max_images=max_images,
        provider=provider,
        provider_settings=provider_settings,
    )
