from typing import Any, Dict, List, Type, Optional, Union, Tuple
from pydantic import BaseModel, Field, create_model

# Helper to support dict[T] -> Dict[str, T] shorthand
class SmartDict:
    def __class_getitem__(cls, item):
        if isinstance(item, tuple):
            return dict[item]
        return dict[str, item]

TYPE_CONTEXT = {
    "str": str, "string": str,
    "int": int, "integer": int,
    "float": float, "number": float,
    "bool": bool, "boolean": bool,
    "list": list,
    "dict": SmartDict,
    "object": Any, "any": Any,
    "union": Union,
    "optional": Optional,
    "tuple": Tuple,
}

def sanitize_type(t: Any) -> Any:
    """
    Recursively replace SmartDict with dict[str, Any] in resolved types.
    """
    if t is SmartDict:
        return dict[str, Any]

    # Handle generics (list[T], dict[K,V], Union[A,B], etc.)
    origin = getattr(t, "__origin__", None)
    args = getattr(t, "__args__", None)

    if origin is not None and args:
        new_args = tuple(sanitize_type(arg) for arg in args)
        if new_args != args:
            return origin[new_args]

    return t

def get_python_type(type_str: str) -> Any:
    # Normalize
    type_str = type_str.lower().strip()

    try:
        # Safe eval with restricted context
        resolved = eval(type_str, {"__builtins__": {}}, TYPE_CONTEXT)
        return sanitize_type(resolved)
    except Exception:
        # Fallback to string for unknown types
        return str

def create_dynamic_schema(fields_config: List[Dict[str, Any]], model_name: str = "DynamicSchema") -> Type[BaseModel]:
    fields: Dict[str, Tuple[Any, Any]] = {}
    for field_cfg in fields_config:
        name = field_cfg["name"]
        desc = field_cfg.get("description", "")
        type_str = field_cfg.get("type", "string")

        py_type = get_python_type(type_str)

        # Make optional by default for extraction
        fields[name] = (Optional[py_type], Field(None, description=desc))

    field_kwargs: Dict[str, Any] = {k: v for k, v in fields.items()}
    return create_model(model_name, **field_kwargs)

def generate_schema_prompt(fields_config: List[Dict[str, Any]]) -> str:
    """
    Generates a text description of the schema for the LLM system prompt.
    """
    field_lines = []
    for f in fields_config:
        name = f.get("name")
        desc = f.get("description", "")
        f_type = f.get("type", "string")
        field_lines.append(f"- {name}: {desc}")
        field_lines.append(f"  Type: {f_type}")

    fields_text = "\n".join(field_lines)
    return f"Target Schema:\n{fields_text}\n\nEnsure the output matches the structure and types defined above. For any nested structure (such as dictionaries or lists of objects), you MUST infer the keys and internal structure from the field description."
