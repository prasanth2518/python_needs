from __future__ import annotations

from typing import Any, Iterable, List, Optional, Tuple, Union

from pydantic import BaseModel, Field


class BoundingBox(BaseModel):
    """A rectangular bounding box in pixel coordinates."""

    page_index: int = Field(..., description="0-based page index")
    x0: float = Field(..., description="Left coordinate in pixels")
    y0: float = Field(..., description="Top coordinate in pixels")
    x1: float = Field(..., description="Right coordinate in pixels")
    y1: float = Field(..., description="Bottom coordinate in pixels")
    confidence: Optional[float] = Field(None, description="0-1 confidence (optional)")


class FieldBBox(BaseModel):
    """Field-level localization for an extracted value."""

    field: str = Field(..., description="Field name from the extraction schema")
    value: Optional[str] = Field(None, description="Human-readable value string used for matching")
    boxes: List[BoundingBox] = Field(default_factory=list, description="One or more boxes covering the value")


class BBoxExtractionResult(BaseModel):
    """Wrapper for extraction output plus bounding boxes."""

    data: dict
    fields: List[FieldBBox] = Field(default_factory=list)
    images: Optional[List[bytes]] = Field(
        default=None,
        exclude=True,
        repr=False,
        description="Optional list of PNG page images used for extraction (excluded from serialization).",
    )
    document_path: Optional[str] = Field(
        default=None,
        exclude=True,
        repr=False,
        description="Optional source document path (excluded from serialization).",
    )

    def iter_boxes(self, *, page_index: Optional[int] = None) -> Iterable[Tuple[str, BoundingBox]]:
        """Yield (field_name, box) pairs, optionally filtered by page_index."""

        for field in self.fields:
            for box in field.boxes:
                if page_index is not None and box.page_index != page_index:
                    continue
                yield field.field, box

    def draw_on_image(
        self,
        image: Union[bytes, Any, None] = None,
        *,
        page_index: int = 0,
        outline: str = "red",
        width: int = 3,
        draw_labels: bool = True,
    ) -> bytes:
        """Return a PNG (bytes) with bounding boxes drawn on top.

        Args:
            image: Either PNG/JPEG bytes, a `PIL.Image.Image`, or None to use `self.images[page_index]`.
            page_index: Which page's boxes to draw.
            outline: Rectangle outline color.
            width: Rectangle stroke width.
            draw_labels: If True, draw the field name near the rectangle.
        """

        try:
            from PIL import Image as PILImage, ImageDraw  # type: ignore
        except Exception as exc:  # pragma: no cover
            raise RuntimeError(
                "Pillow is required for drawing bounding boxes. Install with `pip install pillow`."
            ) from exc

        import io

        if image is None:
            if not self.images:
                raise ValueError(
                    "No image provided and no `images` attached to this result. "
                    "Pass `image=...` or call `extract_with_bboxes(..., include_images=True)`."
                )
            try:
                image = self.images[page_index]
            except IndexError as exc:
                raise IndexError(
                    f"Requested page_index={page_index}, but only {len(self.images)} page images are attached."
                ) from exc

        if isinstance(image, (bytes, bytearray)):
            img = PILImage.open(io.BytesIO(image)).convert("RGB")
        else:
            img = image.convert("RGB")

        draw = ImageDraw.Draw(img)

        # If the model returns normalized coords in [0,1], rescale to pixels.
        coords: List[float] = []
        for _, b in self.iter_boxes(page_index=page_index):
            coords.extend([b.x0, b.y0, b.x1, b.y1])
        normalized = bool(coords) and max(coords) <= 1.5
        w, h = img.size

        for field_name, box in self.iter_boxes(page_index=page_index):
            x0, y0, x1, y1 = box.x0, box.y0, box.x1, box.y1
            if normalized:
                x0 *= w
                x1 *= w
                y0 *= h
                y1 *= h

            if x0 > x1:
                x0, x1 = x1, x0
            if y0 > y1:
                y0, y1 = y1, y0

            x0 = max(0.0, min(float(w), float(x0)))
            x1 = max(0.0, min(float(w), float(x1)))
            y0 = max(0.0, min(float(h), float(y0)))
            y1 = max(0.0, min(float(h), float(y1)))

            draw.rectangle([x0, y0, x1, y1], outline=outline, width=width)
            if draw_labels:
                draw.text((x0, max(0.0, y0 - 14.0)), field_name, fill=outline)

        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    def display_on_image(
        self,
        image: Union[bytes, Any, None] = None,
        *,
        page_index: int = 0,
        width: int = 1000,
        outline: str = "red",
        stroke_width: int = 3,
        draw_labels: bool = True,
    ) -> None:
        """Notebook helper: display image with drawn boxes (requires IPython)."""

        annotated = self.draw_on_image(
            image,
            page_index=page_index,
            outline=outline,
            width=stroke_width,
            draw_labels=draw_labels,
        )

        try:
            from IPython.display import display, Image as IPImage  # type: ignore
        except Exception as exc:  # pragma: no cover
            raise RuntimeError("IPython is required for display_on_image().") from exc

        display(IPImage(data=annotated, width=width))

    def _repr_html_(self) -> str:  # pragma: no cover
        """Notebook-friendly representation showing data and an annotated preview when possible."""

        import base64
        import html as _html
        import json

        parts: List[str] = []
        parts.append("<div style='font-family: ui-sans-serif, system-ui, sans-serif;'>")

        data_json = json.dumps(self.data, indent=2, ensure_ascii=False, default=str)
        parts.append("<details open><summary><b>Data</b></summary>")
        parts.append(f"<pre style='white-space: pre-wrap;'>{_html.escape(data_json)}</pre>")
        parts.append("</details>")

        summary = [
            {"field": f.field, "value": f.value, "boxes": len(f.boxes)}
            for f in self.fields
        ]
        summary_json = json.dumps(summary, indent=2, ensure_ascii=False, default=str)
        parts.append("<details><summary><b>Field Boxes</b></summary>")
        parts.append(f"<pre style='white-space: pre-wrap;'>{_html.escape(summary_json)}</pre>")
        parts.append("</details>")

        annotated: Optional[bytes]
        try:
            annotated = self.draw_on_image(page_index=0)
        except Exception:
            annotated = None

        if annotated:
            b64 = base64.b64encode(annotated).decode("ascii")
            parts.append("<details open><summary><b>Annotated Preview (page 0)</b></summary>")
            parts.append(f"<img src='data:image/png;base64,{b64}' style='max-width: 100%; height: auto;'/>")
            parts.append("</details>")
        elif not self.images:
            parts.append(
                "<div style='margin-top: 0.5rem; color: #666;'>"
                "<i>No source image attached; pass <code>image=...</code> to "
                "<code>draw_on_image</code>/<code>display_on_image</code>, or "
                "call <code>extract_with_bboxes(..., include_images=True)</code>.</i>"
                "</div>"
            )

        parts.append("</div>")
        return "\n".join(parts)
