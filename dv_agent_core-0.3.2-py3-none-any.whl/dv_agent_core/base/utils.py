from typing import Dict, Any, Optional, cast
from pydantic_ai.settings import ModelSettings


def build_model_settings(config: Optional[Dict[str, Any]] = None) -> Optional[ModelSettings]:
    """
    Build ModelSettings from a config dict.

    Supports standard pydantic_ai settings plus OpenAI-specific options via extra_body,
    and Google/Gemini-specific options via google_* fields.

    Config options:
        - temperature: float (0.0-2.0)
        - max_tokens: int
        - top_p: float
        - timeout: float (seconds)
        - seed: int
        - presence_penalty: float
        - frequency_penalty: float
        - stop_sequences: list[str]
        - parallel_tool_calls: bool
        - reasoning_effort: str (OpenAI gpt-5/o1 models - "none", "low", "medium", "high")
        - extra_body: dict (additional OpenAI API parameters)
        - google_safety_settings: list[dict] (Gemini safety settings)
        - google_thinking_config: dict (Gemini thinking config)
        - google_labels: dict (Gemini request labels)
        - google_video_resolution: str (Gemini video resolution)
        - google_cached_content: str (Gemini cached content resource name)
        - extra_headers: dict
    """
    if not config:
        return None

    settings: Dict[str, Any] = {}

    # Standard ModelSettings fields
    standard_fields = [
        'temperature', 'max_tokens', 'top_p', 'timeout', 'seed',
        'presence_penalty', 'frequency_penalty', 'logit_bias',
        'stop_sequences', 'parallel_tool_calls', 'extra_headers',
        'google_safety_settings', 'google_thinking_config', 'google_labels',
        'google_video_resolution', 'google_cached_content',
    ]

    for field in standard_fields:
        if field in config:
            settings[field] = config[field]

    # Handle extra_body (for OpenAI-specific params like reasoning_effort)
    extra_body = dict(config.get('extra_body', {}))

    # Convenience: allow 'reasoning_effort' at top level, map to extra_body
    if 'reasoning_effort' in config:
        extra_body['reasoning_effort'] = config['reasoning_effort']

    if extra_body:
        settings['extra_body'] = extra_body

    return cast(ModelSettings, settings) if settings else None
