import asyncio
import json
from pathlib import Path
from typing import Optional
import typer
from rich.console import Console
from rich.panel import Panel
from rich.json import JSON

from dv_agent_core import get_supported_types, get_examples, get_classification_examples, get_extraction_examples
from .helpers import run_classify, run_extract, run_chat, run_list_models

app = typer.Typer()
console = Console()

@app.command()
def types():
    """List all supported data types for extraction configuration."""
    types = get_supported_types()
    console.print(Panel("[bold blue]Supported Data Types[/bold blue]"))
    for name, py_type in types.items():
        # Format type string for better readability
        type_str = str(py_type).replace("typing.", "").replace("<class '", "").replace("'>", "")
        console.print(f"- [bold cyan]{name}[/bold cyan]: {type_str}")
    console.print("\n[dim]Note: You can also use list[<type>] (e.g., list[str]) for lists.[/dim]")

@app.command()
def examples(
    name: Optional[str] = typer.Argument(None, help="Name of the example to show details for"),
    save: bool = typer.Option(False, help="Save the example config to a file")
):
    """List available examples or show details for a specific example."""

    if name:
        examples_dict = get_examples()
        if name not in examples_dict:
            console.print(f"[red]Example '{name}' not found.[/red]")
            return

        ex = examples_dict[name]
        console.print(Panel(f"[bold blue]Example: {name}[/bold blue]"))
        console.print(f"[italic]{ex['description']}[/italic]\n")
        console.print(JSON(json.dumps(ex['config'], indent=2)))

        if save:
            filename = f"{name}.json"
            with open(filename, "w") as f:
                json.dump(ex['config'], f, indent=2)
            console.print(f"\n[green]Saved config to {filename}[/green]")
    else:
        console.print(Panel("[bold blue]Available Examples[/bold blue]"))

        console.print("\n[bold yellow]Classification[/bold yellow]")
        for key, val in get_classification_examples().items():
            console.print(f"- [bold cyan]{key}[/bold cyan]: {val['description']}")

        console.print("\n[bold yellow]Extraction[/bold yellow]")
        for key, val in get_extraction_examples().items():
            console.print(f"- [bold cyan]{key}[/bold cyan]: {val['description']}")

        console.print("\n[dim]Run 'python main.py examples <name>' to see the config.[/dim]")
        console.print("[dim]Run 'python main.py examples <name> --save' to save it to a file.[/dim]")

@app.command()
def classify(
    config: str = typer.Option(..., help="Path to JSON configuration file OR JSON string"),
    file: Optional[Path] = typer.Option(None, help="Path to PDF document (optional if defined in config)"),
):
    """Classify a document based on a configuration."""
    asyncio.run(run_classify(config, file))

@app.command()
def extract(
    config: str = typer.Option(..., help="Path to JSON configuration file OR JSON string"),
    file: Optional[Path] = typer.Option(None, help="Path to PDF document (optional if defined in config)"),
    output_dir: Optional[Path] = typer.Option(None, help="Directory to save output JSON"),
):
    """Extract information from a document based on a configuration."""
    asyncio.run(run_extract(config, file, output_dir))

@app.command()
def chat(
    config: str = typer.Option(..., help="Path to JSON configuration file OR JSON string"),
    text: str = typer.Option(..., help="Text content to process"),
):
    """Process text content using the configured agent (Classification or Extraction)."""
    asyncio.run(run_chat(config, text))

@app.command()
def models(
    provider: str = typer.Option("openai", help="Model provider (openai, google, google-vertex)"),
):
    """List available models and documentation for a provider."""
    asyncio.run(run_list_models(provider))

if __name__ == "__main__":
    app()
