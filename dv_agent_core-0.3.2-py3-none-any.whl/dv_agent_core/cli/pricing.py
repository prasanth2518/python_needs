from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from dv_agent_core.utils.cost_fetch import fetch_latest_pricing
from dv_agent_core.utils.cost_sync import pricing_to_json, render_cost_constants, update_default_pricing_file


def pricing_fetch(
    output: Annotated[Path | None, typer.Option(
        None,
        "--output",
        "-o",
        help="Write pricing JSON to a file (stdout when omitted).",
    )] = None,
    timeout: Annotated[float, typer.Option(help="HTTP timeout in seconds.")] = 10.0,
    allow_fail: Annotated[bool, typer.Option(
        False,
        "--allow-fail/--no-allow-fail",
        help="Continue even if one provider fails.",
    )] = False,
) -> None:
    pricing = fetch_latest_pricing(timeout=timeout, allow_fail=allow_fail)
    payload = pricing_to_json(pricing)
    if output is None:
        typer.echo(payload, nl=False)
        return

    output.write_text(payload, encoding="utf-8")
    typer.echo(f"Wrote {len(pricing)} pricing rows to {output}")


def pricing_update(
    output: Annotated[Path | None, typer.Option(
        None,
        "--output",
        "-o",
        help="Target path for generated cost_constants.py (defaults to package file).",
    )] = None,
    timeout: Annotated[float, typer.Option(help="HTTP timeout in seconds.")] = 10.0,
    allow_fail: Annotated[bool, typer.Option(
        False,
        "--allow-fail/--no-allow-fail",
        help="Continue even if one provider fails.",
    )] = False,
    dry_run: Annotated[bool, typer.Option(
        False,
        "--dry-run",
        help="Print generated constants content instead of writing to disk.",
    )] = False,
) -> None:
    if dry_run:
        pricing = fetch_latest_pricing(timeout=timeout, allow_fail=allow_fail)
        typer.echo(render_cost_constants(pricing), nl=False)
        return

    updated_path = update_default_pricing_file(
        output_path=output,
        timeout=timeout,
        allow_fail=allow_fail,
    )
    typer.echo(f"Updated pricing constants at {updated_path}")


def pricing_fetch_main() -> None:
    typer.run(pricing_fetch)


def pricing_update_main() -> None:
    typer.run(pricing_update)
