import json
from pathlib import Path
from typing import Optional, Dict, Any
from rich.console import Console
from rich.panel import Panel
from rich.json import JSON

from dv_agent_core import create_classifier, create_extractor
from dv_agent_core.utils.document import load_document_as_images
from dv_agent_core.utils.llm import get_openai_client, get_google_client, normalize_provider

console = Console()

def load_config(config_input: str) -> Optional[Dict[str, Any]]:
    """
    Load configuration from a file path or a JSON string.
    """
    # Try as a file path first
    path = Path(config_input)
    if path.exists() and path.is_file():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception as e:
            console.print(f"[red]Failed to read config file: {e}[/red]")
            return None

    # Try as JSON string
    try:
        return json.loads(config_input)
    except json.JSONDecodeError:
        console.print("[red]Invalid config: Input is neither a valid file path nor a valid JSON string.[/red]")
        return None

async def run_classify(config_input: str, file_path: Optional[Path]):
    config = load_config(config_input)
    if not config:
        return

    # Determine document path
    target_file = file_path
    if not target_file:
        if "document_path" in config:
            target_file = Path(config["document_path"])
        else:
            console.print("[red]No document file specified. Provide --file or add 'document_path' to config.[/red]")
            return

    if not target_file.exists():
        console.print(f"[red]Document file not found: {target_file}[/red]")
        return

    console.print(Panel(f"[bold blue]Classifying: {target_file.name}[/bold blue]"))

    # Load Document (PDF or Image)
    console.print("[dim]Loading document...[/dim]")
    try:
        images = load_document_as_images(target_file)
        console.print(f"[green]Loaded {len(images)} pages/images.[/green]")
    except Exception as e:
        console.print(f"[red]Failed to load document: {e}[/red]")
        return

    # Classify
    classifier = create_classifier(config)
    result = await classifier.classify(images)

    console.print("[bold green]Result:[/bold green]")
    console.print(JSON(result.model_dump_json(indent=2)))

async def run_extract(config_input: str, file_path: Optional[Path], output_dir: Optional[Path] = None):
    config = load_config(config_input)
    if not config:
        return

    # Determine document path
    target_file = file_path
    if not target_file:
        if "document_path" in config:
            target_file = Path(config["document_path"])
        else:
            console.print("[red]No document file specified. Provide --file or add 'document_path' to config.[/red]")
            return

    if not target_file.exists():
        console.print(f"[red]Document file not found: {target_file}[/red]")
        return

    console.print(Panel(f"[bold blue]Extracting: {target_file.name}[/bold blue]"))

    # Load Document (PDF or Image)
    console.print("[dim]Loading document...[/dim]")
    try:
        images = load_document_as_images(target_file)
        console.print(f"[green]Loaded {len(images)} pages/images.[/green]")
    except Exception as e:
        console.print(f"[red]Failed to load document: {e}[/red]")
        return

    # Extract
    extractor = create_extractor(config)
    result = await extractor.extract(images)

    console.print("[bold green]Result:[/bold green]")
    console.print(JSON(result.model_dump_json(indent=2)))

    if output_dir:
        output_dir.mkdir(parents=True, exist_ok=True)
        out_file = output_dir / f"{target_file.stem}_result.json"
        with open(out_file, "w") as f:
            f.write(result.model_dump_json(indent=2))
        console.print(f"[dim]Saved result to {out_file}[/dim]")

async def run_chat(config_input: str, text: str):
    config = load_config(config_input)
    if not config:
        return

    console.print(Panel("[bold blue]Chat Processing[/bold blue]"))
    console.print(f"[dim]Input: {text}[/dim]")

    # Determine mode based on config
    agent: Any
    if "types" in config:
        console.print("[dim]Mode: Classification[/dim]")
        agent = create_classifier(config)
        result = await agent.chat(text)
    elif "fields" in config:
        console.print("[dim]Mode: Extraction[/dim]")
        agent = create_extractor(config)
        result = await agent.chat(text)
    else:
        console.print("[red]Invalid config: Must contain 'types' (classification) or 'fields' (extraction).[/red]")
        return

    console.print("[bold green]Result:[/bold green]")
    console.print(JSON(result.model_dump_json(indent=2)))

async def run_list_models(provider: str = "openai"):
    """
    List available models for a provider and show documentation link.
    """
    try:
        provider_key = normalize_provider(provider)
        if provider_key == "openai":
            client = get_openai_client()
            openai_models = await client.models.list()
            console.print(Panel("[bold blue]Available OpenAI Models[/bold blue]"))

            # Sort models for better readability
            model_ids = sorted([m.id for m in openai_models.data])

            for model_id in model_ids:
                console.print(f"- {model_id}")

            console.print("\n[bold blue]Documentation[/bold blue]")
            console.print("For more information about models, visit: [link=https://platform.openai.com/docs/models]https://platform.openai.com/docs/models[/link]")
        elif provider_key in {"google-gla", "google-vertex"}:
            client = get_google_client(provider)
            google_models: list[Any] = list(client.models.list())
            console.print(Panel("[bold blue]Available Gemini Models[/bold blue]"))

            model_names = sorted({m.name for m in google_models if getattr(m, "name", None)})
            for model_name in model_names:
                console.print(f"- {model_name}")
        else:
            console.print(f"[red]Unsupported provider: {provider}[/red]")
    except Exception as e:
        console.print(f"[red]Failed to list models: {e}[/red]")
