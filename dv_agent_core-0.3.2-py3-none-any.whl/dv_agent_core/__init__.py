"""
DV Agent Core Library
=====================

A unified library for document classification and extraction using Large Language Models (LLMs).
This library provides a high-level, type-safe interface for processing documents based on
runtime JSON configurations.

Key Features:
-------------
*   **Dynamic Configuration**: Define classification catalogs and extraction schemas in JSON.
*   **Type Safety**: Enforces strict data types (str, float, int, bool, list, dict) on LLM outputs.
*   **Robustness**: Built on `pydantic-ai` for reliable LLM interaction and validation.
*   **Extensibility**: Easily adaptable to new document types without code changes.

Usage:
------

### Classification

```python
from dv_agent_core import create_classifier

config = {
    "types": [
        {"name": "Invoice", "description": "A bill for goods or services"},
        {"name": "Contract", "description": "A legal agreement"}
    ]
}

classifier = create_classifier(config)
result = await classifier.classify(text)
print(result.documents[0].type)  # "Invoice"
print(result.documents[0].possible_types)  # Ranked list of possible types
```

### Extraction

```python
from dv_agent_core import create_extractor

config = {
    "fields": [
        {"name": "total", "type": "float", "description": "Total amount"},
        {"name": "items", "type": "list[str]", "description": "Line items"}
    ]
}

extractor = create_extractor(config)
result = await extractor.extract(text)
print(result.total)  # 100.50 (float)
```
"""

from typing import Union, List, Any
from dv_agent_core.classification.agent import (
    create_classifier,
    SimpleClassifier,
    ClassificationResult,
    ClassifiedDocument,
    TypeCandidate,
)
from dv_agent_core.extraction.agent import create_extractor, SimpleExtractor
from dv_agent_core.models.bbox import BoundingBox, FieldBBox, BBoxExtractionResult
from dv_agent_core.models.dynamic_schema import TYPE_CONTEXT
from dv_agent_core.examples import get_examples, get_classification_examples, get_extraction_examples
from dv_agent_core.utils.cost import estimate_cost
from dv_agent_core.utils.cost_constants import DEFAULT_PRICING
from dv_agent_core.utils.cost_fetch import (
    fetch_gemini_standard_pricing,
    fetch_latest_pricing,
    fetch_openai_standard_text_pricing,
)
from dv_agent_core.utils.cost_models import CostEstimate, ModelPricing, TokenUsage

def get_supported_types() -> dict:
    """
    Returns a dictionary of supported type strings and their Python equivalents.
    Useful for validating configuration files or generating documentation.
    """
    return {k: str(v) for k, v in TYPE_CONTEXT.items()}

async def classify(config: dict, input_data: Union[str, List[bytes]]) -> ClassificationResult:
    """
    Classify a document based on the provided configuration.

    Args:
        config: The classification configuration dictionary.
        input_data: Either a string (text content) or a list of bytes (image data).

    Returns:
        ClassificationResult: The classification result.

    Example:
        ```python
        config = {
            "types": [
                {"name": "Invoice", "description": "A bill for goods or services"},
                {"name": "Contract", "description": "A legal agreement"}
            ]
        }
        result = await classify(config, "This is an invoice for $500.")
        print(result.documents[0].type)  # "Invoice"
        print(result.documents[0].possible_types)  # Ranked list of possible types
        ```
    """
    classifier = create_classifier(config)
    if isinstance(input_data, str):
        return await classifier.chat(input_data)
    return await classifier.classify(input_data)

async def extract(config: dict, input_data: Union[str, List[bytes]]) -> Any:
    """
    Extract information from a document based on the provided configuration.

    Args:
        config: The extraction configuration dictionary.
        input_data: Either a string (text content) or a list of bytes (image data).

    Returns:
        The extracted data model (type depends on config).

    Example:
        ```python
        config = {
            "fields": [
                {"name": "total", "type": "float", "description": "Total amount"},
                {"name": "date", "type": "string", "description": "Invoice date"}
            ]
        }
        result = await extract(config, "Total: $100.00, Date: 2023-01-01")
        print(result.total)  # 100.0
        ```
    """
    extractor = create_extractor(config)
    if isinstance(input_data, str):
        return await extractor.chat(input_data)
    return await extractor.extract(input_data)

__all__ = [
    "create_classifier",
    "create_extractor",
    "classify",
    "extract",
    "SimpleClassifier",
    "SimpleExtractor",
    "ClassificationResult",
    "ClassifiedDocument",
    "TypeCandidate",
    "CostEstimate",
    "ModelPricing",
    "TokenUsage",
    "DEFAULT_PRICING",
    "estimate_cost",
    "fetch_gemini_standard_pricing",
    "fetch_latest_pricing",
    "fetch_openai_standard_text_pricing",
    "get_supported_types",
    "get_examples",
    "get_classification_examples",
    "get_extraction_examples",
        "BoundingBox",
        "FieldBBox",
        "BBoxExtractionResult",
]
