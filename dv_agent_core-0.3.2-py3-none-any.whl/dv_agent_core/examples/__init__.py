from typing import Dict, Any

CLASSIFICATION_EXAMPLES: Dict[str, Dict[str, Any]] = {
    "classification_basic": {
        "description": "Basic Document Routing - Classify documents into broad categories.",
        "type": "classification",
        "config": {
            "types": [
                {
                    "name": "Financial",
                    "description": "Invoices, receipts, tax forms, and bank statements."
                },
                {
                    "name": "Legal",
                    "description": "Contracts, NDAs, and court orders."
                },
                {
                    "name": "Personal",
                    "description": "ID cards, passports, and handwritten letters."
                }
            ],
            "instruction_template": "Analyze the document image and classify it into one of the following categories:\n{catalog}"
        }
    },
    "classification_forms": {
        "description": "Specific Form Identification - Distinguish between specific form types.",
        "type": "classification",
        "config": {
            "types": [
                { "name": "W9", "description": "IRS Form W-9 Request for Taxpayer Identification Number." },
                { "name": "1040", "description": "IRS Form 1040 U.S. Individual Income Tax Return." },
                { "name": "I-9", "description": "USCIS Form I-9 Employment Eligibility Verification." }
            ]
        }
    },
    "workflow_with_path": {
        "description": "Self-Contained Workflow - Config that includes the target document path.",
        "type": "classification",
        "config": {
            "document_path": "./documents/sample_invoice.pdf",
            "types": [
                { "name": "Invoice", "description": "A bill for goods or services" },
                { "name": "Other", "description": "Any other document" }
            ]
        }
    }
}

EXTRACTION_EXAMPLES: Dict[str, Dict[str, Any]] = {
    "extraction_invoice": {
        "description": "Invoice Extraction - Extract header-level information with mixed data types.",
        "type": "extraction",
        "config": {
            "fields": [
                { "name": "invoice_number", "type": "string", "description": "The unique identifier for the invoice." },
                { "name": "date", "type": "string", "description": "The invoice date (YYYY-MM-DD)." },
                { "name": "total_amount", "type": "float", "description": "The final total amount due." },
                { "name": "is_paid", "type": "boolean", "description": "True if the invoice is marked as paid." }
            ]
        }
    },
    "extraction_receipt": {
        "description": "Receipt Line Items - Extract a list of items from a receipt.",
        "type": "extraction",
        "config": {
            "fields": [
                { "name": "merchant", "type": "string", "description": "Name of the store." },
                { "name": "items", "type": "list[str]", "description": "List of item names purchased." },
                { "name": "prices", "type": "list[float]", "description": "List of prices corresponding to the items." }
            ]
        }
    },
    "extraction_specs": {
        "description": "Complex/Unstructured Data - Extract a dictionary of specifications.",
        "type": "extraction",
        "config": {
            "fields": [
                { "name": "product_name", "type": "string", "description": "Name of the product." },
                { "name": "specifications", "type": "dict", "description": "Key-value pairs of technical specifications found in the spec sheet." }
            ]
        }
    },
    "extraction_nested_json": {
        "description": "Nested JSON Object - Extract a specific JSON structure for a field.",
        "type": "extraction",
        "config": {
            "fields": [
                {
                    "name": "address",
                    "type": "object",
                    "description": "The full address broken down into components (street, city, zip)."
                },
                {
                    "name": "metadata",
                    "type": "dict",
                    "description": "Any additional metadata found in the document header."
                }
            ]
        }
    },
    "extraction_identity_card": {
        "description": "Identity Card - Extract personal details from an ID card.",
        "type": "extraction",
        "config": {
            "fields": [
                {"name": "full_name", "type": "string", "description": "Full name as it appears on the ID."},
                {"name": "document_number", "type": "string", "description": "The unique ID number."},
                {"name": "date_of_birth", "type": "string", "description": "Date of birth (YYYY-MM-DD)."},
                {"name": "expiration_date", "type": "string", "description": "Expiration date of the document."}
            ]
        }
    },
    "extraction_bank_statement": {
        "description": "Bank Statement - Extract account details and list of transactions.",
        "type": "extraction",
        "config": {
            "fields": [
                {"name": "account_holder", "type": "string", "description": "Name of the account holder."},
                {"name": "account_number", "type": "string", "description": "The bank account number."},
                {"name": "statement_period", "type": "string", "description": "The period covered by this statement."},
                {"name": "transactions", "type": "list[dict[str, any]]", "description": "List of transactions with date, description, and amount."}
            ]
        }
    },
    "extraction_resume": {
        "description": "Resume/CV - Extract contact info, skills, and experience.",
        "type": "extraction",
        "config": {
            "fields": [
                {"name": "contact_info", "type": "dict[str, string]", "description": "Contact details (email, phone, address)."},
                {"name": "skills", "type": "list[string]", "description": "List of technical and professional skills."},
                {"name": "experience", "type": "list[dict[str, any]]", "description": "Work experience entries with title, company, and dates."}
            ]
        }
    }
}

def get_classification_examples() -> Dict[str, Dict[str, Any]]:
    """Return a dictionary of classification example configurations."""
    return CLASSIFICATION_EXAMPLES

def get_extraction_examples() -> Dict[str, Dict[str, Any]]:
    """Return a dictionary of extraction example configurations."""
    return EXTRACTION_EXAMPLES

def get_examples() -> Dict[str, Dict[str, Any]]:
    """Return a dictionary of all example configurations."""
    return {**CLASSIFICATION_EXAMPLES, **EXTRACTION_EXAMPLES}
