from cev_ai_core.doc_types.base import BaseDocType


class MedicalHardshipDocType(BaseDocType):
    # TODO: Placeholder values until we get specifics on what Medical Hardship entails
    DOCTOR_LETTER = (
        "doctor_letter",
        "A letter from a doctor describing a medical condition or hardship",
    )
    MEDICAL_REPORT = (
        "medical_report",
        "Report on medical condition(s) that would prevent one from being able to work",
    )
    PRENATAL_RECORD = (
        "prenatal_record",
        "An antepartum or prenatal clinical record documenting pregnancy care, "
        "including visit logs, obstetric history, lab results, and estimated delivery date.",
    )
    POSTPARTUM_DISCHARGE = (
        "postpartum_discharge",
        "A hospital obstetric discharge summary documenting delivery details, "
        "maternal and newborn status at discharge, and postpartum follow-up instructions.",
    )
