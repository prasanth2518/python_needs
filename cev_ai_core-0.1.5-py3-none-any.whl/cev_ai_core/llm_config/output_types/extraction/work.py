from datetime import date
from typing import Literal

from pydantic import Field, computed_field, model_validator

from cev_ai_core.doc_types import WorkDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class Income(CamelCaseModel):
    amount: float | None = Field(
        default=None,
        description=(
            "Total income earned in this period. Only extract a specific dollar amount explicitly stated as "
            "total pay or compensation for the period — do not extract hourly rates, salary rates, "
            "or calculate income from rate * hours. Assume USD if no currency is specified. "
            "If the document explicitly shows a non-USD currency, set amount to null."
        ),
    )

    @computed_field
    @property
    def currency(self) -> Literal["USD"] | None:
        if self.amount is None:
            return

        return "USD"


class Bucket(CamelCaseModel):
    """A single time period with associated hours and income data."""

    start_date: date | None = Field(
        default=None,
        description="Start date of this period (YYYY-MM-DD)",
    )
    end_date: date | None = Field(
        default=None,
        description="End date of this period (YYYY-MM-DD)",
    )
    hours: float | None = Field(
        default=None,
        description="Total hours worked in this period (regular + overtime combined). Extract from totals at the current grain level if present. If no totals are shown but individual time entries exist, calculate by summing them. Do not extract from documents that only state a rate or schedule without actual logged time.",
    )


Grain = Literal["annual", "monthly", "biweekly", "weekly", "daily", "pay_period"]


class Allocations(CamelCaseModel):
    """Time-bucketed breakdown of hours extracted from the document."""

    grain: Grain | None = Field(
        default=None,
        description=(
            "The time grain of each bucket. Pick the coarsest grain that matches "
            "what the document actually shows, in this priority order: "
            "annual > monthly > biweekly > weekly > daily. "
            "For example, a W-2 covering a full year = 'annual'. "
            "A paystub covering two weeks = 'biweekly'. "
            "A timesheet with weekly totals = 'weekly'. "
            "Only use 'daily' if the document has no subtotals at any coarser level. "
            "Use 'pay_period' if the document covers a single period that does not align "
            "to any standard grain (e.g. 10 days, 3 weeks)."
        ),
    )
    buckets: list[Bucket] = Field(
        default_factory=list,
        description=(
            "Time-bucketed breakdown of hours. "
            "For single-period documents (paystubs, tax forms), use one bucket covering the full period. "
            "For timesheets with weekly sections or week totals, use one bucket per week — never per day. "
            "Use the week total (regular + overtime) as hours for each bucket."
        ),
    )


class WorkExtractionOutputType(BaseExtractionSchema):
    """Documents proving paid employment by an employer, including wages, salary, or hourly compensation"""

    document_type: WorkDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    document_date: DocumentDates
    document_source: DocumentSource
    allocations: Allocations
    income: Income

    @model_validator(mode="after")
    def _drop_incomplete_buckets(self):
        self.allocations.buckets = [
            b
            for b in self.allocations.buckets
            if (
                b.start_date is not None
                and b.end_date is not None
                and b.hours is not None
            )
        ]
        if not self.allocations.buckets:
            self.allocations.grain = None
        return self
