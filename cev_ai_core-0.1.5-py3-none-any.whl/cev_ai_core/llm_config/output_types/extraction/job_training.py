from datetime import date
from typing import Literal

from pydantic import Field, model_validator

from cev_ai_core.doc_types import JobTrainingDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class Bucket(CamelCaseModel):
    """A single time period with associated hours data."""

    start_date: date | None = Field(
        default=None,
        description="Start date of this period (YYYY-MM-DD)",
    )
    end_date: date | None = Field(
        default=None,
        description="End date of this period (YYYY-MM-DD)",
    )
    hours: float | None = Field(
        default=None,
        description="Total hours of training in this period. Extract from totals if present. If no totals are shown but individual time entries exist, calculate by summing them.",
    )


Grain = Literal["monthly", "weekly", "daily", "period"]


class Allocations(CamelCaseModel):
    """Time-bucketed breakdown of training hours extracted from the document."""

    grain: Grain | None = Field(
        default=None,
        description=(
            "The time grain of each bucket. Pick the coarsest grain that matches "
            "what the document actually shows, in this priority order: "
            "monthly > weekly > daily. "
            "For example, a form showing monthly totals = 'monthly'. "
            "A timesheet with weekly totals = 'weekly'. "
            "Only use 'daily' if the document has no subtotals at any coarser level. "
            "Use 'period' if the document covers a single span that does not align "
            "to any standard grain (e.g. 3 days, 5 weeks)."
        ),
    )
    buckets: list[Bucket] = Field(
        default_factory=list,
        description=(
            "Time-bucketed breakdown of training hours. "
            "For single-period documents (verification letters with one date range and total hours), "
            "use one bucket covering the full period with grain 'period'. "
            "If the document states hours per recurring period (e.g., monthly hours) over a range, "
            "use one bucket per period with calendar-month boundaries. "
            "For timesheets with weekly sections, use one bucket per week."
        ),
    )


class JobTrainingExtractionOutputType(BaseExtractionSchema):
    """Documents proving participation in workforce development, skills training, or on-the-job training (OJT) programs. These are NOT regular employment — they are issued by workforce development boards, training agencies, or programs like WIOA/OJT. Even if the document mentions an employer or hours worked, if it is issued by or references a training program or workforce development agency, it belongs here."""

    reasoning: str = Field(
        description=(
            "Think step-by-step before extracting any fields:\n"
            "1. DOCUMENT TYPE: What kind of document is this? (OJT verification, certificate, training log, etc.)\n"
            "2. SUBJECT: Who is the trainee? Extract their name exactly as written.\n"
            "3. ORGANIZATION: Who issued this document? What training program or workforce development agency is named?\n"
            "4. DATE RANGE: What is the overall training period? Identify explicit start/end dates.\n"
            "5. HOURS STRUCTURE: How are hours presented?\n"
            "   - A single total for the whole program (e.g. 'Total Training Hours: 240') → grain='period', one bucket\n"
            "   - A per-month rate or monthly schedule over a multi-month range → grain='monthly', one bucket PER MONTH in the range\n"
            "   - A schedule rate field (e.g. 'Weekly Hours: 32') describing the arrangement over a date range,\n"
            "     WITHOUT individual per-week breakdowns → grain='period', one bucket, calculate total hours = rate × number of periods\n"
            "     (e.g., 'Weekly Hours: 32' over 13 weeks = 416 total hours)\n"
            "   - Daily entries only (no subtotals) → grain='daily', one bucket per day\n"
            "   IMPORTANT: When a document shows a monthly schedule (e.g. '20 hours/month') with explicit per-month tracking,\n"
            "   create one bucket PER MONTH. But when a document just states a schedule rate as metadata (e.g. 'Weekly Hours: 32')\n"
            "   without tracking individual periods, use grain='period' and multiply to get total hours.\n"
            "6. BUCKET BOUNDARIES: For each bucket, what are the exact start/end dates?\n"
            "   - Weekly: use Monday-to-Sunday boundaries within the training date range\n"
            "   - Monthly: use calendar month boundaries (1st to last day of each month)\n"
            "   - If the overall range starts/ends mid-period, use the actual start/end date for those edge periods\n"
            "   - Period: use the full date range from step 4\n"
            "7. HOURS CALCULATION: For each bucket, what is the hours value?\n"
            "   - If grain='period' and hours are stated as a rate, multiply: rate × number of periods in the date range\n"
            "     (e.g., 32 hrs/week × 13 weeks = 416 hours; count the weeks between start and end dates)\n"
            "   - If only individual entries exist, sum them\n"
            "   - Use the stated per-period hours for monthly/weekly buckets\n"
            "8. SANITY CHECK: Do the buckets cover the full date range without gaps or overlaps?\n"
            "   Is there one bucket for every period unit in the range?"
        ),
        exclude=True,
    )
    document_type: JobTrainingDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    document_date: DocumentDates
    document_source: DocumentSource
    allocations: Allocations

    @model_validator(mode="after")
    def _drop_incomplete_buckets(self):
        self.allocations.buckets = [
            b
            for b in self.allocations.buckets
            if (
                b.start_date is not None
                and b.end_date is not None
                and b.hours is not None
            )
        ]
        if not self.allocations.buckets:
            self.allocations.grain = None
        return self
