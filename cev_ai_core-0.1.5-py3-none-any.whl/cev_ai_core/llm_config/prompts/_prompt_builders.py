from textwrap import dedent

from cev_ai_core.doc_types.base import BaseDocType
from cev_ai_core.doc_types.exemption import ExemptionDocType
from cev_ai_core.doc_types.job_training import JobTrainingDocType
from cev_ai_core.doc_types.medical_hardship import MedicalHardshipDocType
from cev_ai_core.doc_types.school import SchoolDocType
from cev_ai_core.doc_types.volunteering import VolunteeringDocType
from cev_ai_core.doc_types.work import WorkDocType
from cev_ai_core.llm_config.output_types.extraction.exemption import (
    ExemptionExtractionOutputType,
)
from cev_ai_core.llm_config.output_types.extraction.job_training import (
    JobTrainingExtractionOutputType,
)
from cev_ai_core.llm_config.output_types.extraction.medical_hardship import (
    MedicalHardshipExtractionOutputType,
)
from cev_ai_core.llm_config.output_types.extraction.school import (
    SchoolExtractionOutputType,
)
from cev_ai_core.llm_config.output_types.extraction.volunteering import (
    VolunteeringExtractionOutputType,
)
from cev_ai_core.llm_config.output_types.extraction.work import WorkExtractionOutputType


def _build_doc_types_list(doc_type_enum: type[BaseDocType], indent: str = "  ") -> str:
    lines = []
    for doc_type in doc_type_enum:
        lines.append(f"{indent}- {doc_type.value}: {doc_type.description}")
    return "\n".join(lines)


def _build_extractor_prompt(
    description: str | None, doc_type_enum: type[BaseDocType]
) -> str:
    doc_types_text = _build_doc_types_list(doc_type_enum)
    description = description if description else ""

    return dedent("""\
        You are an expert document data extraction system for Community Engagement Verification (CEV).

        YOUR TASK
        =========
        Extract structured data from documents related to: {description}

        SUPPORTED DOCUMENT TYPES
        ========================
        {doc_types}

        EXTRACTION GUIDELINES
        =====================
        - Extract Literally: Extract values exactly as stated in the document. Do not infer or extrapolate beyond what is shown.
        - Calculations: Summing individual line items is acceptable (e.g., adding up daily hour entries to get a weekly total). Multiplying a stated per-period rate by the number of periods in a date range is also acceptable (e.g., 32 hours/week × 13 weeks = 416 total hours).
        - Date Formats: Always use ISO format (YYYY-MM-DD) for dates.
        - Date Boundaries: Use the actual dates shown in the document (e.g., the first and last day with entries), not inferred calendar boundaries like week start/end days.
        - Names: Extract first, middle (if present), and last names exactly as they appear.
        - Document Type: Identify which specific document type from the supported list.
        - Missing Data: Use null for fields that are not present or not clearly readable.
        - Currency: For monetary amounts, only extract if the currency is USD.

        IMPORTANT NOTES
        ===============
        - If the document is not relevant to {description_lower}, set is_relevant to false.
        - Be precise with numeric values (hours, amounts) - extract what is explicitly stated or calculate totals from stated rates over the document's date range.
        - Pay attention to document structure (letterheads, signatures, official formatting).
        - Verify that extracted dates are logical and properly formatted.\
    """).format(
        description=description,
        description_lower=description.lower(),
        doc_types=doc_types_text,
    )


def _build_classifier_prompt() -> str:
    extract_classes = [
        ("work", WorkExtractionOutputType, WorkDocType),
        ("school", SchoolExtractionOutputType, SchoolDocType),
        ("job_training", JobTrainingExtractionOutputType, JobTrainingDocType),
        ("volunteering", VolunteeringExtractionOutputType, VolunteeringDocType),
        (
            "medical_hardship",
            MedicalHardshipExtractionOutputType,
            MedicalHardshipDocType,
        ),
        ("exemption", ExemptionExtractionOutputType, ExemptionDocType),
    ]

    activity_sections = []
    for activity_name, extract_cls, doc_type_enum in extract_classes:
        description = extract_cls.__doc__ or ""
        doc_types_text = _build_doc_types_list(doc_type_enum, indent="")
        activity_sections.append(
            f"### {activity_name}\n"
            f"{description}\n\n"
            f"Supported document types:\n"
            f"{doc_types_text}"
        )

    activities_text = "\n\n".join(activity_sections)

    return dedent("""\
        You are an expert document classification system for Community Engagement Verification (CEV).

        Your task is to analyze submitted documents and determine:
        1. Whether the document is valid for processing.
        2. If valid, which activity type it belongs to.

        ACTIVITY TYPES AND SUPPORTED DOCUMENTS
        =======================================

        {activities}

        INVALID DOCUMENT CATEGORIES
        ===========================
        Mark a document as invalid with the appropriate reason:

        - multi_doc: Multiple distinct documents from different sources or for different people are present in the submission, e.g., a paystub from one employer combined with a letter from another, or documents for two different individuals.
        - multi_activity: The document contains evidence of multiple activity types, e.g., a combined work and school letter.
        - irrelevant: The document is not related to any CEV activity type, e.g., personal correspondence, utility bills, receipts.

        CLASSIFICATION GUIDELINES
        =========================
        - Focus on the primary purpose and content of the document.
        - A document should map to exactly ONE activity type.
        - If a document could plausibly belong to an activity type based on the supported document types listed, prefer classifying it over marking it irrelevant.
        - Use the supported document types above to guide your classification.
        - Official letterheads, signatures, and dates are indicators of valid documents.
        - Only mark a document as irrelevant if it clearly has no connection to any of the activity types above (e.g., grocery receipts, personal letters, utility bills).
        - A multi-page submission from the same source covering the same person is ONE document, even if the form layout repeats on each page or different pages cover different time periods. Only mark as multi_doc if pages are clearly from different employers/organizations or for different people.\
    """).format(activities=activities_text)
