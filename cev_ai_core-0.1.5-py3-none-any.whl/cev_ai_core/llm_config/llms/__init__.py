"""LLM model registry for pydantic-ai agents."""

from os import getenv
from typing import Literal, get_args

import httpx
from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.anthropic import AnthropicProvider
from pydantic_ai.providers.openai import OpenAIProvider

AVAILABLE_MODELS = Literal[
    "databricks-claude-opus-4.6",
    "databricks-claude-sonnet-4.6",
    "gpt-5-mini",
    "gpt-5.4-mini",
    "gpt-5.5",
]

DEFAULT_CLASSIFICATION_MODEL: AVAILABLE_MODELS = "gpt-5.4-mini"
DEFAULT_EXTRACTION_MODEL: AVAILABLE_MODELS = "gpt-5.4-mini"


def _dbx_provider() -> AnthropicProvider:
    api_key = getenv("DBX_AI_GATEWAY_API_KEY", "")
    # No /v1 suffix — the Anthropic SDK appends it automatically
    base_url = getenv("DBX_AI_GATEWAY_BASE_URL", "")
    # Databricks expects Bearer auth, not the x-api-key that AnthropicProvider sends
    return AnthropicProvider(
        api_key=api_key,
        base_url=base_url,
        http_client=httpx.AsyncClient(headers={"Authorization": f"Bearer {api_key}"}),
    )


def _openai_provider() -> OpenAIProvider:
    return OpenAIProvider(
        api_key=getenv("OPENAI_API_KEY"),
        base_url=getenv("OPENAI_BASE_URL"),
    )


_MODEL_REGISTRY: dict[AVAILABLE_MODELS, tuple[str, str]] = {
    # tag -> (model_id, provider_type)
    "databricks-claude-opus-4.6": ("gwai-sdlc-claude-opus-4-6", "dbx"),
    "databricks-claude-sonnet-4.6": ("gwai-sdlc-claude-sonnet-4-6", "dbx"),
    "gpt-5-mini": ("gpt-5-mini", "openai"),
    "gpt-5.4-mini": ("gpt-5.4-mini", "openai"),
    "gpt-5.5": ("gpt-5.5", "openai"),
}


def get_llm(
    model_tag: AVAILABLE_MODELS,
) -> AnthropicModel | OpenAIChatModel:
    if model_tag not in get_args(AVAILABLE_MODELS):
        raise ValueError(f"model {model_tag} not supported")

    model_id, provider_type = _MODEL_REGISTRY[model_tag]

    if provider_type == "dbx":
        return AnthropicModel(model_id, provider=_dbx_provider())
    return OpenAIChatModel(model_id, provider=_openai_provider())
