import io
import base64
from pathlib import Path
from typing import List, Union

def decode_base64_image(data: str) -> bytes:
    """
    Decode a base64-encoded image string to bytes.

    Args:
        data: Base64 string, optionally with data URI prefix (e.g., "data:image/png;base64,...")

    Returns:
        bytes: Decoded image bytes
    """
    # Handle data URI format: data:image/png;base64,<base64_data>
    if data.startswith("data:"):
        # Extract the base64 part after the comma
        if "," in data:
            data = data.split(",", 1)[1]

    return base64.b64decode(data)


def encode_image_to_base64(image_bytes: bytes, media_type: str = "image/png") -> str:
    """
    Encode image bytes to a base64 data URI string.

    Args:
        image_bytes: Raw image bytes
        media_type: MIME type of the image (default: image/png)

    Returns:
        str: Data URI string (e.g., "data:image/png;base64,...")
    """
    b64 = base64.b64encode(image_bytes).decode("utf-8")
    return f"data:{media_type};base64,{b64}"


def load_images_from_base64(base64_images: List[str]) -> List[bytes]:
    """
    Load images from base64-encoded strings.

    Args:
        base64_images: List of base64 strings (with or without data URI prefix)

    Returns:
        List[bytes]: List of decoded image bytes
    """
    return [decode_base64_image(img) for img in base64_images]


def load_document_as_images(path: Union[str, Path], scale: float = 2.0) -> List[bytes]:
    """
    Load a document (PDF or Image) and return a list of image bytes (PNG format).

    Args:
        path: Path to the file.
        scale: Scale factor for PDF rendering (default 2.0).

    Returns:
        List[bytes]: List of PNG image bytes.
    """
    path = Path(path).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    suffix = path.suffix.lower()

    # Handle PDF
    if suffix == ".pdf":
        try:
            import pypdfium2 as pdfium
        except ImportError as exc:
            raise RuntimeError("pypdfium2 is required for PDF rendering") from exc

        images: List[bytes] = []
        pdf = pdfium.PdfDocument(str(path))

        for page in pdf:
            bitmap = page.render(scale=scale)
            pil_image = bitmap.to_pil()

            buf = io.BytesIO()
            pil_image.save(buf, format="PNG")
            images.append(buf.getvalue())

        return images

    # Handle Images
    if suffix in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tiff"}:
        # For consistency, we could convert everything to PNG,
        # but for now let's just return the raw bytes if it's a supported format.
        # However, the agent currently hardcodes "image/png" in the BinaryContent.
        # So we should probably convert to PNG to be safe and consistent.
        from PIL import Image

        try:
            with Image.open(path) as img:
                # Convert to RGB if necessary (e.g. for RGBA or CMYK) to save as PNG
                if img.mode not in ("RGB", "L"):
                    img = img.convert("RGB")

                buf = io.BytesIO()
                img.save(buf, format="PNG")
                return [buf.getvalue()]
        except Exception as e:
            raise RuntimeError(f"Failed to load image {path}: {e}")

    raise ValueError(f"Unsupported file type: {suffix}. Supported: .pdf, .png, .jpg, .jpeg, .webp")
