from dv_agent_core.utils.cost_models import ModelPricing

# Default pricing uses standard on-demand input/output rates per 1M tokens.
# Gemini rates reflect the <=200k prompt tier where applicable.
DEFAULT_PRICING: dict[str, ModelPricing] = {
    # OpenAI GPT models (text tokens) - source: OpenAI API pricing.
    "gpt-5.2": ModelPricing(input_per_million=1.75, output_per_million=14.00),
    "gpt-5.2-pro": ModelPricing(input_per_million=21.00, output_per_million=168.00),
    "gpt-5.2-chat-latest": ModelPricing(input_per_million=1.75, output_per_million=14.00),
    "gpt-5.2-codex": ModelPricing(input_per_million=1.75, output_per_million=14.00),
    "gpt-5.1": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5.1-chat-latest": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5.1-codex-max": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5.1-codex": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5-chat-latest": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5-codex": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gpt-5-pro": ModelPricing(input_per_million=15.00, output_per_million=120.00),
    "gpt-5-mini": ModelPricing(input_per_million=0.25, output_per_million=2.00),
    "gpt-5-nano": ModelPricing(input_per_million=0.05, output_per_million=0.40),
    "gpt-4o": ModelPricing(input_per_million=2.50, output_per_million=10.00),
    "gpt-4o-mini": ModelPricing(input_per_million=0.15, output_per_million=0.60),
    "gpt-4.1": ModelPricing(input_per_million=2.00, output_per_million=8.00),
    "gpt-4.1-mini": ModelPricing(input_per_million=0.40, output_per_million=1.60),
    "gpt-4.1-nano": ModelPricing(input_per_million=0.10, output_per_million=0.40),
    # Google Gemini models (text/image/video tokens)
    "gemini-2.5-pro": ModelPricing(input_per_million=1.25, output_per_million=10.00),
    "gemini-2.5-flash": ModelPricing(input_per_million=0.30, output_per_million=2.50),
    "gemini-2.5-flash-lite": ModelPricing(input_per_million=0.10, output_per_million=0.40),
    "gemini-2.0-flash": ModelPricing(input_per_million=0.10, output_per_million=0.40),
}
