import io
from pathlib import Path
from typing import List, Union

def create_sample_pdf(path: Union[str, Path], text: str) -> Path:
    """Create a simple PDF with text using PIL. Useful for testing and examples."""
    try:
        from PIL import Image, ImageDraw
    except ImportError as exc:
        raise RuntimeError("Pillow is required for creating sample PDFs") from exc

    if isinstance(path, str):
        path = Path(path)

    # Create a white image
    img = Image.new('RGB', (800, 600), color='white')
    d = ImageDraw.Draw(img)

    # Draw text (simple default font)
    d.text((50, 50), text, fill=(0, 0, 0))

    img.save(path, "PDF", resolution=100.0)
    return path

def render_pdf_to_images(path: Path, scale: float = 2.0) -> List[bytes]:
    """Render PDF pages to PNG bytes using pypdfium2."""
    try:
        import pypdfium2 as pdfium
    except ImportError as exc:
        raise RuntimeError("pypdfium2 is required for PDF rendering but is not installed") from exc

    images: List[bytes] = []
    pdf = pdfium.PdfDocument(str(path))

    for page in pdf:
        bitmap = page.render(scale=scale)
        pil_image = bitmap.to_pil()

        buf = io.BytesIO()
        pil_image.save(buf, format="PNG")
        images.append(buf.getvalue())

    return images
