from typing import List, Type, TypeVar, Generic, Union, Optional, Dict, Any, Callable, Tuple, Mapping, cast
from pathlib import Path
from pydantic import BaseModel
from pydantic_ai import Agent, BinaryContent
from pydantic_ai.settings import ModelSettings
from dv_agent_core.utils.llm import build_model, normalize_provider
from dv_agent_core.utils.document import load_document_as_images, load_images_from_base64
from dv_agent_core.models.bbox import FieldBBox, BBoxExtractionResult
from dv_agent_core.utils.cost_models import CostEstimate, ModelPricing
import importlib
import re

T = TypeVar("T", bound=BaseModel)


class DocumentAgent(Generic[T]):
    """
    A generic agent for processing documents (images or text) and returning structured data.

    Tools can be added in three ways:
    1. Via config: Pass a list of tool configs with "name", "description", and "function" (dotted path)
    2. Via constructor: Pass a list of callable functions to the `tools` parameter
    3. After creation: Use the `@agent.tool` decorator on the underlying agent

    Example (after creation):
        classifier = create_classifier(config)

        @classifier.agent.tool
        def lookup_vendor(vendor_name: str) -> dict:
            '''Look up vendor information.'''
            return {"vendor_id": "123"}
    """

    @staticmethod
    def resolve_template(text: str, context: Dict[str, Any]) -> str:
        """
        Resolve ${key} placeholders in text using values from context dict.

        Supports:
        - ${key} - simple replacement
        - ${key} where value is a list - joins with ", "
        - ${key} where value is a dict - converts to "key1: value1, key2: value2"

        If a key is not found in context, the placeholder is left as-is.
        """
        if not context:
            return text

        def replace_match(match):
            key = match.group(1)
            if key not in context:
                return match.group(0)  # Keep original if key not found

            value = context[key]

            # Format value based on type
            if isinstance(value, list):
                return ", ".join(str(v) for v in value)
            elif isinstance(value, dict):
                return ", ".join(f"{k}: {v}" for k, v in value.items())
            else:
                return str(value)

        # Match ${key} pattern
        return re.sub(r'\$\{(\w+)\}', replace_match, text)

    @staticmethod
    def resolve_tool_function(tool_config: Dict[str, Any]) -> Callable:
        """
        Resolve a tool function from a config dict with a dotted path.

        Args:
            tool_config: Dict with "function" key containing a dotted path like "my_module.my_function"

        Returns:
            The resolved callable function

        Example:
            tool_config = {"function": "my_app.tools.lookup_vendor"}
            func = DocumentAgent.resolve_tool_function(tool_config)
        """
        func_path = tool_config.get("function", "")
        if not func_path:
            raise ValueError("Tool config must have a 'function' key with a dotted path")

        # Split into module and function name
        parts = func_path.rsplit(".", 1)
        if len(parts) != 2:
            raise ValueError(f"Invalid function path: {func_path}. Expected 'module.function' format.")

        module_path, func_name = parts
        module = importlib.import_module(module_path)
        return getattr(module, func_name)

    # Default maximum images to process (None = no limit)
    DEFAULT_MAX_IMAGES: int = 10

    def __init__(
        self,
        model: str,
        system_prompt: str,
        output_type: Type[T],
        image_instruction: str = "Process the document provided in the images.",
        retries: int = 1,
        model_settings: Optional[ModelSettings] = None,
        tools: Optional[List[Callable]] = None,
        system_prompt_template: Optional[str] = None,
        max_images: Optional[int] = None,
        provider: str = "openai",
        provider_settings: Optional[Dict[str, Any]] = None,
    ):
        self.model_name = model  # Keep attribute name for backward compatibility
        self.provider = normalize_provider(provider)
        self.provider_settings = provider_settings
        self._model = build_model(model, provider=self.provider, provider_settings=provider_settings)
        self.system_prompt = system_prompt
        self.output_type = output_type
        self.image_instruction = image_instruction
        self.retries = retries
        self.model_settings = model_settings
        self._last_usage: Optional[Any] = None
        # Max images limit (use class default if not specified)
        self.max_images = max_images if max_images is not None else self.DEFAULT_MAX_IMAGES
        # Store template for runtime resolution (defaults to system_prompt if not provided)
        self._system_prompt_template = system_prompt_template or system_prompt
        self.agent = Agent(
            self._model,
            system_prompt=system_prompt,
            output_type=output_type,
            retries=retries,
            model_settings=model_settings
        )

        # Register tools if provided (Option 2 & 3)
        # Use tool_plain for simple functions that don't need RunContext
        if tools:
            for tool_func in tools:
                self.agent.tool_plain(tool_func)

    def _capture_usage(self, result: Any) -> None:
        usage = getattr(result, "usage", None)
        if callable(usage):
            try:
                usage = usage()
            except TypeError:
                usage = None
        self._last_usage = usage

    def add_tool(self, func: Callable) -> Callable:
        """
        Add a tool to the agent. Can be used as a decorator.

        Example:
            @classifier.add_tool
            def my_tool(query: str) -> str:
                '''Search for something.'''
                return "result"
        """
        return self.agent.tool_plain(func)

    def get_model_info(self) -> Dict[str, Any]:
        """
        Return basic model metadata for debugging/logging.
        """
        info: Dict[str, Any] = {
            "provider": self.provider,
            "model": self.model_name,
        }
        base_url = getattr(self._model, "base_url", None)
        if base_url:
            info["base_url"] = base_url
        return info

    async def process_images(self, images: List[bytes], context: Optional[Dict[str, Any]] = None) -> T:
        """
        Process a list of image bytes.

        Args:
            images: List of image bytes to process
            context: Optional dictionary for resolving ${key} placeholders in system prompt

        Raises:
            ValueError: If number of images exceeds max_images limit
        """
        # Enforce image limit
        if self.max_images is not None and len(images) > self.max_images:
            raise ValueError(
                f"Too many images: {len(images)} provided, but max_images is {self.max_images}. "
                f"Reduce the number of images or increase max_images in config."
            )

        try:
            user_prompt: List[Union[BinaryContent, str]] = []
            for img in images:
                user_prompt.append(BinaryContent(data=img, media_type="image/png"))
            user_prompt.append(self.image_instruction)

            if context:
                # Resolve templates and temporarily update agent's system prompt
                resolved_prompt = self.resolve_template(self._system_prompt_template, context)
                original_prompt = self.agent._system_prompts
                self.agent._system_prompts = (resolved_prompt,)
                try:
                    result = await self.agent.run(user_prompt)
                    self._capture_usage(result)
                    return cast(T, result.output)
                finally:
                    self.agent._system_prompts = original_prompt
            else:
                result = await self.agent.run(user_prompt)
                self._capture_usage(result)
                return cast(T, result.output)
        except Exception as e:
            raise RuntimeError(f"Image processing failed: {e}")

    async def process_images_with_bboxes(
        self,
        images: List[bytes],
        *,
        schema_fields: List[str],
        context: Optional[Dict[str, Any]] = None,
    ) -> Tuple[T, List[FieldBBox]]:
        """Extract structured data and field-level bounding boxes in one call.

        This uses a separate agent call that asks the LLM to return both the structured
        extraction output and bounding boxes for each extracted field.
        """

        # Enforce image limit
        if self.max_images is not None and len(images) > self.max_images:
            raise ValueError(
                f"Too many images: {len(images)} provided, but max_images is {self.max_images}. "
                f"Reduce the number of images or increase max_images in config."
            )

        # Define a lightweight response model dynamically
        from typing import List as _List, Type as _Type
        from pydantic import BaseModel as _BaseModel, Field as _Field, create_model as _create_model

        ResponseModel: _Type[_BaseModel] = _create_model(
            "ExtractionWithBBoxes",
            data=(self.output_type, ...),
            fields=(_List[FieldBBox], _Field(default_factory=list)),
        )

        bbox_instruction = (
            "Also return bounding boxes for each extracted field. "
            "For each field, return one or more rectangles with pixel coordinates (x0,y0,x1,y1) "
            "and a 0-based page_index. If a value appears multiple times, choose the most relevant occurrence. "
            "If you cannot localize a field, return an empty boxes list for that field. "
            f"Fields to localize: {', '.join(schema_fields)}."
        )

        user_prompt: List[Union[BinaryContent, str]] = []
        for img in images:
            user_prompt.append(BinaryContent(data=img, media_type="image/png"))
        user_prompt.append(self.image_instruction)
        user_prompt.append(bbox_instruction)

        try:
            # Build a one-off agent so we can change output_type
            # Prefer a stronger model for localization unless user configured otherwise.
            # If the configured model is already a gpt-5* model, keep it.
            bbox_model = self._model
            try:
                model_name = getattr(self, "model_name", "") or ""
                if self.provider == "openai" and not model_name.startswith("gpt-5"):
                    from dv_agent_core.utils.llm import build_model

                    bbox_model = build_model(
                        "gpt-5.2",
                        provider=self.provider,
                        provider_settings=self.provider_settings,
                    )
            except Exception:
                # Fall back to the existing model if anything goes wrong
                bbox_model = self._model

            temp_agent = Agent(
                bbox_model,
                system_prompt=self.system_prompt,
                output_type=ResponseModel,
                retries=self.retries,
                model_settings=self.model_settings,
            )

            if context:
                resolved_prompt = self.resolve_template(self._system_prompt_template, context)
                temp_agent._system_prompts = (resolved_prompt,)

            result = await temp_agent.run(user_prompt)
            self._capture_usage(result)
            output = cast(Any, result.output)
            # Return the typed extraction output plus field bbox list
            return output.data, output.fields  # type: ignore[attr-defined]
        except Exception as e:
            raise RuntimeError(f"Image processing (with bboxes) failed: {e}")

    async def process_document(
        self,
        images: Optional[List[bytes]] = None,
        *,
        document_path: Optional[Union[str, Path]] = None,
        base64_images: Optional[List[str]] = None,
        context: Optional[Dict[str, Any]] = None,
        with_bboxes: bool = False,
        include_images: bool = True,
        schema_fields: Optional[List[str]] = None,
    ) -> Union[T, BBoxExtractionResult]:
        """
        Process a document from various input formats.

        Provide ONE of the following input options:
        - images: List of raw image bytes (PNG format)
        - document_path: Path to a PDF or image file
        - base64_images: List of base64-encoded image strings

        Args:
            images: List of image bytes to process
            document_path: Path to PDF or image file
            base64_images: List of base64-encoded images (with or without data URI prefix)
            context: Optional dictionary for resolving ${key} placeholders in prompts

        Returns:
            Processed result as the configured output type, or BBoxExtractionResult when with_bboxes=True
        """
        if with_bboxes:
            return await self.process_document_with_bboxes(
                images=images,
                document_path=document_path,
                base64_images=base64_images,
                context=context,
                schema_fields=schema_fields,
                include_images=include_images,
            )

        # Determine which input to use
        if images is not None:
            pass  # Use provided images directly
        elif document_path is not None:
            images = load_document_as_images(document_path)
        elif base64_images is not None:
            images = load_images_from_base64(base64_images)
        else:
            raise ValueError("Must provide one of: images, document_path, or base64_images")

        return await self.process_images(images, context=context)

    async def process_document_with_bboxes(
        self,
        images: Optional[List[bytes]] = None,
        *,
        document_path: Optional[Union[str, Path]] = None,
        base64_images: Optional[List[str]] = None,
        context: Optional[Dict[str, Any]] = None,
        schema_fields: Optional[List[str]] = None,
        include_images: bool = True,
    ) -> BBoxExtractionResult:
        """
        Process a document and return both the structured output and field-level bounding boxes.

        Provide ONE of the following input options:
        - images: List of raw image bytes (PNG format)
        - document_path: Path to a PDF or image file
        - base64_images: List of base64-encoded image strings

        Args:
            images: List of image bytes to process
            document_path: Path to PDF or image file
            base64_images: List of base64-encoded images (with or without data URI prefix)
            context: Optional dictionary for resolving ${key} placeholders in prompts
            schema_fields: Optional list of field names to localize; defaults to the output schema's fields
            include_images: If True, attach page images to the returned result for easy annotation/display

        Returns:
            BBoxExtractionResult containing `data`, `fields`, and optionally attached `images`
        """
        resolved_document_path: Optional[str] = None

        # Determine which input to use
        if images is not None:
            resolved_images = images  # Use provided images directly
        elif document_path is not None:
            resolved_images = load_document_as_images(document_path)
            resolved_document_path = str(document_path)
        elif base64_images is not None:
            resolved_images = load_images_from_base64(base64_images)
        else:
            raise ValueError("Must provide one of: images, document_path, or base64_images")

        if schema_fields is None:
            schema_fields = list(self.output_type.model_fields.keys())

        data_model, field_bboxes = await self.process_images_with_bboxes(
            resolved_images,
            schema_fields=schema_fields,
            context=context,
        )

        return BBoxExtractionResult(
            data=data_model.model_dump(),
            fields=field_bboxes,
            images=list(resolved_images) if include_images else None,
            document_path=resolved_document_path,
        )

    async def process_text(self, text: str, context: Optional[Dict[str, Any]] = None) -> T:
        """
        Process text content directly.

        Args:
            text: Text content to process
            context: Optional dictionary for resolving ${key} placeholders in system prompt
        """
        try:
            if context:
                resolved_prompt = self.resolve_template(self._system_prompt_template, context)
                original_prompt = self.agent._system_prompts
                self.agent._system_prompts = (resolved_prompt,)
                try:
                    result = await self.agent.run(text)
                    self._capture_usage(result)
                    return result.output
                finally:
                    self.agent._system_prompts = original_prompt
            else:
                result = await self.agent.run(text)
                self._capture_usage(result)
                return result.output
        except Exception as e:
            raise RuntimeError(f"Text processing failed: {e}")

    def get_last_usage(self) -> Optional[Any]:
        return self._last_usage

    def estimate_last_cost(self, pricing: Optional[Mapping[str, ModelPricing]] = None) -> Optional[CostEstimate]:
        if self._last_usage is None:
            return None
        from dv_agent_core.utils.cost import estimate_cost
        return estimate_cost(self.model_name, self._last_usage, pricing=pricing)
