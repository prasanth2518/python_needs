"""LLM configuration for the staged document review workflow."""

from os import getenv
from textwrap import dedent
from typing import Literal

import httpx
from pydantic import BaseModel, ConfigDict, Field, create_model, model_validator
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

from dev_ai_core.document_rules.base import DocumentRule
from dev_ai_core.document_rules.registry import render_supported_document_types
from dev_ai_core.extraction_models import FieldEvidence
from dev_ai_core.orientation import DocumentTopEdge
from dev_ai_core.request import Dependent, PolicyHolder
from dev_ai_core.types import DocumentType, valid_relationships_for_document

VerificationStatus = Literal["PASS", "FAIL"]
DEFAULT_LLM = "openai-chat:gpt-5.4"

SEGMENTATION_SYSTEM_PROMPT = dedent("""\
    You are the segmentation step of a document review workflow.

    Procedure:

    1. Review all pages in the uploaded PDF.
    2. Then, orient all pages by rotating so that the text is right-side up and readable.
    3. Group consecutive pages into logical document segments, but do not merge pages into one segment unless you can confidently tell they belong to the same underlying record or document instance
    4. Assign one document_type to each segment.
    5. Return only the requested schema.

    Rules:
    - Page numbers are 1-based.
    - page_numbers must be an explicit list of all page numbers in the segment.
    - Do not use start/end shorthand. If a segment covers pages 1 through 3, return [1, 2, 3], not [1, 3].
    - Do not represent non-contiguous pages as one segment.
    - Do not merge consecutive pages into one segment just because they share the same document type; each distinct certificate or record must be its own segment
    - For TAX_RETURN_1040, classify only official IRS Form 1040 page 1 and/or page 2. When consecutive pages are page 1 and page 2 of the same Form 1040 return, return them as one segment. If only one official Form 1040 page is present, classify that page as TAX_RETURN_1040. Classify all other tax packet pages as OTHER, including schedules, worksheets, W-2s, 1099s, state returns, cover pages, instruction pages, and supporting tax attachments.    
    - Use OTHER for unsupported, unusable, blurry, unrelated, blank, partially legible, or low-confidence pages.
    - Use OTHER whenever a page or segment cannot be confidently assigned to one of the supported document types.
    - Keep reasoning brief and factual.
""")

PAGE_ORIENTATION_PROMPT = dedent("""\

    Page orientation output:
    - For every uploaded page, identify where the document's top edge appears in the current image.
    - Use the document title, header, and normal reading direction to identify its top edge.
    - Return TOP when the top edge is at the image's top, LEFT when it is at the image's left, BOTTOM when it is at the image's bottom, or RIGHT when it is at the image's right.
    - Do not calculate or return rotation degrees.
    - Return null when the document's top edge cannot be determined confidently.
    - Return exactly one orientation entry for every PAGE label.
""")

VALIDATION_SYSTEM_PROMPT = dedent("""\
    You are the extraction step of a document review workflow.

    Procedure:
    1. Treat the supplied document_type as a fixed input.
    2. First, orient the document by rotating so that the text is right-side up and readable.
    2. Then, choose the best matching dependent from the eligible dependent list using loose document evidence.
    3. Return matched_dependent_id only when one eligible dependent is the clear best match and the document is clear enough to make a confident selection.
    4. Return matched_dependent_id as null if the match is ambiguous or if the document is too blurry to make out the name of the dependent.
    5. After choosing the dependent, extract only the requested values from the provided segment pages.
    6. Return names exactly as instructed for each field.
    7. Return date values in YYYY-MM-DD format when a date is visible.
    8. If a value is not present, return null.
    9. Return only the requested schema.

    Rules:
    - Do not invent values.
    - Do not add extra keys or narrative.
    - Use only the eligible dependent relationships listed in the prompt.
    - When match_statuses are requested for a field, return only PASS or FAIL for that field.
    - When a field asks for an event date, do not substitute issue, filing, recording, certificate, or return dates.
    - When a field instruction asks for a JSON array, return an array and not a string.
    - When a field instruction asks for a JSON object, return an object with exactly the requested keys.
    - For every requested field, return extracted and evidence. evidence must contain exactText and reasoning.
    - evidence.exactText must be a list of exact text quoted from the document. Do not paraphrase quoted text or copy submitted payload information into it.
    - Return evidence.exactText as an empty list when no reliable supporting text is visible.
    - evidence.reasoning must briefly explain how the quoted evidence supports the extraction, or why the value could not be reliably extracted.
    - Do not use evidence.reasoning to compare against the payload or determine PASS or FAIL.
""")


def get_model() -> str:
    return getenv("DEV_AI_MODEL", DEFAULT_LLM)


def get_openai_model_name() -> str:
    model = get_model()
    for prefix in ("openai-chat:", "openai-responses:", "openai:"):
        if model.startswith(prefix):
            return model[len(prefix) :]
    return model


def _build_provider() -> OpenAIProvider:
    http_client = httpx.AsyncClient(verify=False)
    return OpenAIProvider(
        base_url=getenv("OPENAI_BASE_URL"),
        api_key=getenv("OPENAI_API_KEY"),
        http_client=http_client,
    )


def build_segmentation_agent(*, include_page_orientation: bool = False) -> Agent:
    model = OpenAIChatModel(
        model_name=get_openai_model_name(),
        provider=_build_provider(),
    )
    system_prompt = SEGMENTATION_SYSTEM_PROMPT
    if include_page_orientation:
        system_prompt += PAGE_ORIENTATION_PROMPT
        return Agent(
            model=model,
            system_prompt=system_prompt,
            retries={"output": 1},
        )
    return Agent(
        model=model,
        system_prompt=system_prompt,
    )


def build_validation_agent() -> Agent:
    model = OpenAIChatModel(
        model_name=get_openai_model_name(),
        provider=_build_provider(),
    )
    return Agent(
        model=model,
        system_prompt=VALIDATION_SYSTEM_PROMPT,
        retries={"output": 1},
    )


class AISegmentClassification(BaseModel):
    document_type: DocumentType = Field(
        description="Specific document type for the logical segment"
    )
    reasoning: str = Field(
        description="Short explanation of why this segment belongs to that document type"
    )
    matched_target_index: int | None = Field(
        default=None,
        description="Best matching dependent index when one dependent clearly applies",
    )
    page_numbers: list[int] = Field(
        description="Explicit 1-based list of every page number in the logical segment, not a start/end range"
    )


class AISegmentationResult(BaseModel):
    classifications: list[AISegmentClassification] = Field(default_factory=list)


class AIPageOrientation(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    page_number: int = Field(
        ge=1,
        description="The explicit 1-based PAGE label for this image.",
    )
    document_top_edge: DocumentTopEdge | None = Field(
        description=(
            "Position of the document's top edge in the current image, "
            "or null when uncertain."
        )
    )


class AIOrientedSegmentationResult(AISegmentationResult):
    page_orientations: list[AIPageOrientation] = Field(min_length=1)


class AISegmentExtractionResult(BaseModel):
    matched_dependent_id: str | None = Field(
        default=None,
        description="Dependent id chosen during validation from the ELIGIBLE DEPENDENTS list, or null if ambiguous.",
    )
    extracted_fields: dict[str, object] = Field(
        default_factory=dict,
        description="Map of requested extracted field keys to their extracted values or null.",
    )
    match_statuses: dict[str, VerificationStatus] = Field(
        default_factory=dict,
        description="Optional map of field keys to PASS or FAIL when a rule asks the LLM to make the match decision.",
    )
    field_evidence: dict[str, dict[str, object]] = Field(
        default_factory=dict,
        description="Evidence and extraction reasoning returned for each extracted field.",
    )


class StrictLLMOutputModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        strict=True,
        populate_by_name=True,
    )


def _build_evidence_field_model(
    rule: DocumentRule,
    field_key: str,
    output_annotation: object,
    *,
    requires_text_evidence: bool,
) -> type[BaseModel]:
    @model_validator(mode="after")
    def validate_text_evidence(self: BaseModel) -> BaseModel:
        extracted = self.__dict__["extracted"]
        evidence = self.__dict__["evidence"]
        if requires_text_evidence and extracted is not None and not evidence.exact_text:
            raise ValueError("A non-null extraction requires exact document text")
        return self

    return create_model(
        f"{rule.document_type.value}{field_key}Result",
        __base__=StrictLLMOutputModel,
        __validators__={"validate_text_evidence": validate_text_evidence},
        extracted=(output_annotation | None, ...),
        evidence=(FieldEvidence, ...),
    )


def _build_extracted_fields_model(rule: DocumentRule) -> type[BaseModel]:
    return create_model(
        f"{rule.document_type.value}ExtractedFields",
        __base__=StrictLLMOutputModel,
        **{
            field.key: (
                _build_evidence_field_model(
                    rule,
                    field.key,
                    field.output_annotation,
                    requires_text_evidence=field.evidence_mode == "text",
                ),
                ...,
            )
            for field in rule.validation_fields
        },
    )


def build_validation_output_model(rule: DocumentRule) -> type[BaseModel]:
    extracted_fields_model = _build_extracted_fields_model(rule)

    match_status_fields = {
        field.key: (VerificationStatus, ...)
        for field in rule.validation_fields
        if field.match_via_llm
    }
    match_statuses_model = create_model(
        f"{rule.document_type.value}MatchStatuses",
        __base__=StrictLLMOutputModel,
        **match_status_fields,
    )
    if match_status_fields:
        match_statuses_definition = (match_statuses_model, ...)
    else:
        match_statuses_definition = (
            match_statuses_model,
            Field(default_factory=match_statuses_model),
        )

    return create_model(
        f"{rule.document_type.value}ExtractionResult",
        __base__=StrictLLMOutputModel,
        matched_dependent_id=(str | None, None),
        extracted_fields=(extracted_fields_model, ...),
        match_statuses=match_statuses_definition,
    )


def _dependents_text(dependents: list[Dependent]) -> str:
    if not dependents:
        return "None"

    lines = []
    for index, dependent in enumerate(dependents):
        lines.append(
            f"- [{index}] {dependent.full_name}; "
            f"DOB: {dependent.date_of_birth}; "
            f"Relationship: {dependent.relationship.value}"
        )
    return "\n".join(lines)


def _dependent_id(index: int) -> str:
    return f"DEP-{index + 1:03d}"


def _effective_dependent_id(index: int, dependent: Dependent) -> str:
    return dependent.dependent_id or _dependent_id(index)


def _eligible_dependents_text(
    document_type: DocumentType,
    dependents: list[Dependent],
) -> str:
    allowed_relationships = set(valid_relationships_for_document(document_type))
    if not allowed_relationships:
        return "None"

    lines = []
    for index, dependent in enumerate(dependents):
        if dependent.relationship not in allowed_relationships:
            continue
        if document_type == DocumentType.BIRTH_CERTIFICATE:
            lines.append(
                f"- {_effective_dependent_id(index, dependent)}: {dependent.full_name}; "
                f"Relationship: {dependent.relationship.value}"
            )
        else:
            lines.append(
                f"- {_effective_dependent_id(index, dependent)}: {dependent.full_name}; "
                f"DOB: {dependent.date_of_birth}; "
                f"Relationship: {dependent.relationship.value}"
            )
    return "\n".join(lines) if lines else "None"


def build_segmentation_prompt(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    doc_name: str,
    num_pages: int,
) -> str:
    return dedent(f"""\
        DOCUMENT: {doc_name}
        PAGE COUNT: {num_pages}

        SUBMITTER:
        - Name: {policy_holder.full_name}
        - DOB: {policy_holder.date_of_birth}

        DEPENDENTS:
        {_dependents_text(dependents)}

        SUPPORTED DOCUMENT TYPES:
        {render_supported_document_types()}

        Return the logical segments for this upload.
    """)


def build_validation_prompt(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    segment: AISegmentClassification,
    rule: DocumentRule,
) -> str:
    required_fields = "\n".join(
        f"- {field.key}: {field.prompt}" for field in rule.validation_fields
    )
    valid_relationships = valid_relationships_for_document(segment.document_type)
    valid_relationship_text = (
        "\n".join(f"- {relationship.value}" for relationship in valid_relationships)
        if valid_relationships
        else "None"
    )

    return dedent(f"""\
        DOCUMENT TYPE: {segment.document_type.value}
        SEGMENT PAGE NUMBERS: {segment.page_numbers}

        SUBMITTER:
        - Name: {policy_holder.full_name}
        - DOB: {policy_holder.date_of_birth}

        ELIGIBLE DEPENDENT RELATIONSHIPS FOR THIS DOCUMENT TYPE:
        {valid_relationship_text}

        ELIGIBLE DEPENDENTS:
        {_eligible_dependents_text(segment.document_type, dependents)}

        DEPENDENT ID RULE:
        Return matched_dependent_id using exactly one of the dependent ids from ELIGIBLE DEPENDENTS above.
        Do not return a name or an index.

        DOCUMENT-SPECIFIC RULE:
        {rule.render_prompt()}

        Required extracted fields:
        {required_fields}
    """)
