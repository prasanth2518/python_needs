"""LLM configuration for the staged document review workflow."""

from os import getenv
from textwrap import dedent
from typing import Literal

import httpx
from pydantic import BaseModel, Field
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

from dev_ai_core.document_rules.base import DocumentRule
from dev_ai_core.document_rules.registry import render_supported_document_types
from dev_ai_core.request import Dependent, PolicyHolder
from dev_ai_core.types import DocumentType, valid_relationships_for_document

VerificationStatus = Literal["PASS", "FAIL"]
DEFAULT_LLM = "openai-chat:gpt-5.4"

SEGMENTATION_SYSTEM_PROMPT = dedent("""\
    You are the segmentation step of a document review workflow.

    Procedure:

    1. Review all pages in the uploaded PDF.
    2. Then, orient all pages by rotating so that the text is right-side up and readable.
    3. Group consecutive pages into logical document segments, but do not merge pages into one segment unless you can confidently tell they belong to the same underlying record or document instance
    4. Assign one document_type to each segment.
    5. Return only the requested schema.

    Rules:
    - Page numbers are 1-based.
    - Page ranges must be non-overlapping.
    - Do not merge consecutive pages into one segment just because they share the same document type; each distinct certificate or record must be its own segment
    - Use OTHER for unsupported, unusable, blurry, unrelated, blank, partially legible, or low-confidence pages.
    - Use OTHER whenever a page or segment cannot be confidently assigned to one of the supported document types.
    - Keep reasoning brief and factual.
""")

VALIDATION_SYSTEM_PROMPT = dedent("""\
    You are the extraction step of a document review workflow.

    Procedure:
    1. Treat the supplied document_type as a fixed input.
    2. First, orient the document by rotating so that the text is right-side up and readable.
    2. Then, choose the best matching dependent from the eligible dependent list using loose document evidence.
    3. Return matched_dependent_id only when one eligible dependent is the clear best match and the document is clear enough to make a confident selection.
    4. Return matched_dependent_id as null if the match is ambiguous or if the document is too blurry to make out the name of the dependent.
    5. After choosing the dependent, extract only the requested values from the provided segment pages.
    6. Return names exactly as instructed for each field.
    7. Return date values in YYYY-MM-DD format when a date is visible.
    8. If a value is not present, return null.
    9. Return only the requested schema.

    Rules:
    - Do not invent values.
    - Do not add extra keys or narrative.
    - Use only the eligible dependent relationships listed in the prompt.
    - When match_statuses are requested for a field, return only PASS or FAIL for that field.
    - When a field asks for an event date, do not substitute issue, filing, recording, certificate, or return dates.
    - When a field instruction asks for a JSON array, return an array and not a string.
    - When a field instruction asks for a JSON object, return an object with exactly the requested keys.
""")


def get_model() -> str:
    return getenv("DEV_AI_MODEL", DEFAULT_LLM)


def get_openai_model_name() -> str:
    model = get_model()
    for prefix in ("openai-chat:", "openai-responses:", "openai:"):
        if model.startswith(prefix):
            return model[len(prefix):]
    return model


def _build_provider() -> OpenAIProvider:
    http_client = httpx.AsyncClient(verify=False)
    return OpenAIProvider(
        base_url=getenv("OPENAI_BASE_URL"),
        api_key=getenv("OPENAI_API_KEY"),
        http_client=http_client,
    )


def build_segmentation_agent() -> Agent:
    model = OpenAIChatModel(
        model_name=get_openai_model_name(),
        provider=_build_provider(),
    )
    return Agent(model=model, system_prompt=SEGMENTATION_SYSTEM_PROMPT)


def build_validation_agent() -> Agent:
    model = OpenAIChatModel(
        model_name=get_openai_model_name(),
        provider=_build_provider(),
    )
    return Agent(model=model, system_prompt=VALIDATION_SYSTEM_PROMPT)


class AISegmentClassification(BaseModel):
    document_type: DocumentType = Field(
        description="Specific document type for the logical segment"
    )
    reasoning: str = Field(
        description="Short explanation of why this segment belongs to that document type"
    )
    matched_target_index: int | None = Field(
        default=None,
        description="Best matching dependent index when one dependent clearly applies",
    )
    page_range: list[int] = Field(
        description="1-based page numbers included in the logical segment"
    )


class AISegmentationResult(BaseModel):
    classifications: list[AISegmentClassification] = Field(default_factory=list)


class AISegmentExtractionResult(BaseModel):
    matched_dependent_id: str | None = Field(
        default=None,
        description="Dependent id chosen during validation from the ELIGIBLE DEPENDENTS list, or null if ambiguous."
    )
    extracted_fields: dict[str, object] = Field(
        default_factory=dict,
        description="Map of requested extracted field keys to their extracted values or null."
    )
    match_statuses: dict[str, VerificationStatus] = Field(
        default_factory=dict,
        description="Optional map of field keys to PASS or FAIL when a rule asks the LLM to make the match decision.",
    )


def _dependents_text(dependents: list[Dependent]) -> str:
    if not dependents:
        return "None"

    lines = []
    for index, dependent in enumerate(dependents):
        lines.append(
            f"- [{index}] {dependent.full_name}; "
            f"DOB: {dependent.date_of_birth}; "
            f"Relationship: {dependent.relationship.value}"
        )
    return "\n".join(lines)


def _dependent_id(index: int) -> str:
    return f"DEP-{index + 1:03d}"


def _eligible_dependents_text(
    document_type: DocumentType,
    dependents: list[Dependent],
) -> str:
    allowed_relationships = set(valid_relationships_for_document(document_type))
    if not allowed_relationships:
        return "None"

    lines = []
    for index, dependent in enumerate(dependents):
        if dependent.relationship not in allowed_relationships:
            continue
        lines.append(
            f"- {_dependent_id(index)}: {dependent.full_name}; "
            f"DOB: {dependent.date_of_birth}; "
            f"Relationship: {dependent.relationship.value}"
        )
    return "\n".join(lines) if lines else "None"


def build_segmentation_prompt(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    doc_name: str,
    num_pages: int,
) -> str:
    return dedent(f"""\
        DOCUMENT: {doc_name}
        PAGE COUNT: {num_pages}

        SUBMITTER:
        - Name: {policy_holder.full_name}
        - DOB: {policy_holder.date_of_birth}

        DEPENDENTS:
        {_dependents_text(dependents)}

        SUPPORTED DOCUMENT TYPES:
        {render_supported_document_types()}

        Return the logical segments for this upload.
    """)


def build_validation_prompt(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    segment: AISegmentClassification,
    rule: DocumentRule,
) -> str:
    required_fields = "\n".join(
        f"- {field.key}: {field.prompt}"
        for field in rule.validation_fields
    )
    valid_relationships = valid_relationships_for_document(segment.document_type)
    valid_relationship_text = (
        "\n".join(f"- {relationship.value}" for relationship in valid_relationships)
        if valid_relationships
        else "None"
    )

    return dedent(f"""\
        DOCUMENT TYPE: {segment.document_type.value}
        PAGE RANGE: {segment.page_range}

        SUBMITTER:
        - Name: {policy_holder.full_name}
        - DOB: {policy_holder.date_of_birth}

        ELIGIBLE DEPENDENT RELATIONSHIPS FOR THIS DOCUMENT TYPE:
        {valid_relationship_text}

        ELIGIBLE DEPENDENTS:
        {_eligible_dependents_text(segment.document_type, dependents)}

        DEPENDENT ID RULE:
        Return matched_dependent_id using one of the DEP-xxx ids from ELIGIBLE DEPENDENTS above.
        Do not return a name or an index.

        DOCUMENT-SPECIFIC RULE:
        {rule.render_prompt()}

        Required extracted fields:
        {required_fields}
    """)
