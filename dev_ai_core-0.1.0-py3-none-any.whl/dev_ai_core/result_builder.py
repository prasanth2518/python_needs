from dev_ai_core.document_rules.base import DocumentRule, ValidationField
from dev_ai_core.document_rules.registry import get_document_rule
from dev_ai_core.llm_workflow import AISegmentClassification, AISegmentExtractionResult
from dev_ai_core.matching_utils import (
    VerificationStatus,
    display_last_name,
    first_name,
    status_from_dob,
    status_from_first_name,
    status_from_last_name,
    status_from_name,
    status_from_presence,
    status_from_signed_yes,
)
from dev_ai_core.request import Dependent, PolicyHolder, SubmittedDocument
from dev_ai_core.result import (
    ClassificationResult,
    DocumentMetadata,
    FileRef,
    UploadedDocumentResult,
    UploadTime,
)
from dev_ai_core.tax_1040_validation import (
    build_tax_1040_validation_details,
    tax_1040_required_keys,
)
from dev_ai_core.types import DocumentType, Relationship


def dependent_id(index: int) -> str:
    return f"DEP-{index + 1:03d}"


def dependent_from_id(
    dependents: list[Dependent],
    candidate_dependent_id: str | None,
) -> tuple[Dependent | None, str | None]:
    if candidate_dependent_id is None:
        return None, None
    for index, dependent in enumerate(dependents):
        resolved_dependent_id = dependent_id(index)
        if resolved_dependent_id == candidate_dependent_id:
            return dependent, resolved_dependent_id
    return None, None


def document_id(index: int) -> str:
    return f"DOC-{index + 1:03d}"


def document_type_label(document_type: DocumentType) -> str:
    return document_type.name


def normalize_page_range(page_range: list[int], max_pages: int) -> list[int]:
    valid_pages = sorted({page for page in page_range if 1 <= page <= max_pages})
    return valid_pages


def submitter_full_name(policy_holder: PolicyHolder) -> str:
    return policy_holder.full_name


def find_spouse_or_dp(dependents: list[Dependent]) -> Dependent | None:
    for dependent in dependents:
        if dependent.relationship in {Relationship.SPOUSE, Relationship.DOMESTIC_PARTNER}:
            return dependent
    return None


def expected_parent_candidates(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    dependent: Dependent | None,
) -> list[tuple[str, str]]:
    candidates: list[tuple[str, str]] = [("submitter", submitter_full_name(policy_holder))]
    if dependent is None:
        return candidates

    if dependent.relationship in {
        Relationship.CHILD,
        Relationship.BIOLOGICAL_CHILD,
        Relationship.ADOPTED_CHILD,
        Relationship.STEP_CHILD,
    }:
        spouse_or_dp = find_spouse_or_dp(dependents)
        if spouse_or_dp is not None:
            candidates.append(("spouseOrDp", spouse_or_dp.full_name))
    return candidates


def expected_parent_role(dependent: Dependent | None) -> str:
    if dependent is not None and dependent.relationship == Relationship.STEP_CHILD:
        return "spouse_or_dp"
    return "employee"


def collect_statuses(value: object) -> list[str]:
    statuses: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            if key == "field_match_status" and isinstance(item, str):
                statuses.append(item)
            else:
                statuses.extend(collect_statuses(item))
    elif isinstance(value, list):
        for item in value:
            statuses.extend(collect_statuses(item))
    return statuses


def field_statuses(value: object) -> list[str]:
    if isinstance(value, dict):
        top_level_status = value.get("field_match_status")
        if isinstance(top_level_status, str):
            return [top_level_status]
    return collect_statuses(value)


def as_extracted_name_list(value: str | list[str] | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        normalized = " ".join(value.strip().split())
        return [normalized] if normalized else []
    extracted_names: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        normalized = " ".join(item.strip().split())
        if normalized:
            extracted_names.append(normalized)
    return extracted_names


def derive_verification_status(
    validation_details: dict[str, object],
    required_keys: list[str],
) -> VerificationStatus:
    if not validation_details or not required_keys:
        return "FAIL"

    statuses: list[str] = []
    for key in required_keys:
        statuses.extend(field_statuses(validation_details.get(key)))
    if not statuses:
        return "FAIL"
    return "PASS" if all(status == "PASS" for status in statuses) else "FAIL"


def verification_code(status: VerificationStatus) -> str:
    return "1000" if status == "PASS" else "2000"


def build_validation_entry(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    dependent: Dependent | None,
    current_dependent_id: str | None,
    field: ValidationField,
    extracted_value: object,
    llm_match_status: VerificationStatus | None,
) -> dict[str, object]:
    if field.match_via_llm:
        if field.comparison == "submitter_name":
            submitted = first_name(policy_holder.full_name)
            return {
                "extracted": extracted_value,
                "submitted": submitted,
                "field_match_status": llm_match_status or "FAIL",
            }
        if field.comparison == "submitter_first_name":
            return {
                "extracted": extracted_value,
                "submitted": first_name(policy_holder.full_name),
                "field_match_status": llm_match_status or "FAIL",
            }
        if field.comparison == "submitter_last_name":
            return {
                "extracted": extracted_value,
                "submitted": display_last_name(policy_holder.full_name),
                "field_match_status": llm_match_status or "FAIL",
            }
        if field.comparison == "dependent_name":
            entry: dict[str, object] = {
                "extracted": extracted_value,
            }
            if current_dependent_id is not None and dependent is not None:
                entry[current_dependent_id] = {
                    "submitted": first_name(dependent.full_name),
                    "field_match_status": llm_match_status or "FAIL",
                }
            else:
                entry["field_match_status"] = "FAIL"
            return entry
        if field.comparison == "dependent_first_name":
            entry = {
                "extracted": extracted_value,
            }
            if current_dependent_id is not None and dependent is not None:
                entry[current_dependent_id] = {
                    "submitted": first_name(dependent.full_name),
                    "field_match_status": llm_match_status or "FAIL",
                }
            else:
                entry["field_match_status"] = "FAIL"
            return entry
        if field.comparison == "dependent_last_name":
            entry = {
                "extracted": extracted_value,
            }
            if current_dependent_id is not None and dependent is not None:
                entry[current_dependent_id] = {
                    "submitted": display_last_name(dependent.full_name),
                    "field_match_status": llm_match_status or "FAIL",
                }
            else:
                entry["field_match_status"] = "FAIL"
            return entry
        return {
            "extracted": extracted_value,
            "field_match_status": llm_match_status or "FAIL",
        }

    if field.comparison == "presence":
        if isinstance(extracted_value, dict):
            raw_extracted = extracted_value.get("extracted")
            reasoning = extracted_value.get("reasoning")
            return {
                "extracted": raw_extracted,
                "reasoning": reasoning,
                "field_match_status": status_from_presence(raw_extracted),
            }
        return {
            "extracted": extracted_value,
            "field_match_status": status_from_presence(extracted_value),
        }
    if field.comparison == "submitter_name":
        submitted = submitter_full_name(policy_holder)
        return {
            "extracted": extracted_value,
            "submitted": submitted,
            "field_match_status": status_from_name(extracted_value, submitted),
        }
    if field.comparison == "submitter_first_name":
        return {
            "extracted": extracted_value,
            "submitted": first_name(policy_holder.full_name),
            "field_match_status": status_from_first_name(
                extracted_value,
                policy_holder.full_name,
            ),
        }
    if field.comparison == "submitter_last_name":
        return {
            "extracted": extracted_value,
            "submitted": display_last_name(policy_holder.full_name),
            "field_match_status": status_from_last_name(
                extracted_value,
                policy_holder.full_name,
            ),
        }
    if field.comparison == "submitter_dob":
        return {
            "extracted": extracted_value,
            "submitted": policy_holder.date_of_birth.isoformat(),
            "field_match_status": status_from_dob(
                extracted_value,
                policy_holder.date_of_birth,
            ),
        }
    if field.comparison == "dependent_name":
        entry: dict[str, object] = {
            "extracted": extracted_value,
        }
        if current_dependent_id is not None and dependent is not None:
            submitted = dependent.full_name
            entry[current_dependent_id] = {
                "submitted": submitted,
                "field_match_status": status_from_name(extracted_value, submitted),
            }
        else:
            entry["field_match_status"] = "FAIL"
        return entry
    if field.comparison == "dependent_first_name":
        entry = {
            "extracted": extracted_value,
        }
        if current_dependent_id is not None and dependent is not None:
            entry[current_dependent_id] = {
                "submitted": first_name(dependent.full_name),
                "field_match_status": status_from_first_name(
                    extracted_value,
                    dependent.full_name,
                ),
            }
        else:
            entry["field_match_status"] = "FAIL"
        return entry
    if field.comparison == "dependent_last_name":
        entry = {
            "extracted": extracted_value,
        }
        if current_dependent_id is not None and dependent is not None:
            entry[current_dependent_id] = {
                "submitted": display_last_name(dependent.full_name),
                "field_match_status": status_from_last_name(
                    extracted_value,
                    dependent.full_name,
                ),
            }
        else:
            entry["field_match_status"] = "FAIL"
        return entry
    if field.comparison == "dependent_dob":
        entry = {
            "extracted": extracted_value,
        }
        if current_dependent_id is not None and dependent is not None:
            entry[current_dependent_id] = {
                "submitted": dependent.date_of_birth.isoformat(),
                "field_match_status": status_from_dob(
                    extracted_value,
                    dependent.date_of_birth,
                ),
            }
        else:
            entry["field_match_status"] = "FAIL"
        return entry
    if field.comparison == "expected_parent_name":
        extracted_names = as_extracted_name_list(extracted_value)
        comparisons: dict[str, object] = {}
        matched_against: list[str] = []
        for candidate_key, submitted in expected_parent_candidates(
            policy_holder,
            dependents,
            dependent,
        ):
            matched_extracted = next(
                (
                    name
                    for name in extracted_names
                    if status_from_name(name, submitted) == "PASS"
                ),
                None,
            )
            comparisons[candidate_key] = {
                "submitted": submitted,
                "matchedExtracted": matched_extracted,
                "field_match_status": "PASS" if matched_extracted is not None else "FAIL",
            }
            if matched_extracted is not None:
                matched_against.append(candidate_key)
        return {
            "extracted": extracted_names or None,
            "comparisons": comparisons,
            "matchedAgainst": matched_against,
            "field_match_status": "PASS" if matched_against else "FAIL",
        }
    if field.comparison == "expected_parent_first_name":
        extracted_names = as_extracted_name_list(extracted_value)
        comparisons: dict[str, object] = {}
        matched_against: list[str] = []
        for candidate_key, submitted in expected_parent_candidates(
            policy_holder,
            dependents,
            dependent,
        ):
            matched_extracted = next(
                (
                    name
                    for name in extracted_names
                    if status_from_first_name(name, submitted) == "PASS"
                ),
                None,
            )
            comparisons[candidate_key] = {
                "submitted": first_name(submitted),
                "matchedExtracted": matched_extracted,
                "field_match_status": "PASS" if matched_extracted is not None else "FAIL",
            }
            if matched_extracted is not None:
                matched_against.append(candidate_key)
        return {
            "extracted": extracted_names or None,
            "comparisons": comparisons,
            "matchedAgainst": matched_against,
            "field_match_status": "PASS" if matched_against else "FAIL",
        }
    if field.comparison == "expected_parent_role":
        submitted = expected_parent_role(dependent)
        return {
            "extracted": extracted_value,
            "submitted": submitted,
            "field_match_status": status_from_name(extracted_value, submitted),
        }
    if field.comparison == "signed_yes":
        if isinstance(extracted_value, dict):
            raw_extracted = extracted_value.get("extracted")
            reasoning = extracted_value.get("reasoning")
            return {
                "extracted": raw_extracted,
                "reasoning": reasoning,
                "field_match_status": status_from_signed_yes(raw_extracted),
            }
        return {
            "extracted": extracted_value,
            "field_match_status": status_from_signed_yes(extracted_value),
        }
    if field.comparison == "official_signed_type":
        return {
            "extracted": extracted_value,
            "field_match_status": _status_from_official_signed_type(extracted_value),
        }
    return {
        "extracted": extracted_value,
        "field_match_status": "FAIL",
    }


def build_validation_details(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    dependent: Dependent | None,
    current_dependent_id: str | None,
    rule: DocumentRule,
    extraction: AISegmentExtractionResult,
) -> dict[str, object]:
    validation_details: dict[str, object] = {}
    for field in rule.validation_fields:
        validation_details[field.key] = build_validation_entry(
            policy_holder,
            dependents,
            dependent,
            current_dependent_id,
            field,
            extraction.extracted_fields.get(field.key),
            extraction.match_statuses.get(field.key),
        )
    return validation_details


def failed_field_labels(
    validation_details: dict[str, object],
    rule: DocumentRule,
) -> list[str]:
    failed: list[str] = []
    for field in rule.validation_fields:
        if not field.required:
            continue
        current_field_statuses = field_statuses(validation_details.get(field.key))
        if not current_field_statuses or any(status != "PASS" for status in current_field_statuses):
            failed.append(field.key)
    return failed


def failed_required_keys(
    validation_details: dict[str, object],
    required_keys: list[str],
) -> list[str]:
    failed: list[str] = []
    for key in required_keys:
        current_field_statuses = field_statuses(validation_details.get(key))
        if not current_field_statuses or any(status != "PASS" for status in current_field_statuses):
            failed.append(key)
    return failed


def build_comment(
    document_type: DocumentType,
    validation_details: dict[str, object],
    rule: DocumentRule,
) -> str:
    failed_fields = failed_field_labels(validation_details, rule)
    if not failed_fields:
        return f"All standardized checks passed for {document_type.name}."
    return (
        f"Standardized verification failed for {document_type.name} because "
        + ", ".join(failed_fields)
        + " did not match."
    )


def build_comment_for_required_keys(
    document_type: DocumentType,
    validation_details: dict[str, object],
    required_keys: list[str],
) -> str:
    failed_fields = failed_required_keys(validation_details, required_keys)
    if not failed_fields:
        return f"All standardized checks passed for {document_type.name}."
    return (
        f"Standardized verification failed for {document_type.name} because "
        + ", ".join(failed_fields)
        + " did not match."
    )


def build_other_classification(
    page_range: list[int],
    reasoning: str,
    matched_dependent: str | None = None,
) -> ClassificationResult:
    return ClassificationResult(
        document_type="OTHER",
        reasoning=reasoning,
        matched_dependent=matched_dependent,
        page_range=page_range,
        verification_status="FAIL",
        verification_code="4000",
        validation_details={},
        comment="Document is unsupported or unrelated for standardized validation.",
    )


def build_merged_other_classification(
    segments: list[AISegmentClassification],
    max_pages: int,
) -> ClassificationResult:
    merged_page_range = normalize_page_range(
        [page for segment in segments for page in segment.page_range],
        max_pages,
    )
    merged_reasons: list[str] = []
    for segment in segments:
        reason = segment.reasoning.strip()
        if reason and reason not in merged_reasons:
            merged_reasons.append(reason)
    reasoning = (
        " ".join(merged_reasons)
        if merged_reasons
        else "Pages are unsupported or unrelated to dependent verification."
    )
    return build_other_classification(
        page_range=merged_page_range,
        reasoning=reasoning,
    )


def build_tax_1040_classification(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    segment: AISegmentClassification,
    extraction: AISegmentExtractionResult,
    max_pages: int,
) -> ClassificationResult:
    dependent, current_dependent_id = dependent_from_id(
        dependents,
        extraction.matched_dependent_id,
    )
    raw_filing_status = extraction.extracted_fields.get("filingStatus")
    from dev_ai_core.matching_utils import normalize_filing_status

    filing_status = normalize_filing_status(
        raw_filing_status if isinstance(raw_filing_status, str) else None
    )
    required_keys = tax_1040_required_keys(filing_status)

    validation_details = build_tax_1040_validation_details(
        policy_holder,
        dependent,
        current_dependent_id,
        extraction,
    )
    verification_status = derive_verification_status(
        validation_details,
        required_keys,
    )

    return ClassificationResult(
        document_type=document_type_label(segment.document_type),
        reasoning=segment.reasoning,
        matched_dependent=current_dependent_id,
        page_range=normalize_page_range(segment.page_range, max_pages),
        verification_status=verification_status,
        verification_code=verification_code(verification_status),
        validation_details=validation_details,
        comment=build_comment_for_required_keys(
            segment.document_type,
            validation_details,
            required_keys,
        ),
    )


def build_supported_classification(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    segment: AISegmentClassification,
    extraction: AISegmentExtractionResult,
    max_pages: int,
) -> ClassificationResult:
    rule = get_document_rule(segment.document_type)
    if rule is None:
        return build_other_classification(
            page_range=normalize_page_range(segment.page_range, max_pages),
            reasoning=segment.reasoning,
            matched_dependent=extraction.matched_dependent_id,
        )

    if segment.document_type == DocumentType.TAX_RETURN_1040:
        return build_tax_1040_classification(
            policy_holder,
            dependents,
            segment,
            extraction,
            max_pages,
        )

    dependent, current_dependent_id = dependent_from_id(
        dependents,
        extraction.matched_dependent_id,
    )

    validation_details = build_validation_details(
        policy_holder,
        dependents,
        dependent,
        current_dependent_id,
        rule,
        extraction,
    )
    verification_status = derive_verification_status(
        validation_details,
        [field.key for field in rule.validation_fields if field.required],
    )

    return ClassificationResult(
        document_type=document_type_label(segment.document_type),
        reasoning=segment.reasoning,
        matched_dependent=current_dependent_id,
        page_range=normalize_page_range(segment.page_range, max_pages),
        verification_status=verification_status,
        verification_code=verification_code(verification_status),
        validation_details=validation_details,
        comment=build_comment(
            segment.document_type,
            validation_details,
            rule,
        ),
    )


def fallback_invalid_classification(document: SubmittedDocument) -> ClassificationResult:
    return ClassificationResult(
        document_type="OTHER",
        reasoning="No valid logical segment was produced for this upload.",
        matched_dependent=None,
        page_range=list(range(1, len(document.images) + 1)),
        verification_status="FAIL",
        verification_code="4000",
        validation_details={},
        comment="Document could not be standardized into a supported classification.",
    )


def build_uploaded_document(
    index: int,
    document: SubmittedDocument,
) -> UploadedDocumentResult:
    file_name = document.file_name or f"{document.name}.pdf"
    return UploadedDocumentResult(
        document_id=document_id(index),
        file_name=file_name,
        file_ref=FileRef(file_id=document.name),
        metadata=DocumentMetadata(
            mime_type=document.mime_type,
            size_bytes=document.size_bytes,
        ),
        upload_time=UploadTime(
            as_of=document.uploaded_at,
            timezone=document.upload_timezone,
        ),
    )
