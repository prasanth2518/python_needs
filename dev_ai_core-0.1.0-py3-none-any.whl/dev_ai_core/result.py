from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from dev_ai_core.camel_case_base import CamelCaseModel


class UploadTime(CamelCaseModel):
    as_of: datetime | None = None
    timezone: str | None = None


class UploadedDocumentResult(CamelCaseModel):
    document_id: str
    file_name: str
    upload_time: UploadTime


class ClassificationResult(CamelCaseModel):
    document_type: str
    reasoning: str
    matched_dependent: str | None = None
    page_range: list[int]
    verification_status: Literal["PASS", "FAIL"]
    verification_code: str | None = None
    validation_details: dict[str, Any] = Field(default_factory=dict)
    comment: str | None = None


class DocumentAnalysisResult(CamelCaseModel):
    classifications: list[ClassificationResult]


class ReviewedDocument(CamelCaseModel):
    uploaded_document: UploadedDocumentResult
    result: DocumentAnalysisResult


class FullResult(CamelCaseModel):
    doc_list: list[ReviewedDocument]
