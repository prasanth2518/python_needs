from __future__ import annotations

from contextvars import ContextVar
from typing import Any


_usage_records: ContextVar[list[dict[str, Any]] | None] = ContextVar(
    "dev_ai_core_usage_records",
    default=None,
)


def reset_llm_usage() -> None:
    _usage_records.set([])


def get_llm_usage() -> list[dict[str, Any]]:
    return list(_usage_records.get() or [])


def clear_llm_usage() -> None:
    _usage_records.set(None)


def record_llm_usage(
    *,
    phase: str,
    document_name: str | None,
    page_numbers: list[int] | None,
    model: str,
    result: Any,
) -> None:
    records = _usage_records.get()
    if records is None:
        return

    usage = getattr(result, "usage", None)
    if usage is None:
        return

    input_tokens = int(getattr(usage, "input_tokens", 0) or 0)
    output_tokens = int(getattr(usage, "output_tokens", 0) or 0)
    records.append(
        {
            "phase": phase,
            "documentName": document_name,
            "pageNumbers": page_numbers,
            "model": model,
            "requests": int(getattr(usage, "requests", 0) or 0),
            "toolCalls": int(getattr(usage, "tool_calls", 0) or 0),
            "inputTokens": input_tokens,
            "outputTokens": output_tokens,
            "totalTokens": input_tokens + output_tokens,
            "cacheWriteTokens": int(getattr(usage, "cache_write_tokens", 0) or 0),
            "cacheReadTokens": int(getattr(usage, "cache_read_tokens", 0) or 0),
            "details": dict(getattr(usage, "details", {}) or {}),
        }
    )
