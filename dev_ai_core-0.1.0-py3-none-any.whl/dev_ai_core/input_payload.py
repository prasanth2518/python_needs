from datetime import date, datetime

from pydantic import model_validator

from dev_ai_core.camel_case_base import CamelCaseModel


class InputRoute(CamelCaseModel):
    domain: str | None = None
    apiver: str | None = None
    client_id: str | None = None
    app_client: str | None = None
    request_guid: str | None = None
    request_type: str | None = None


class InputAddress(CamelCaseModel):
    street: str
    street2: str | None = None
    city: str
    state: str
    zip: str
    zip_4: str | None = None
    country: str


class InputSubmitter(CamelCaseModel):
    member_id: str | None = None
    submitter_name: str
    submitter_dob: date
    address: InputAddress


class InputDependent(CamelCaseModel):
    dependent_id: str
    dependent_name: str
    dob: date
    relationship: str


class InputUploadedDocument(CamelCaseModel):
    document_id: str | None = None
    file_name: str | None = None
    local_file_path: str
    upload_time: datetime | None = None
    mime_type: str | None = None
    size_bytes: int | None = None


class InputDocumentListItem(CamelCaseModel):
    uploaded_document: InputUploadedDocument


class InputPayload(CamelCaseModel):
    route: InputRoute | None = None
    submitter: InputSubmitter
    dependents: list[InputDependent]
    doc_list: list[InputDocumentListItem]

    @model_validator(mode="after")
    def validate_dependent_ids(self) -> "InputPayload":
        dependent_ids = [dependent.dependent_id for dependent in self.dependents]
        if len(dependent_ids) != len(set(dependent_ids)):
            raise ValueError("Each dependentId must be unique.")
        return self
