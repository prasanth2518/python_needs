"""Strict structured-output types shared by document extraction rules."""

from typing import Annotated, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictFloat,
    StrictInt,
    StrictStr,
    StringConstraints,
)

NonEmptyText = Annotated[
    StrictStr,
    StringConstraints(strip_whitespace=True, min_length=1, max_length=1000),
]

TextValue: TypeAlias = StrictStr
TaxYearValue: TypeAlias = StrictStr | StrictInt | StrictFloat
FilingStatusValue: TypeAlias = Literal["MFJ", "MFS", "HOH"]
YesNoValue: TypeAlias = Literal["yes", "no"]
ParentNamesValue: TypeAlias = Annotated[list[NonEmptyText], Field(max_length=2)]


class StrictExtractionModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        strict=True,
        populate_by_name=True,
    )


class FieldEvidence(StrictExtractionModel):
    exact_text: list[NonEmptyText] = Field(alias="exactText", max_length=4)
    reasoning: NonEmptyText
