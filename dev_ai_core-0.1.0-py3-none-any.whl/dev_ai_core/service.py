import asyncio

from dev_ai_core.ingestion import ingest_payload, load_input_payload
from dev_ai_core.result import FullResult
from dev_ai_core.standardized_processor import process


async def run_payload(payload: dict) -> FullResult:
    input_payload = load_input_payload(payload)
    policy_holder, dependents, documents = ingest_payload(input_payload)
    return await process(policy_holder, dependents, documents)


def run_payload_sync(payload: dict) -> dict:
    result = asyncio.run(run_payload(payload))
    return result.model_dump(by_alias=True, mode="json")
