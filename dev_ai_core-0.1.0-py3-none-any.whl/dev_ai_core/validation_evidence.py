"""Helpers for attaching extraction evidence to validation output fields."""

from dev_ai_core.llm_workflow import AISegmentExtractionResult


def field_evidence(
    extraction: AISegmentExtractionResult,
    field_key: str,
) -> dict[str, object]:
    evidence = extraction.field_evidence.get(field_key)
    if isinstance(evidence, dict):
        return evidence
    return {
        "exactText": [],
        "reasoning": "No extraction evidence was returned for this field.",
    }


def attach_evidence(
    entry: dict[str, object],
    evidence: dict[str, object],
) -> dict[str, object]:
    result: dict[str, object] = {
        "extracted": entry.get("extracted"),
        "evidence": evidence,
    }
    result.update({key: value for key, value in entry.items() if key != "extracted"})
    return result
