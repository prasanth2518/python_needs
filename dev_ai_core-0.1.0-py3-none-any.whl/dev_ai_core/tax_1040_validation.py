from dev_ai_core.llm_workflow import AISegmentExtractionResult
from dev_ai_core.matching_utils import (
    VerificationStatus,
    display_last_name,
    first_name,
    normalize_filing_status,
    status_from_first_name,
    status_from_last_name,
    status_from_presence,
    status_from_supported_1040_filing_status,
)
from dev_ai_core.request import Dependent, PolicyHolder


def build_presence_entry(extracted_value: object) -> dict[str, object]:
    if isinstance(extracted_value, str):
        extracted = extracted_value
    else:
        extracted = None
    return {
        "extracted": extracted_value,
        "field_match_status": status_from_presence(extracted),
    }


def build_tax_1040_filing_status_entry(extracted_value: object) -> dict[str, object]:
    extracted = extracted_value if isinstance(extracted_value, str) else None
    return {
        "extracted": extracted,
        "field_match_status": status_from_supported_1040_filing_status(extracted),
    }


def tax_1040_slot_pair_statuses(
    extracted_first: str | None,
    extracted_last: str | None,
    submitted_full_name: str,
) -> tuple[VerificationStatus, VerificationStatus]:
    return (
        status_from_first_name(extracted_first, submitted_full_name),
        status_from_last_name(extracted_last, submitted_full_name),
    )


def tax_1040_party_specs(
    policy_holder: PolicyHolder,
    dependent: Dependent | None,
    dependent_id: str | None,
) -> dict[str, str]:
    parties: dict[str, str] = {
        "submitter": policy_holder.full_name,
    }
    if dependent is not None and dependent_id is not None:
        parties[dependent_id] = dependent.full_name
    return parties


def tax_1040_assignment_options(
    filing_status: str | None,
    dependent_id: str | None,
) -> list[dict[str, str | None]]:
    if dependent_id is None:
        return []
    if filing_status in {"mfj", "mfs"}:
        return [
            {"primary": "submitter", "spouseField": dependent_id},
            {"primary": dependent_id, "spouseField": "submitter"},
        ]
    if filing_status == "hoh":
        return [{"primary": dependent_id, "spouseField": None}]
    return []


def tax_1040_assignment_score(
    assignment: dict[str, str | None],
    parties: dict[str, str],
    extracted_primary_first: str | None,
    extracted_primary_last: str | None,
    extracted_spouse_first: str | None,
    extracted_spouse_last: str | None,
) -> tuple[bool, int]:
    total_score = 0
    all_required_pass = True

    for slot_name, extracted_first, extracted_last in (
        ("primary", extracted_primary_first, extracted_primary_last),
        ("spouseField", extracted_spouse_first, extracted_spouse_last),
    ):
        party_label = assignment.get(slot_name)
        if party_label is None:
            continue
        submitted_full_name = parties[party_label]
        first_status, last_status = tax_1040_slot_pair_statuses(
            extracted_first,
            extracted_last,
            submitted_full_name,
        )
        total_score += int(first_status == "PASS") + int(last_status == "PASS")
        if first_status != "PASS" or last_status != "PASS":
            all_required_pass = False

    return all_required_pass, total_score


def select_tax_1040_assignment(
    filing_status: str | None,
    policy_holder: PolicyHolder,
    dependent: Dependent | None,
    dependent_id: str | None,
    extraction: AISegmentExtractionResult,
) -> dict[str, str | None]:
    parties = tax_1040_party_specs(policy_holder, dependent, dependent_id)
    options = tax_1040_assignment_options(filing_status, dependent_id)
    if not options:
        return {}

    extracted_primary_first = extraction.extracted_fields.get("primaryFilerFirstName")
    extracted_primary_last = extraction.extracted_fields.get("primaryFilerLastName")
    extracted_spouse_first = extraction.extracted_fields.get("spouseFieldFirstName")
    extracted_spouse_last = extraction.extracted_fields.get("spouseFieldLastName")

    best_assignment: dict[str, str | None] | None = None
    best_complete = False
    best_score = -1

    for assignment in options:
        complete, score = tax_1040_assignment_score(
            assignment,
            parties,
            extracted_primary_first if isinstance(extracted_primary_first, str) else None,
            extracted_primary_last if isinstance(extracted_primary_last, str) else None,
            extracted_spouse_first if isinstance(extracted_spouse_first, str) else None,
            extracted_spouse_last if isinstance(extracted_spouse_last, str) else None,
        )
        if complete and not best_complete:
            best_assignment = assignment
            best_complete = True
            best_score = score
            continue
        if complete == best_complete and score > best_score:
            best_assignment = assignment
            best_score = score

    return best_assignment or {}


def build_tax_1040_name_entry(
    extracted_value: object,
    selected_label: str | None,
    parties: dict[str, str],
    *,
    part: str,
    comparisons_enabled: bool = True,
) -> dict[str, object]:
    extracted = extracted_value if isinstance(extracted_value, str) else None
    if not comparisons_enabled:
        return {
            "extracted": extracted,
            "comparisons": {},
            "matchedAgainst": None,
            "field_match_status": "FAIL",
        }

    comparisons: dict[str, object] = {}
    for label, submitted_full_name in parties.items():
        submitted = (
            first_name(submitted_full_name)
            if part == "first"
            else display_last_name(submitted_full_name)
        )
        status = (
            status_from_first_name(extracted, submitted_full_name)
            if part == "first"
            else status_from_last_name(extracted, submitted_full_name)
        )
        comparisons[label] = {
            "submitted": submitted,
            "field_match_status": status,
        }

    selected_status = "FAIL"
    matched_against: str | None = None
    if selected_label is not None:
        selected_entry = comparisons.get(selected_label)
        if isinstance(selected_entry, dict):
            selected_status = str(selected_entry.get("field_match_status", "FAIL"))
            if selected_status == "PASS":
                matched_against = selected_label

    return {
        "extracted": extracted,
        "comparisons": comparisons,
        "matchedAgainst": matched_against,
        "field_match_status": selected_status,
    }


def tax_1040_required_keys(filing_status: str | None) -> list[str]:
    base_keys = [
        "filingStatus",
        "taxYear",
        "primaryFilerFirstName",
        "primaryFilerLastName",
    ]
    if filing_status in {"mfj", "mfs"}:
        return base_keys + [
            "spouseFieldFirstName",
            "spouseFieldLastName",
        ]
    return base_keys


def build_tax_1040_validation_details(
    policy_holder: PolicyHolder,
    dependent: Dependent | None,
    dependent_id: str | None,
    extraction: AISegmentExtractionResult,
) -> dict[str, object]:
    extracted_fields = extraction.extracted_fields
    raw_filing_status = extracted_fields.get("filingStatus")
    filing_status = normalize_filing_status(
        raw_filing_status if isinstance(raw_filing_status, str) else None
    )
    parties = tax_1040_party_specs(policy_holder, dependent, dependent_id)
    assignment = select_tax_1040_assignment(
        filing_status,
        policy_holder,
        dependent,
        dependent_id,
        extraction,
    )
    spouse_field_comparisons_enabled = filing_status in {"mfj", "mfs"}

    return {
        "filingStatus": build_tax_1040_filing_status_entry(raw_filing_status),
        "taxYear": build_presence_entry(extracted_fields.get("taxYear")),
        "primaryFilerFirstName": build_tax_1040_name_entry(
            extracted_fields.get("primaryFilerFirstName"),
            assignment.get("primary"),
            parties,
            part="first",
        ),
        "primaryFilerLastName": build_tax_1040_name_entry(
            extracted_fields.get("primaryFilerLastName"),
            assignment.get("primary"),
            parties,
            part="last",
        ),
        "spouseFieldFirstName": build_tax_1040_name_entry(
            extracted_fields.get("spouseFieldFirstName"),
            assignment.get("spouseField"),
            parties,
            part="first",
            comparisons_enabled=spouse_field_comparisons_enabled,
        ),
        "spouseFieldLastName": build_tax_1040_name_entry(
            extracted_fields.get("spouseFieldLastName"),
            assignment.get("spouseField"),
            parties,
            part="last",
            comparisons_enabled=spouse_field_comparisons_enabled,
        ),
    }
