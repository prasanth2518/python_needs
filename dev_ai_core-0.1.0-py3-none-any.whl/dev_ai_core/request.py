from datetime import date, datetime

from pydantic import model_validator

from dev_ai_core.camel_case_base import CamelCaseModel
from dev_ai_core.matching_utils import display_last_name, first_name
from dev_ai_core.types import Relationship


class Address(CamelCaseModel):
    street: str
    street2: str | None = None
    city: str
    state: str
    zip: str
    zip_4: str | None = None
    country: str


class Person(CamelCaseModel):
    first_name: str = ""
    last_name: str = ""
    full_name: str = ""
    date_of_birth: date

    @model_validator(mode="after")
    def populate_names(self) -> "Person":
        combined_name = " ".join(
            part for part in (self.first_name.strip(), self.last_name.strip()) if part
        ).strip()
        normalized_full_name = self.full_name.strip() or combined_name
        if not normalized_full_name:
            raise ValueError("Either full_name or first_name/last_name must be provided.")

        if not self.first_name.strip():
            self.first_name = first_name(normalized_full_name)
        if not self.last_name.strip():
            self.last_name = display_last_name(normalized_full_name)
        self.full_name = normalized_full_name
        return self


class PolicyHolder(Person):
    address: Address


class Dependent(Person):
    relationship: Relationship


class SubmittedDocument(CamelCaseModel):
    name: str
    images: list[bytes]
    file_name: str | None = None
    mime_type: str = "application/pdf"
    size_bytes: int | None = None
    uploaded_at: datetime | None = None
    upload_timezone: str | None = None
