from enum import Enum


class EnumWithDesc(str, Enum):
    description: str

    def __new__(cls, value, description):
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj.description = description
        return obj


class DocumentType(EnumWithDesc):
    BIRTH_CERTIFICATE = (
        "birth_certificate",
        "Official birth certificate or certified state vital record intended to serve as a legal birth record, showing child name, DOB, and parent names. Do not use this for proof-of-birth letters, hospital birth announcements, birth worksheets, verification letters, or informal birth notices",
    )
    MARRIAGE_CERTIFICATE = (
        "marriage_certificate",
        "Marriage certificate or Marriage License listing the submitter and spouse or domestic partner names, a marriage date confirming vows were solemnized, and an officiant signature",
    )
    STATE_ISSUED_MARRIAGE_CERTIFICATE = (
        "state_issued_marriage_certificate",
        "Marriage certificate or Marriage License listing the submitter and spouse or domestic partner names, a marriage date confirming vows were solemnized, an officiant signature, and an indication that the document was issued by a city, county, or state authority",
    )
    TAX_RETURN_1040 =  (
        "tax_return_1040",
        "Official IRS Form 1040 pages only. Classify only official Form 1040 "
        "page 1 and/or page 2 as tax_return_1040 when each page is clearly labeled "
        "Form 1040 and belongs to the same taxpayer and tax year. If only one "
        "official Form 1040 page is present, classify that page as tax_return_1040. "
        "Do not include schedules, worksheets, W-2s, 1099s, state returns, cover "
        "pages, instruction pages, or supporting tax attachments."
    )
    OTHER = (
        "other",
        "Any unsupported, unrelated, blank, unusable, blurry, low-confidence, or "
        "non-target document page. Also use other for tax packet pages that are "
        "not official IRS Form 1040 page 1 or page 2, including schedules, "
        "worksheets, W-2s, 1099s, state returns, cover pages, instruction pages, "
        "and supporting tax attachments."
    )


def _verified_by(doc_types: list[DocumentType], note: str = "") -> str:
    docs_str = ", ".join(d.value for d in doc_types)
    if note:
        return f"Verified by: [{docs_str}]. {note}"
    return f"Verified by: [{docs_str}]"


class Relationship(EnumWithDesc):
    SPOUSE = (
        "spouse",
        _verified_by(
            [DocumentType.MARRIAGE_CERTIFICATE, DocumentType.TAX_RETURN_1040],
            "Marriage cert lists both names; 1040 shows married filing status",
        ),
    )
    DOMESTIC_PARTNER = (
        "domestic_partner",
        _verified_by(
            [DocumentType.MARRIAGE_CERTIFICATE],
            "Domestic partnership variant of marriage certificate",
        ),
    )
    CHILD = (
        "child",
        _verified_by(
            [DocumentType.BIRTH_CERTIFICATE],
            "Birth cert shows the child and parent on record; the parent may be the policy holder or spouse/domestic partner from the payload",
        ),
    )
    BIOLOGICAL_CHILD = (
        "biological_child",
        _verified_by(
            [DocumentType.BIRTH_CERTIFICATE],
            "Policy holder or spouse listed as parent",
        ),
    )
    ADOPTED_CHILD = (
        "adopted_child",
        _verified_by(
            [DocumentType.BIRTH_CERTIFICATE],
            "Amended birth certificate showing adoptive parents",
        ),
    )
    STEP_CHILD = (
        "step_child",
        _verified_by(
            [DocumentType.BIRTH_CERTIFICATE, DocumentType.MARRIAGE_CERTIFICATE],
            "Birth cert shows biological parent; marriage cert links that parent to policy holder",
        ),
    )


RELATIONSHIP_DOCUMENT_TYPES: dict[Relationship, tuple[DocumentType, ...]] = {
    Relationship.SPOUSE: (
        DocumentType.MARRIAGE_CERTIFICATE,
        DocumentType.STATE_ISSUED_MARRIAGE_CERTIFICATE,
        DocumentType.TAX_RETURN_1040,
    ),
    Relationship.DOMESTIC_PARTNER: (
        DocumentType.MARRIAGE_CERTIFICATE,
        DocumentType.STATE_ISSUED_MARRIAGE_CERTIFICATE,
        DocumentType.TAX_RETURN_1040,
    ),
    Relationship.CHILD: (DocumentType.BIRTH_CERTIFICATE,),
    Relationship.BIOLOGICAL_CHILD: (DocumentType.BIRTH_CERTIFICATE,),
    Relationship.ADOPTED_CHILD: (DocumentType.BIRTH_CERTIFICATE,),
    Relationship.STEP_CHILD: (
        DocumentType.BIRTH_CERTIFICATE,
        DocumentType.MARRIAGE_CERTIFICATE,
        DocumentType.STATE_ISSUED_MARRIAGE_CERTIFICATE,
    ),
}

DOCUMENT_TYPE_RELATIONSHIPS: dict[DocumentType, tuple[Relationship, ...]] = {
    document_type: tuple(
        relationship
        for relationship, document_types in RELATIONSHIP_DOCUMENT_TYPES.items()
        if document_type in document_types
    )
    for document_type in DocumentType
}


def valid_relationships_for_document(document_type: DocumentType) -> tuple[Relationship, ...]:
    relationships = DOCUMENT_TYPE_RELATIONSHIPS.get(document_type, ())
    return relationships if relationships else tuple(Relationship)
