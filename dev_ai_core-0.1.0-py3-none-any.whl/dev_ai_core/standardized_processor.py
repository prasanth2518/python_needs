"""Standardized document review pipeline with staged prompting."""

import json
import logging
import os
from pathlib import Path

from pydantic_ai import BinaryImage, UnexpectedModelBehavior

from dev_ai_core.document_rules.base import DocumentRule
from dev_ai_core.document_rules.registry import get_document_rule
from dev_ai_core.llm_usage import record_llm_usage
from dev_ai_core.llm_workflow import (
    AIOrientedSegmentationResult,
    AISegmentClassification,
    AISegmentExtractionResult,
    build_segmentation_agent,
    build_segmentation_prompt,
    build_validation_agent,
    build_validation_output_model,
    build_validation_prompt,
    get_openai_model_name,
)
from dev_ai_core.orientation import (
    OrientationDecision,
    orient_images_from_llm,
    save_oriented_pages,
)
from dev_ai_core.request import Dependent, PolicyHolder, SubmittedDocument
from dev_ai_core.result import (
    ClassificationResult,
    DocumentAnalysisResult,
    FullResult,
    ReviewedDocument,
)
from dev_ai_core.result_builder import (
    build_merged_other_classification,
    build_supported_classification,
    build_uploaded_document,
    fallback_invalid_classification,
)
from dev_ai_core.types import DocumentType

logger = logging.getLogger(__name__)


def _write_classification_debug(
    submitted_document: SubmittedDocument,
    *,
    debug_source: str,
    segmentation_image_state: str,
    validation_image_state: str,
    segments: list[AISegmentClassification],
    orientation_decisions: list[OrientationDecision],
) -> None:
    debug_path_value = os.getenv("DEV_AI_CORE_DEBUG_CLASSIFICATION_PATH")
    if not debug_path_value:
        return

    debug_record: dict[str, object] = {
        "documentName": submitted_document.file_name or submitted_document.name,
        "debugSource": debug_source,
        "orientationMode": "llm",
        "segmentationImageState": segmentation_image_state,
        "validationImageState": validation_image_state,
        "pageOrientations": [
            {
                "pageNumber": page_number,
                "reportedTopEdge": decision.reported_top_edge,
                "detectedRotation": decision.detected_rotation,
                "appliedRotation": decision.applied_rotation,
                "confidence": decision.confidence,
                "orientationUncertain": decision.uncertain,
                "detail": decision.detail,
            }
            for page_number, decision in enumerate(orientation_decisions, start=1)
        ],
        "classifications": [
            {
                "documentType": segment.document_type.value,
                "pageNumbers": segment.page_numbers,
                "reasoning": segment.reasoning,
            }
            for segment in segments
        ],
    }
    run_number = os.getenv("DEV_AI_CORE_DEBUG_RUN")
    if run_number:
        debug_record["run"] = int(run_number) if run_number.isdigit() else run_number

    debug_path = Path(debug_path_value)
    debug_path.parent.mkdir(parents=True, exist_ok=True)
    with debug_path.open("a", encoding="utf-8") as debug_file:
        debug_file.write(
            json.dumps(debug_record, ensure_ascii=False, default=str) + "\n"
        )


def _write_validation_debug(
    submitted_document: SubmittedDocument,
    segment: AISegmentClassification,
    matched_dependent_id: str | None,
    extracted_fields: dict[str, object],
    field_evidence: dict[str, dict[str, object]],
    match_statuses: dict[str, object],
) -> None:
    debug_path_value = os.getenv("DEV_AI_CORE_DEBUG_VALIDATION_PATH")
    if not debug_path_value:
        return

    debug_record: dict[str, object] = {
        "documentName": submitted_document.file_name or submitted_document.name,
        "documentType": segment.document_type.value,
        "pageNumbers": segment.page_numbers,
        "matchedDependentId": matched_dependent_id,
        "extractedFields": extracted_fields,
        "fieldEvidence": field_evidence,
        "matchStatuses": match_statuses,
    }
    run_number = os.getenv("DEV_AI_CORE_DEBUG_RUN")
    if run_number:
        debug_record["run"] = int(run_number) if run_number.isdigit() else run_number

    debug_path = Path(debug_path_value)
    debug_path.parent.mkdir(parents=True, exist_ok=True)
    with debug_path.open("a", encoding="utf-8") as debug_file:
        debug_file.write(
            json.dumps(debug_record, ensure_ascii=False, default=str) + "\n"
        )


def _unpack_extracted_fields(
    strict_extracted_fields: object,
) -> tuple[dict[str, object], dict[str, dict[str, object]]]:
    structured_fields = strict_extracted_fields.model_dump(by_alias=True)
    extracted_fields: dict[str, object] = {}
    field_evidence: dict[str, dict[str, object]] = {}
    for key, value in structured_fields.items():
        extracted_fields[key] = value.get("extracted")
        field_evidence[key] = value["evidence"]
    return extracted_fields, field_evidence


def _structured_extraction_fallback(
    rule: DocumentRule,
) -> AISegmentExtractionResult:
    reason = "A valid structured extraction could not be produced after retry."
    return AISegmentExtractionResult(
        matched_dependent_id=None,
        extracted_fields={field.key: None for field in rule.validation_fields},
        match_statuses={},
        field_evidence={
            field.key: {
                "exactText": [],
                "reasoning": reason,
            }
            for field in rule.validation_fields
        },
    )


async def _segment_document(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    submitted_document: SubmittedDocument,
) -> AIOrientedSegmentationResult:
    agent = build_segmentation_agent(include_page_orientation=True)
    user_prompt: list = []
    for page_number, image in enumerate(submitted_document.images, start=1):
        user_prompt.append(f"PAGE {page_number}")
        user_prompt.append(BinaryImage(data=image, media_type="image/png"))
    user_prompt.append(
        build_segmentation_prompt(
            policy_holder,
            dependents,
            submitted_document.name,
            len(submitted_document.images),
        )
    )
    res = await agent.run(
        user_prompt=user_prompt,
        output_type=AIOrientedSegmentationResult,
    )
    record_llm_usage(
        phase="segmentation",
        document_name=submitted_document.file_name or submitted_document.name,
        page_numbers=list(range(1, len(submitted_document.images) + 1)),
        model=get_openai_model_name(),
        result=res,
    )
    return res.output


async def _extract_segment(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    submitted_document: SubmittedDocument,
    segment: AISegmentClassification,
) -> AISegmentExtractionResult:
    rule = get_document_rule(segment.document_type)
    if rule is None:
        return AISegmentExtractionResult()

    agent = build_validation_agent()
    images = [
        BinaryImage(
            data=submitted_document.images[page_number - 1],
            media_type="image/png",
        )
        for page_number in segment.page_numbers
        if 1 <= page_number <= len(submitted_document.images)
    ]
    images.append(
        build_validation_prompt(
            policy_holder,
            dependents,
            segment,
            rule,
        )
    )
    output_model = build_validation_output_model(rule)
    try:
        res = await agent.run(user_prompt=images, output_type=output_model)
    except UnexpectedModelBehavior:
        logger.exception(
            "Validation output remained invalid after retry for %s",
            segment.document_type.value,
        )
        return _structured_extraction_fallback(rule)
    record_llm_usage(
        phase="validation",
        document_name=submitted_document.file_name or submitted_document.name,
        page_numbers=segment.page_numbers,
        model=get_openai_model_name(),
        result=res,
    )
    strict_output = res.output
    extracted_fields, field_evidence = _unpack_extracted_fields(
        strict_output.extracted_fields
    )
    match_statuses = strict_output.match_statuses.model_dump()
    _write_validation_debug(
        submitted_document=submitted_document,
        segment=segment,
        matched_dependent_id=strict_output.matched_dependent_id,
        extracted_fields=extracted_fields,
        field_evidence=field_evidence,
        match_statuses=match_statuses,
    )
    return AISegmentExtractionResult(
        matched_dependent_id=strict_output.matched_dependent_id,
        extracted_fields=extracted_fields,
        match_statuses=match_statuses,
        field_evidence=field_evidence,
    )


async def process(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    documents: list[SubmittedDocument],
) -> FullResult:
    reviewed_documents: list[ReviewedDocument] = []

    for doc_index, document in enumerate(documents):
        segmentation_image_state = "original"
        validation_image_state = "oriented"

        segmentation = await _segment_document(
            policy_holder,
            dependents,
            document,
        )

        page_top_edges = [
            (
                orientation.page_number,
                orientation.document_top_edge,
            )
            for orientation in segmentation.page_orientations
        ]
        oriented_images, orientation_decisions = orient_images_from_llm(
            document.images,
            page_top_edges,
        )
        if all(decision.uncertain for decision in orientation_decisions):
            validation_image_state = "original"
        elif any(decision.uncertain for decision in orientation_decisions):
            validation_image_state = "partially_oriented"
        save_oriented_pages(
            approach="llm",
            document_name=document.file_name or document.name,
            document_index=doc_index,
            images=oriented_images,
            decisions=orientation_decisions,
        )
        validation_document = document.model_copy(
            update={"images": oriented_images}
        )

        _write_classification_debug(
            document,
            debug_source="pipeline",
            segmentation_image_state=segmentation_image_state,
            validation_image_state=validation_image_state,
            segments=segmentation.classifications,
            orientation_decisions=orientation_decisions,
        )

        classifications: list[ClassificationResult] = []
        other_segments: list[AISegmentClassification] = []
        for segment in segmentation.classifications:
            if segment.document_type == DocumentType.OTHER:
                other_segments.append(segment)
                continue

            extraction = await _extract_segment(
                policy_holder,
                dependents,
                validation_document,
                segment,
            )
            classifications.append(
                build_supported_classification(
                    policy_holder,
                    dependents,
                    segment,
                    extraction,
                    len(document.images),
                )
            )

        if other_segments:
            classifications.append(
                build_merged_other_classification(
                    other_segments,
                    len(document.images),
                )
            )

        if not classifications:
            classifications = [fallback_invalid_classification(document)]

        reviewed_documents.append(
            ReviewedDocument(
                uploaded_document=build_uploaded_document(doc_index, document),
                result=DocumentAnalysisResult(classifications=classifications),
            )
        )

    return FullResult(doc_list=reviewed_documents)
