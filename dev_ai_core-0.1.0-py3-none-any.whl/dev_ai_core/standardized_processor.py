"""Standardized document review pipeline with staged prompting."""

from pydantic_ai import BinaryImage

from dev_ai_core.document_rules.registry import get_document_rule
from dev_ai_core.llm_workflow import (
    AISegmentClassification,
    AISegmentExtractionResult,
    AISegmentationResult,
    build_segmentation_agent,
    build_segmentation_prompt,
    build_validation_agent,
    build_validation_prompt,
)
from dev_ai_core.request import Dependent, PolicyHolder, SubmittedDocument
from dev_ai_core.result import (
    ClassificationResult,
    DocumentAnalysisResult,
    FullResult,
    ReviewedDocument,
)
from dev_ai_core.result_builder import (
    build_merged_other_classification,
    build_supported_classification,
    build_uploaded_document,
    fallback_invalid_classification,
)
from dev_ai_core.types import DocumentType


async def _segment_document(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    submitted_document: SubmittedDocument,
) -> AISegmentationResult:
    agent = build_segmentation_agent()
    user_prompt: list = [
        BinaryImage(data=image, media_type="image/png")
        for image in submitted_document.images
    ]
    user_prompt.append(
        build_segmentation_prompt(
            policy_holder,
            dependents,
            submitted_document.name,
            len(submitted_document.images),
        )
    )
    res = await agent.run(user_prompt=user_prompt, output_type=AISegmentationResult)
    return res.output


async def _extract_segment(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    submitted_document: SubmittedDocument,
    segment: AISegmentClassification,
) -> AISegmentExtractionResult:
    rule = get_document_rule(segment.document_type)
    if rule is None:
        return AISegmentExtractionResult()

    agent = build_validation_agent()
    images = [
        BinaryImage(
            data=submitted_document.images[page_number - 1],
            media_type="image/png",
        )
        for page_number in segment.page_range
        if 1 <= page_number <= len(submitted_document.images)
    ]
    images.append(
        build_validation_prompt(
            policy_holder,
            dependents,
            segment,
            rule,
        )
    )
    res = await agent.run(user_prompt=images, output_type=AISegmentExtractionResult)
    return res.output


async def process(
    policy_holder: PolicyHolder,
    dependents: list[Dependent],
    documents: list[SubmittedDocument],
) -> FullResult:
    reviewed_documents: list[ReviewedDocument] = []

    for doc_index, document in enumerate(documents):
        segmentation = await _segment_document(policy_holder, dependents, document)

        classifications: list[ClassificationResult] = []
        other_segments: list[AISegmentClassification] = []
        for segment in segmentation.classifications:
            if segment.document_type == DocumentType.OTHER:
                other_segments.append(segment)
                continue

            extraction = await _extract_segment(
                policy_holder,
                dependents,
                document,
                segment,
            )
            classifications.append(
                build_supported_classification(
                    policy_holder,
                    dependents,
                    segment,
                    extraction,
                    len(document.images),
                )
            )

        if other_segments:
            classifications.append(
                build_merged_other_classification(
                    other_segments,
                    len(document.images),
                )
            )

        if not classifications:
            classifications = [fallback_invalid_classification(document)]

        reviewed_documents.append(
            ReviewedDocument(
                uploaded_document=build_uploaded_document(doc_index, document),
                result=DocumentAnalysisResult(classifications=classifications),
            )
        )

    return FullResult(doc_list=reviewed_documents)
