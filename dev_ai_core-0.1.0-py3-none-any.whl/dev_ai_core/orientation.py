from __future__ import annotations

import io
import json
import re
import threading
from collections.abc import Sequence
from contextvars import ContextVar, Token
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from PIL import Image

DocumentTopEdge = Literal["TOP", "RIGHT", "BOTTOM", "LEFT"]
VALID_ROTATIONS = {0, 90, 180, 270}
ROTATION_BY_TOP_EDGE: dict[DocumentTopEdge, int] = {
    "TOP": 0,
    "LEFT": 90,
    "BOTTOM": 180,
    "RIGHT": 270,
}


@dataclass(frozen=True)
class OrientationDecision:
    detected_rotation: int | None
    applied_rotation: int
    confidence: float | None
    uncertain: bool
    source: str
    detail: str | None = None
    reported_top_edge: DocumentTopEdge | None = None


@dataclass(frozen=True)
class OrientationArtifactContext:
    root: Path
    case_id: str
    run_number: int
    attempt: int


_artifact_context: ContextVar[OrientationArtifactContext | None] = ContextVar(
    "dev_ai_core_orientation_artifact_context",
    default=None,
)
_artifact_write_lock = threading.Lock()


def rotate_png_bytes(image_bytes: bytes, clockwise_degrees: int) -> bytes:
    if clockwise_degrees not in VALID_ROTATIONS:
        raise ValueError(f"Unsupported clockwise rotation: {clockwise_degrees}")
    if clockwise_degrees == 0:
        return image_bytes

    with Image.open(io.BytesIO(image_bytes)) as image:
        rotated = image.convert("RGB").rotate(-clockwise_degrees, expand=True)
        output = io.BytesIO()
        rotated.save(output, format="PNG")
        return output.getvalue()


def orient_images_from_llm(
    images: Sequence[bytes],
    page_top_edges: Sequence[tuple[int, DocumentTopEdge | None]],
) -> tuple[list[bytes], list[OrientationDecision]]:
    top_edges_by_page: dict[int, set[DocumentTopEdge | None]] = {}
    for page_number, top_edge in page_top_edges:
        if page_number < 1 or page_number > len(images):
            continue
        top_edges_by_page.setdefault(page_number, set()).add(top_edge)

    oriented_images: list[bytes] = []
    decisions: list[OrientationDecision] = []
    for page_number, image_bytes in enumerate(images, start=1):
        candidates = top_edges_by_page.get(page_number, set())
        top_edge = next(iter(candidates)) if len(candidates) == 1 else None
        rotation = ROTATION_BY_TOP_EDGE.get(top_edge) if top_edge is not None else None
        if rotation not in VALID_ROTATIONS:
            oriented_images.append(image_bytes)
            decisions.append(
                OrientationDecision(
                    detected_rotation=rotation,
                    applied_rotation=0,
                    confidence=None,
                    uncertain=True,
                    source="llm",
                    detail=(
                        "No unambiguous document top edge was returned."
                        if len(candidates) <= 1
                        else "Conflicting document top edges were returned."
                    ),
                    reported_top_edge=top_edge,
                )
            )
            continue

        oriented_images.append(rotate_png_bytes(image_bytes, rotation))
        decisions.append(
            OrientationDecision(
                detected_rotation=rotation,
                applied_rotation=rotation,
                confidence=None,
                uncertain=False,
                source="llm",
                reported_top_edge=top_edge,
            )
        )
    return oriented_images, decisions


def set_orientation_artifact_context(
    *,
    root: Path,
    case_id: str,
    run_number: int,
    attempt: int,
) -> Token[OrientationArtifactContext | None]:
    return _artifact_context.set(
        OrientationArtifactContext(
            root=root,
            case_id=case_id,
            run_number=run_number,
            attempt=attempt,
        )
    )


def reset_orientation_artifact_context(
    token: Token[OrientationArtifactContext | None],
) -> None:
    _artifact_context.reset(token)


def save_oriented_pages(
    *,
    approach: Literal["llm"],
    document_name: str,
    document_index: int,
    images: Sequence[bytes],
    decisions: Sequence[OrientationDecision],
) -> None:
    context = _artifact_context.get()
    if context is None:
        return

    approach_dir = context.root / approach
    approach_dir.mkdir(parents=True, exist_ok=True)
    safe_case_id = _safe_filename_part(context.case_id)
    safe_document_name = _safe_filename_part(Path(document_name).stem)

    for page_number, (image_bytes, decision) in enumerate(
        zip(images, decisions, strict=True),
        start=1,
    ):
        filename = (
            f"{safe_case_id}__doc_{document_index + 1:03d}__"
            f"{safe_document_name}__page_{page_number:03d}__"
            f"run_{context.run_number:03d}__attempt_{context.attempt:02d}.png"
        )
        image_path = approach_dir / filename
        image_path.write_bytes(image_bytes)
        manifest_record = {
            "fileName": filename,
            "caseId": context.case_id,
            "documentName": document_name,
            "documentIndex": document_index,
            "pageNumber": page_number,
            "run": context.run_number,
            "attempt": context.attempt,
            "approach": approach,
            "reportedTopEdge": decision.reported_top_edge,
            "detectedRotation": decision.detected_rotation,
            "appliedRotation": decision.applied_rotation,
            "confidence": decision.confidence,
            "orientationUncertain": decision.uncertain,
            "detail": decision.detail,
        }
        _append_manifest_record(approach_dir / "manifest.jsonl", manifest_record)


def _append_manifest_record(path: Path, record: dict[str, object]) -> None:
    serialized = json.dumps(record, ensure_ascii=False, default=str)
    with _artifact_write_lock, path.open("a", encoding="utf-8") as manifest:
        manifest.write(serialized + "\n")


def _safe_filename_part(value: str) -> str:
    sanitized = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._")
    return sanitized or "unnamed"
