from datetime import date
import re
import unicodedata

from rapidfuzz import fuzz

VerificationStatus = str
SUPPORTED_1040_FILING_STATUSES = {
    "mfj",
    "mfs",
    "hoh",
}
FIRST_NAME_FUZZY_THRESHOLD = 95
LAST_NAME_FUZZY_THRESHOLD = 94
FULL_NAME_FUZZY_THRESHOLD = 94
SHORT_NAME_EXACT_LENGTH = 2
NAME_PREFIXES = {
    "mr",
    "mrs",
    "ms",
    "miss",
    "mx",
    "dr",
}
NAME_SUFFIXES = {
    "jr",
    "sr",
    "ii",
    "iii",
    "iv",
    "v",
}


def normalize_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = " ".join(value.strip().split())
    return normalized.casefold() if normalized else None


def strip_accents(value: str) -> str:
    return "".join(
        char
        for char in unicodedata.normalize("NFKD", value)
        if not unicodedata.combining(char)
    )


def normalize_name(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = strip_accents(value).casefold()
    normalized = re.sub(r"[^a-z0-9\s]", " ", normalized)
    parts = [part for part in normalized.split() if part]
    while parts and parts[0] in NAME_PREFIXES:
        parts.pop(0)
    if not parts:
        return None
    return " ".join(parts)


def name_tokens(value: str | None) -> list[str]:
    if value is None:
        return []
    normalized = " ".join(value.strip().split())
    cleaned = re.sub(r"[^A-Za-z0-9\s]", " ", strip_accents(normalized))
    parts = [part for part in cleaned.split() if part]
    while parts and parts[0].casefold() in NAME_PREFIXES:
        parts.pop(0)
    while parts and parts[-1].casefold() in NAME_SUFFIXES:
        parts.pop()
    return parts


def first_name(value: str) -> str:
    parts = name_tokens(value)
    return parts[0] if parts else ""


def display_last_name(value: str) -> str:
    parts = name_tokens(value)
    if not parts:
        return ""
    return parts[-1]


def fuzzy_match(
    extracted: str | None,
    submitted: str | None,
    threshold: int,
) -> VerificationStatus:
    normalized_extracted = normalize_name(extracted)
    normalized_submitted = normalize_name(submitted)
    if normalized_extracted is None or normalized_submitted is None:
        return "FAIL"
    if normalized_extracted == normalized_submitted:
        return "PASS"
    if (
        len(normalized_extracted) <= SHORT_NAME_EXACT_LENGTH
        or len(normalized_submitted) <= SHORT_NAME_EXACT_LENGTH
    ):
        return "FAIL"
    score = fuzz.ratio(normalized_extracted, normalized_submitted)
    return "PASS" if score >= threshold else "FAIL"


def status_from_name(extracted: str | None, submitted: str) -> VerificationStatus:
    return fuzzy_match(extracted, submitted, FULL_NAME_FUZZY_THRESHOLD)


def status_from_dob(extracted: str | None, submitted: date) -> VerificationStatus:
    if extracted is None:
        return "FAIL"
    return "PASS" if extracted == submitted.isoformat() else "FAIL"


def status_from_presence(extracted: str | None) -> VerificationStatus:
    return "PASS" if extracted else "FAIL"


def normalize_filing_status(value: str | None) -> str | None:
    normalized = normalize_text(value)
    return normalized if normalized else None


def status_from_supported_1040_filing_status(
    extracted: str | None,
) -> VerificationStatus:
    normalized = normalize_filing_status(extracted)
    if normalized is None:
        return "FAIL"
    return "PASS" if normalized in SUPPORTED_1040_FILING_STATUSES else "FAIL"


def status_from_signed_yes(extracted: str | None) -> VerificationStatus:
    if extracted is None:
        return "FAIL"
    normalized = normalize_text(extracted)
    return "PASS" if normalized in {"yes", "signed", "true"} else "FAIL"


def status_from_first_name(extracted: str | None, submitted: str) -> VerificationStatus:
    return fuzzy_match(
        extracted,
        first_name(submitted),
        FIRST_NAME_FUZZY_THRESHOLD,
    )


def status_from_last_name(extracted: str | None, submitted: str) -> VerificationStatus:
    return fuzzy_match(
        extracted,
        display_last_name(submitted),
        LAST_NAME_FUZZY_THRESHOLD,
    )
