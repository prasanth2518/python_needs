import os
from datetime import datetime
from pathlib import Path

from dev_ai_core.document_parser import (
    render_jpg_as_bytes,
    render_pdf_as_bytes,
    render_png_as_bytes,
)
from dev_ai_core.input_payload import (
    InputDependent,
    InputDocumentListItem,
    InputPayload,
    InputSubmitter,
)
from dev_ai_core.request import Address, Dependent, PolicyHolder, SubmittedDocument
from dev_ai_core.types import Relationship


def load_input_payload(payload: dict) -> InputPayload:
    return InputPayload.model_validate(payload)


def map_relationship(value: str) -> Relationship:
    normalized = value.strip().casefold().replace("-", "_").replace(" ", "_")
    for relationship in Relationship:
        if normalized in {relationship.value, relationship.name.casefold()}:
            return relationship
    raise ValueError(f"Unsupported relationship value: {value!r}")


def build_policy_holder(submitter: InputSubmitter) -> PolicyHolder:
    return PolicyHolder(
        full_name=submitter.submitter_name,
        date_of_birth=submitter.submitter_dob,
        address=Address.model_validate(submitter.address.model_dump()),
    )


def build_dependents(dependents: list[InputDependent]) -> list[Dependent]:
    return [
        Dependent(
            dependent_id=dependent.dependent_id,
            full_name=dependent.dependent_name,
            date_of_birth=dependent.dob,
            relationship=map_relationship(dependent.relationship),
        )
        for dependent in dependents
    ]


def resolve_local_file_path(local_file_path: str) -> Path:
    resolved = Path(os.path.expandvars(local_file_path)).expanduser()
    if not resolved.exists():
        raise FileNotFoundError(f"Document path does not exist: {resolved}")
    if not resolved.is_file():
        raise FileNotFoundError(f"Document path is not a file: {resolved}")
    return resolved


def infer_mime_type(path: Path) -> str:
    suffix = path.suffix.casefold()
    if suffix == ".pdf":
        return "application/pdf"
    if suffix == ".png":
        return "image/png"
    if suffix in {".jpg", ".jpeg"}:
        return "image/jpeg"
    raise ValueError(f"Unsupported document type for ingestion: {path.suffix}")


def load_document_images(local_file_path: str) -> list[bytes]:
    path = resolve_local_file_path(local_file_path)
    suffix = path.suffix.casefold()
    if suffix == ".pdf":
        return render_pdf_as_bytes(path)
    if suffix == ".png":
        return render_png_as_bytes(path)
    if suffix in {".jpg", ".jpeg"}:
        return render_jpg_as_bytes(path)
    raise ValueError(f"Unsupported document type for ingestion: {path.suffix}")


def build_submitted_document(item: InputDocumentListItem) -> SubmittedDocument:
    uploaded_document = item.uploaded_document
    path = resolve_local_file_path(uploaded_document.local_file_path)
    stat = path.stat()
    uploaded_at = uploaded_document.upload_time or datetime.fromtimestamp(
        stat.st_mtime
    ).astimezone()
    file_name = uploaded_document.file_name or path.name
    mime_type = uploaded_document.mime_type or infer_mime_type(path)
    size_bytes = uploaded_document.size_bytes or stat.st_size
    return SubmittedDocument(
        name=path.stem,
        images=load_document_images(uploaded_document.local_file_path),
        file_name=file_name,
        mime_type=mime_type,
        size_bytes=size_bytes,
        uploaded_at=uploaded_at,
        upload_timezone=str(uploaded_at.tzinfo) if uploaded_at.tzinfo else None,
    )


def build_submitted_documents(
    items: list[InputDocumentListItem],
) -> list[SubmittedDocument]:
    return [build_submitted_document(item) for item in items]


def ingest_payload(
    payload: InputPayload,
) -> tuple[PolicyHolder, list[Dependent], list[SubmittedDocument]]:
    return (
        build_policy_holder(payload.submitter),
        build_dependents(payload.dependents),
        build_submitted_documents(payload.doc_list),
    )
