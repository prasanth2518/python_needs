import argparse
import json
import sys
from pathlib import Path

from dev_ai_core.service import run_payload_sync


def try_load_dotenv() -> None:
    try:
        from dotenv import find_dotenv, load_dotenv
    except ImportError:
        return
    load_dotenv(find_dotenv(), override=False)


def read_json_file(path: Path) -> dict:
    with path.open(encoding="utf-8") as file_handle:
        return json.load(file_handle)


def write_output(result: dict, output_path: Path | None, pretty: bool) -> None:
    serialized = json.dumps(
        result,
        indent=2 if pretty or output_path is not None else None,
        ensure_ascii=False,
    )
    if output_path is None:
        sys.stdout.write(serialized)
        if not serialized.endswith("\n"):
            sys.stdout.write("\n")
        return
    output_path.write_text(serialized + "\n", encoding="utf-8")


def cmd_run(args: argparse.Namespace) -> int:
    try_load_dotenv()
    payload = read_json_file(args.input)
    result = run_payload_sync(payload)
    write_output(result, args.output, args.pretty)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the dev-ai-core pipeline against a JSON payload."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser(
        "run",
        help="Run the pipeline using a JSON payload file.",
    )
    run_parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="Path to the input payload JSON file.",
    )
    run_parser.add_argument(
        "--output",
        type=Path,
        help="Optional path to write the output JSON.",
    )
    run_parser.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty-print JSON output to stdout.",
    )
    run_parser.set_defaults(handler=cmd_run)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        exit_code = args.handler(args)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    raise SystemExit(exit_code)
