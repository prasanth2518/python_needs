from dev_ai_core.document_rules.base import DocumentRule, ValidationField
from dev_ai_core.types import DocumentType


RULE = DocumentRule(
    document_type=DocumentType.BIRTH_CERTIFICATE,
    check_key="parentNames",
    resolution_prompt=(
        "Choose the best dependent only from eligible child relationships. Use the child's first given name "
        "and child date of birth as the primary signals. "
        "Return matched_dependent_id as null if no single eligible dependent is clearly supported."
    ),
    check_prompt=(
        "Validate the birth or hospital record against the declared dependent child. "
        "Extract the child's first given name, the child date of birth, all visible parent first given names on record, "
        "and whether the document is officially signed or certified by a state authority or a hospital officiant/representative. "
        "Do not select only one relevant parent. If two parent names are shown anywhere on the record, "
        "extract both before comparison. For name fields, extract only the first given name and not the full name. "
        "If any name field is blurry, faint, partially cut off, obstructed, or not clearly legible, return null for that name instead of guessing or using the case context."
    ),
    validation_fields=(
        ValidationField(
            key="childName",
            prompt="Extract only the child's first given name exactly as shown on the record. Do not return middle names or last names. If the first given name is not clearly visible, is blurry, faint, partially cut off, obstructed, or cannot be read with confidence, return null. Do not guess or infer the name from the case context.",
            comparison="dependent_first_name",
        ),
        ValidationField(
            key="childDob",
            prompt="Extract the child date of birth exactly as shown on the record, using YYYY-MM-DD format when the date is clear. If not present, return null.",
            comparison="dependent_dob",
        ),
        ValidationField(
            key="parentNames",
            prompt="Review the entire document and identify every visible parent-name field, including mother, father, parent 1, parent 2, or equivalent labels. Return a JSON array of the first given name for each visible parent, in document order. Do not return middle names or last names. The names may match the submitter, the adult spouse or domestic partner in the case context, or both. Do not omit a second parent just because one parent already matches the payload. Do not choose only the most relevant parent. If two parent names are visible, return both first names. If only one parent name is clearly visible, return an array with one item. If a parent name is blurry, faint, partially cut off, obstructed, or not clearly legible, do not guess it. If no parent names are clearly visible, return null.",
            comparison="expected_parent_first_name",
        ),
        
        ValidationField(
            key="officialSigned",
            prompt="Return officialSigned as a JSON object with exactly these keys: extracted and reasoning. Set extracted to 'yes' if the document shows a qualifying official signature or certification from either a state authority, registrar, clerk, or equivalent government official, or from a hospital officiant, hospital representative, or hospital staff member on a hospital record. Do not count a parent, guardian, applicant, submitter, mother, or father signature as an official signature. Set extracted to 'no' if the visible document does not show a qualifying official or hospital signature/certification. Set extracted to null only if the signature/certification area is not visible or cannot be determined. Set reasoning to a short factual explanation of the visible evidence.",
            comparison="signed_yes",
            required=True,
        ),
    ),
)
