from dev_ai_core.document_rules.base import DocumentRule, ValidationField
from dev_ai_core.extraction_models import ParentNamesValue, TextValue, YesNoValue
from dev_ai_core.types import DocumentType


RULE = DocumentRule(
    document_type=DocumentType.BIRTH_CERTIFICATE,
    check_key="parentNames",
    resolution_prompt=(
        "First extract the child's first given name from the birth certificate. "
        "Then choose exactly one dependent from the eligible child relationships whose first given name "
        "matches the extracted child first name. Use only the child's first given name for dependent selection. Return matched_dependent_id as null if no single eligible dependent is "
        "clearly supported by name."
    ),
    check_prompt=(
        "First, orient all pages of the record by rotating so that the text is right-side up and readable."
        "Extract the child's first given name, the child date of birth, all visible parents first names, "
        "and whether the document is officially signed or certified by a state authority or a hospital officiant/representative. "
        "For parent names extract the fields identifying the father and mother on the birth record or equavalent parent identifying fields like 'Child Of' or 'parents'. " 
        "For name fields, extract only the first given name and not the full name. "
        "If any name field is blurry, faint, partially cut off, obstructed, or not clearly legible, return null for that name instead of guessing or using the case context."
    ),
    validation_fields=(
        ValidationField(
            key="childName",
            output_annotation=TextValue,
            prompt="Extract only the child's first given name exactly as shown in the child/name field on the birth record. Do not return middle names or last names. Preserve the spelling exactly as shown, including uncommon or unusual names. Do not normalize, autocorrect, or replace an uncommon name with a more common name. If the first given name is not clearly visible, is blurry, faint, partially cut off, obstructed, or cannot be read with confidence, return null.",
            comparison="dependent_first_name",
        ),
        ValidationField(
            key="childDob",
            output_annotation=TextValue,
            prompt=(
                "Extract only the child's date of birth from the field or sentence explicitly "
                "labeled 'Date of Birth', 'DOB', 'Born', 'Born On', 'Was Born', or an equivalent "
                "birth-event label. The month and day may appear beside 'Born On' while the year "
                "appears in a separate adjacent 'Year' field; combine those birth-date components "
                "and return YYYY-MM-DD. Do not use a date labeled 'Date Filed', 'Record Was Filed', "
                "'Date Issued', registration date, certification date, amendment date, or any other "
                "administrative date. Before returning the value, confirm that it belongs to the "
                "child's birth event. If the complete birth date cannot be confidently identified, "
                "return null."
            ),
            comparison="dependent_dob",
        ),
        ValidationField(
            key="parentNames",
            output_annotation=ParentNamesValue,
            prompt=(
                "Extract only the first given names from fields explicitly identifying the child's parents, "
                "such as 'Mother', 'Father', 'Parent', 'Parent 1', 'Parent 2', 'Child Of', or equivalent "
                "parent-identifying labels. A valid parent name must appear in the same row, box, or section "
                "as the parent label. Return a JSON array in document order with at most two names. "
                "Do not return more than two parent names. "
                "Do not return middle names or last names. "
                "Do not extract county, city, state, place of birth, hospital, registrar, clerk, certifier, "
                "issuing authority, seal, signature, certifier's name or attendant's name as a parent name, even if it appears "
                "near the birth record. "
                "Do not extract Mother's last name prior to marriage, only extract Mother's official first official name. Similarly, only extract father's first offical name."
                "If both parent fields are clearly visible, return both names. "
                "If only one parent field is clearly visible, return one item. "
                "If more than two possible parent names appear, return only the two names tied most directly "
                "to explicit parent labels. "
                "If no parent-identifying field is clearly visible, return null."
            ),
            
            comparison="expected_parent_first_name",
        ),
        
        ValidationField(
            key="officialSigned",
            output_annotation=YesNoValue,
            evidence_mode="visual",
            prompt="Set extracted to 'yes' if the document shows a qualifying official signature or certification from either a state authority, registrar, clerk, or equivalent government official, or from a hospital officiant, hospital representative, or hospital staff member on a hospital record. Do not count a parent, guardian, applicant, submitter, mother, or father signature as an official signature. Set extracted to 'no' if the visible document does not show a qualifying official or hospital signature/certification. Set extracted to null only if the signature/certification area is not visible or cannot be determined.",
            comparison="signed_yes",
            required=True,
        ),
    ),
)
