from dev_ai_core.document_rules.base import DocumentRule, ValidationField
from dev_ai_core.types import DocumentType


RULE = DocumentRule(
    document_type=DocumentType.MARRIAGE_CERTIFICATE,
    check_key="marriageCertCheck",
    resolution_prompt=(
        "Choose the best dependent only from eligible spouse or domestic-partner relationships. "
        "Use the spouse or domestic partner first given name shown on the certificate as the primary signal. "
        "Return matched_dependent_id as null if no single eligible dependent is clearly supported."
    ),
    check_prompt=(
        "Validate the marriage certificate against the submitter and the matched spouse or domestic partner. "
        "Your goal is to determine that this is valid marriage certificate that certifies the completion of marriage ceremony between the submitter and the matched spouse. "
        "For submitterName and dependentName, extract only the first given name shown on the certificate. "
        "Do not use middle names, last names, initials, or nicknames. "
        "For marriageDatePresent, return a JSON object with exactly these keys: extracted and reasoning. "
        "For marriageDatePresent, if it is a marriage license, use only the ceremony-completion section because that shows whether the marriage occurred. Do not use the license-issuance section. "
        "Use the date from the ceremony/officiant section, not the license application, license issue, registrar, filing, recording, or certificate receipt section. "
        "For officiantSigned, return a JSON object with exactly these keys: extracted and reasoning. "
        "Determine whether a qualifying signature is present. For a marriage license, it must be in the ceremony-completion or returned-and-filed section. For an issued marriage certificate or certified vital record, it may be an official registrar, recorder, clerk, or county certification signature confirming that the marriage occurred or was recorded. "
        "Return only the requested fields. If a field is not visible, return null."
    ),
    validation_fields=(
        ValidationField(
            key="submitterName",
            prompt="Extract only the submitter's first given name exactly as shown on the marriage certificate. If the first name is not present, return null.",
            comparison="submitter_first_name",
        ),
        ValidationField(
            key="dependentName",
            prompt="Extract only the matched spouse or domestic partner's first given name exactly as shown on the marriage certificate. If the first name is not present, return null.",
            comparison="dependent_first_name",
        ),
        ValidationField(
            key="marriageDatePresent",
            prompt="Return marriageDatePresent as a JSON object with exactly these keys: extracted and reasoning. " \
            "Set extracted to the marriage ceremony date in YYYY-MM-DD format usually mentioned with the keywords 'On the Day of'. If the ceremony completion date is mentioned in words convert it into YYYY-MM-DD format. " \
            "This must be the date the parties were actually married, joined in marriage, or had vows solemnized. Do not guess, infer, reconstruct, or estimate a date from document layout, nearby stamps, surrounding labels, or partial digits. " \
            "If the document is only a marriage license, marriage application, or authorization to marry, make sure the completed ceremony date in the marriage section is filled in, if not, set extracted to null even if other dates are present. " \
            "Do not extract a license issue date, application date, clerk signature date, filed date, recorded date, certificate issue date, return date, or any other official signature date. " \
            "If the marriage section is blank or incomplete, including where text such as 'on the day of' appears but the date fields are empty or unreadable, set extracted to null. If the full date is not fully inside the image or is cut off, set extracted to null. Only return a date when the completed ceremony date itself is fully visible. " \
            "If ceremony date is handwritten, try your best to extract it, don't set it to null, unless it completely unlegible. But be sure it is the date of the marriage ceremony. " \
            "In reasoning, explicitly state your reasoning and if any of those conditions are not met, explain that and keep extracted as null.",
            comparison="presence",
        ),
        ValidationField(
            key="officiantSigned",
            prompt="Return officiantSigned as a JSON object with exactly these keys: extracted and reasoning. " \
            "Set extracted to 'yes' only if a qualifying signature is clearly visible, fully shown, and not cut off. "
            "Set extracted to 'no' if that section is clearly visible and unsigned. " \
            "Set extracted to null if the signature area is not visible, is cut off, or cannot be determined. " \
            "If the document is already a certificate of marriage or certified vital record, count an official registrar, recorder, clerk, or county certification signature as 'yes' when the document states that the marriage occurred or was recorded. "
            "If the document is a marriage license, do not count officiant signature in the license issuance section; count only a signature in the ceremony-completion or returned and filed section. "
            "Do not treat witness, applicant, bride, or groom signatures as the officiant signature. In reasoning, explicitly state whether the officiant signature area is clearly visible, fully shown, and not cut off, and describe the visible evidence for the decision.",
            comparison="signed_yes",
        ),
    ),
    examples=(
        """
        Example:
        {
          "matched_dependent_id": "DEP-001",
          "extracted_fields": {
            "submitterName": "Rakan",
            "dependentName": "Jenna",
            "marriageDatePresent": {
              "extracted": null,
              "reasoning": "The document is a marriage license/authorization and the ceremony completion section at the bottom is blank. The line for the marriage date is not filled in, so no marriage ceremony date can be extracted. The visible date near the clerk signature (September 20, 2020) is a signature/authorization date, not the ceremony date, so it should not used."
            },
            "officiantSigned": {
              "extracted": "no",
              "reasoning": "The ceremony-completion and returned-and-filed signature areas are fully visible and unsigned. The only visible signature is in the license-issuance section, which does not qualify."
            }
          }
        }
        """
    ),
)
