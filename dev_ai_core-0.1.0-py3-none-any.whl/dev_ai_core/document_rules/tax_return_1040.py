from dev_ai_core.document_rules.base import DocumentRule, ValidationField
from dev_ai_core.types import DocumentType


RULE = DocumentRule(
    document_type=DocumentType.TAX_RETURN_1040,
    check_key="filingStatus",
    resolution_prompt=(
        "Choose the best dependent only when one eligible spouse or domestic partner is clearly "
        "identified by the tax return. Use only the filer-name area at the top of the 1040, including the "
        "primary filer name field and the spouse-name field when present. Never use the dependents section "
        "to choose the matched dependent. Return matched_dependent_id as null if no single eligible dependent "
        "is clearly supported."
    ),
    check_prompt=(
        "Extract the tax filing status into a standardized value. Return only one of: "
        "'MFJ' for Married Filing Jointly, 'MFS' for Married Filing Separately, or 'HOH' for Head of Household. "
        "If the filing status is not clearly one of those values, return null. Also extract the tax year shown "
        "on the 1040 form. Extract names only from the filer-name area at the top of the 1040. "
        "Do not use the dependents section, qualifying child sections, signature blocks, preparer blocks, "
        "attachments, or any other part of the document for name extraction. "
        "For primaryFilerFirstName and primaryFilerLastName, extract the primary filer name from the main taxpayer name field. "
        "For spouseFieldFirstName and spouseFieldLastName, extract the name from the spouse full-name field or equivalent spouse-name field, when present. "
        "If that spouse-name field is blank, not present, or not clearly legible, return null for the spouseField values. "
        "Do not infer, reconstruct, or make up any name details from the case context or other passed inputs. "
        "If the first name or last name is missing, unclear, or not clearly extractable from the document, return null for that field. "
        "If the filing status or tax year is not visible, return null."
    ),
    validation_fields=(
        ValidationField(
            key="filingStatus",
            prompt=(
                "Return the filing status as a standardized value using exactly one of these strings: "
                "'MFJ', 'MFS', or 'HOH'. Return 'MFJ' only for Married Filing Jointly. Return 'MFS' only for "
                "Married Filing Separately. Return 'HOH' only for Head of Household. If the filing status is "
                "not clearly one of those three, return null."
            ),
            comparison="presence",
        ),
        ValidationField(
            key="taxYear",
            prompt="Extract the tax year shown on the Form 1040 exactly as it appears on the document, for example 2024. If the tax year is not clearly visible, return null.",
            comparison="presence",
        ),
        ValidationField(
            key="primaryFilerFirstName",
            prompt=(
                "Extract only the first name from the primary filer name field at the top of the 1040. "
                "If the primary filer first name is not clearly visible, return null."
            ),
            comparison="presence",
        ),
        ValidationField(
            key="primaryFilerLastName",
            prompt=(
                "Extract only the last name from the primary filer name field at the top of the 1040. "
                "If the primary filer last name is not clearly visible, return null."
            ),
            comparison="presence",
        ),
        ValidationField(
            key="spouseFieldFirstName",
            prompt=(
                "Extract only the first name from the spouse full-name field or equivalent spouse-name field at the top of the 1040. "
                "If that field is blank, not present, or not clearly visible, return null."
            ),
            comparison="presence",
        ),
        ValidationField(
            key="spouseFieldLastName",
            prompt=(
                "Extract only the last name from the spouse full-name field or equivalent spouse-name field at the top of the 1040. "
                "If that field is blank, not present, or not clearly visible, return null."
            ),
            comparison="presence",
        ),
    ),
)
