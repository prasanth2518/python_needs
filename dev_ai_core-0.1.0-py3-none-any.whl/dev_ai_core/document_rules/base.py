from dataclasses import dataclass
from typing import Literal

from dev_ai_core.types import DocumentType

ValidationComparison = Literal[
    "presence",
    "dependent_name",
    "dependent_first_name",
    "dependent_last_name",
    "dependent_dob",
    "submitter_name",
    "submitter_first_name",
    "submitter_last_name",
    "submitter_dob",
    "expected_parent_name",
    "expected_parent_first_name",
    "expected_parent_role",
    "signed_yes",
    "official_signed_type",
]


@dataclass(frozen=True)
class ValidationField:
    key: str
    prompt: str
    comparison: ValidationComparison
    required: bool = True
    match_via_llm: bool = False


@dataclass(frozen=True)
class DocumentRule:
    document_type: DocumentType
    check_key: str
    resolution_prompt: str
    check_prompt: str
    validation_fields: tuple[ValidationField, ...]
    examples: str | None = None

    def render_prompt(self) -> str:
        lines = [
            f"Document-specific check key: {self.check_key}",
            f"Dependent resolution rule: {self.resolution_prompt}",
            f"Instruction: {self.check_prompt}",
            "Return extracted_fields with exactly these keys:",
        ]
        for field in self.validation_fields:
            lines.append(f"- {field.key}: {field.prompt}")
        llm_match_fields = [field.key for field in self.validation_fields if field.match_via_llm]
        if llm_match_fields:
            lines.append(
                "Return match_statuses for these keys using only PASS or FAIL:"
            )
            for field_key in llm_match_fields:
                lines.append(f"- {field_key}")
        if self.examples:
            lines.append("")
            lines.append("Examples:")
            lines.append(self.examples)
        return "\n".join(lines)
