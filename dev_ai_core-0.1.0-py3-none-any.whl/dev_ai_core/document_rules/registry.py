from dev_ai_core.document_rules.base import DocumentRule
from dev_ai_core.document_rules.birth_certificate import RULE as BIRTH_CERTIFICATE_RULE
from dev_ai_core.document_rules.marriage_certificate import RULE as MARRIAGE_CERTIFICATE_RULE
from dev_ai_core.document_rules.tax_return_1040 import RULE as TAX_RETURN_1040_RULE
from dev_ai_core.types import DocumentType

DOCUMENT_RULES: dict[DocumentType, DocumentRule] = {
    BIRTH_CERTIFICATE_RULE.document_type: BIRTH_CERTIFICATE_RULE,
    MARRIAGE_CERTIFICATE_RULE.document_type: MARRIAGE_CERTIFICATE_RULE,
    DocumentType.STATE_ISSUED_MARRIAGE_CERTIFICATE: MARRIAGE_CERTIFICATE_RULE,
    TAX_RETURN_1040_RULE.document_type: TAX_RETURN_1040_RULE,
}


def get_document_rule(document_type: DocumentType) -> DocumentRule | None:
    return DOCUMENT_RULES.get(document_type)


def render_supported_document_types() -> str:
    lines = []
    for document_type, rule in DOCUMENT_RULES.items():
        lines.append(
            f"- {document_type.value}: {document_type.description}. "
            f"Document-specific check key: {rule.check_key}."
        )
    lines.append(
        f"- {DocumentType.OTHER.value}: {DocumentType.OTHER.description}"
    )
    return "\n".join(lines)
