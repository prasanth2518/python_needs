from cev_ai_core.doc_types.base import BaseDocType


class JobTrainingDocType(BaseDocType):
    CERTIFICATE_OF_COMPLETION = (
        "certificate_of_completion",
        "A certificate awarded upon completing a training program",
    )
    CERTIFICATE = (
        "certificate",
        "A general certificate from a job training or skills program",
    )
    AGENCY_STATEMENT = (
        "agency_statement",
        "A statement from the training agency confirming participation",
    )
    OJT_VERIFICATION = (
        "ojt_verification",
        "An On-the-Job Training (OJT) verification form issued by a workforce development agency, often resembling employment verification but tied to a training program",
    )
    ATTESTATION_LETTER = (
        "attestation_letter",
        "A letter attesting to the trainee's attendance or progress",
    )
    ACTIVITY_LOG = ("activity_log", "A log of training activities and hours completed")
    JOB_SEARCH_REGISTRATION = (
        "job_search_registration",
        "A registration record for a job search assistance program",
    )
    WORKSHOP_ATTENDANCE = (
        "workshop_attendance",
        "A record of attendance at job training workshops",
    )
    JOB_APPLICATION_LOG = (
        "job_application_log",
        "A log of job applications submitted during training",
    )
    SUPERVISOR_STATEMENT = (
        "supervisor_statement",
        "A statement from a supervisor confirming training participation",
    )
