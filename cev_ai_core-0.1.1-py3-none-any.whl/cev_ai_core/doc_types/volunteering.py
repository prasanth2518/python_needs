from cev_ai_core.doc_types.base import BaseDocType


class VolunteeringDocType(BaseDocType):
    VOLUNTEERING_FORM = (
        "volunteering_form",
        "A signed form from an organization confirming volunteer participation",
    )
    ORGANIZATION_STATEMENT = (
        "organization_statement",
        "A letter or statement from the organization verifying community service",
    )
    PARTICIPATION_CALENDAR = (
        "participation_calendar",
        "A calendar or schedule showing dates of volunteer attendance",
    )
    TIMESHEET = ("timesheet", "A log of hours worked during volunteer service")
    COURT_ORDERED_TIMESHEET = (
        "court_ordered_timesheet",
        "A timesheet specifically for court-mandated community service hours",
    )
    PROBATION_COMPLETION = (
        "probation_completion",
        "A document confirming completion of probation-related community service",
    )
    PAROLE_COMPLETION = (
        "parole_completion",
        "A document confirming completion of parole-related community service",
    )
