from cev_ai_core.doc_types.base import BaseDocType


class SchoolDocType(BaseDocType):
    COURSE_ENROLLMENT = (
        "course_enrollment",
        "A document confirming enrollment in a course or program",
    )
    TRANSCRIPT = ("transcript", "An academic transcript showing courses and grades")
    REPORT_CARD = (
        "report_card",
        "A report card showing academic performance for a grading period",
    )
    CLASS_SCHEDULE = (
        "class_schedule",
        "A schedule listing enrolled classes and meeting times",
    )
