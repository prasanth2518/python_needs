from cev_ai_core.doc_types.base import BaseDocType


class WorkDocType(BaseDocType):
    PAYSTUB = ("paystub", "A pay stub showing wages earned during a pay period")
    EMPLOYER_LETTER = (
        "employer_letter",
        "A letter from the employer verifying employment details",
    )
    TIMESHEET = ("timesheet", "A record of hours worked during a pay period")
