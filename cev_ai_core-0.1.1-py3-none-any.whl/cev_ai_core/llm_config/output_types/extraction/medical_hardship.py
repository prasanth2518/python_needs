from datetime import date
from typing import Literal

from pydantic import Field

from cev_ai_core.doc_types import MedicalHardshipDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import Subject

HardshipType = Literal["medical_frailty", "pregnancy"]


class Provider(CamelCaseModel):
    name: str | None = Field(
        default=None,
        description="Name of the healthcare provider or facility",
    )
    address: str | None = Field(
        default=None,
        description="Address of the healthcare provider or facility",
    )
    npi: str | None = Field(
        default=None,
        description="National Provider Identifier (NPI) of the healthcare provider",
    )


class SupportingCode(CamelCaseModel):
    code: str = Field(description="The diagnostic or procedure code (e.g. ICD-10 code)")
    code_type: str = Field(description="The coding system used (e.g. ICD10, CPT)")


class MedicalExemption(CamelCaseModel):
    hardship_type: HardshipType | None = Field(
        default=None,
        description="The type of medical hardship claimed in the document, default to null if cannot be determined",
    )
    hardship_subtype: (
        Literal[
            "blind",
            "disabled",
            "impaired_activities_of_daily_living_adl",
            "disabling_mental_disorder",
            "serious_or_complex_medical_condition",
            "substance_abuse_disorder",
            "pregnancy",
        ]
        | None
    ) = Field(
        default=None,
        description="A sub hardship subtype claimed in the document, default to null if cannot be determined",
    )
    effective_date: date | None = Field(
        default=None,
        description="Extract the effective date of this document if present",
    )
    provider: Provider
    supporting_codes: list[SupportingCode] = Field(
        default_factory=list,
        description="Diagnostic or procedure codes supporting the hardship claim",
    )


class MedicalHardshipExtractionOutputType(BaseExtractionSchema):
    """Documents proving a medical condition or hardship preventing work participation"""

    document_type: MedicalHardshipDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    medical_exemption: MedicalExemption
