from datetime import date
from typing import Literal

from pydantic import Field

from cev_ai_core.doc_types import SchoolDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class Bucket(CamelCaseModel):
    """A single time period (semester/year) with associated enrollment and credit data."""

    start_date: date | None = Field(
        default=None,
        description=(
            "The start date of the current time bucket, "
            "do not infer any dates if not specified in the document"
        ),
    )
    end_date: date | None = Field(
        default=None,
        description=(
            "The end date of the current time bucket, "
            "do not infer any dates if not specified in the document"
        ),
    )
    credits: float | None = Field(
        default=None, description="The credit for the current time bucket"
    )
    enrollment_status: (
        Literal["full-time", "half-time", "quarter-time", "unknown"] | None
    ) = Field(
        default=None,
        description=(
            "The student's enrollment status for this time bucket. "
            "Use 'unknown' only if the document mentions enrollment but does not specify a level."
        ),
    )


class Allocations(CamelCaseModel):
    """Time-bucketed breakdown of academic enrollment extracted from the document."""

    grain: Literal["year", "semester", "unknown"] | None = Field(
        default=None,
        description=(
            "The grain of each bucket, only one grain level can exist. "
            "Use the one that makes the most sense"
        ),
    )
    buckets: list[Bucket] = Field(
        default_factory=list,
        description="The logical time bucket that we can break the document down into",
    )


class SchoolExtractionOutputType(BaseExtractionSchema):
    """Documents proving university or college enrollment"""

    document_type: SchoolDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject = Field(
        description="The student named on the document",
    )
    document_date: DocumentDates = Field(
        description="Overall date range covered by this academic document",
    )
    document_source: DocumentSource = Field(
        description="The educational institution that issued this document",
    )
    allocations: Allocations = Field(
        description="Time-bucketed enrollment and credit data extracted from the document",
    )
