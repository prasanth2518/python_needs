from typing import Literal

from pydantic import Field, computed_field

from cev_ai_core.doc_types import WorkDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class Income(CamelCaseModel):
    amount: float | None = Field(
        default=None,
        description=(
            "The total pay amount for the current pay period based on the dates specified in the document and hours. Calculate it if necessary"
        ),
    )

    # NOTE: temporary solution to hard code the currency, might need to make it dynamic in the future
    @computed_field
    @property
    def currency(self) -> Literal["USD"]:
        return "USD"


class ActivityMetrics(CamelCaseModel):
    unit: Literal["hours", "minutes"] | None = Field(
        default=None,
        description="The unit that the time of work is calculated in",
    )
    quantity: float | None = Field(
        default=None,
        description="Aggregated quantity of the unit of training time shown on the document",
    )
    income: Income


class WorkExtractionOutputType(BaseExtractionSchema):
    """Documents proving paid employment by an employer, including wages, salary, or hourly compensation"""

    document_type: WorkDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    document_date: DocumentDates
    document_source: DocumentSource
    activity_metrics: ActivityMetrics
