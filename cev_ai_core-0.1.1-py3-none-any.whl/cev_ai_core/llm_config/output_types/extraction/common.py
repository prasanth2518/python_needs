from datetime import date

from pydantic import Field

from cev_ai_core.camel_case_base import CamelCaseModel


class Subject(CamelCaseModel):
    extracted_name: str | None = Field(
        default=None,
        description=(
            "Full name of the document subject as it appears on the document. "
            "The format should be `<first_name> <last_name>`"
        ),
    )
    extracted_dob: date | None = Field(
        default=None,
        description="Date of birth of document subject in ISO format (YYYY-MM-DD)",
    )


class DocumentSource(CamelCaseModel):
    name: str | None = Field(
        default=None,
        description="Name of the source organization (e.g. employer, school, training agency, hospital, etc)",
    )


class DocumentDates(CamelCaseModel):
    start_date: date | None = Field(
        default=None,
        description="Start date of the activity period covered by the document (YYYY-MM-DD)",
    )
    end_date: date | None = Field(
        default=None,
        description="End date of the activity period covered by the document (YYYY-MM-DD)",
    )
