from enum import Enum


class Activity(str, Enum):
    """Enumeration of supported community engagement activities."""

    WORK = "work"
    SCHOOL = "school"
    JOB_TRAINING = "job_training"
    VOLUNTEERING = "volunteering"
    MEDICAL_HARDSHIP = "medical_hardship"

    # Future compatibility fix for Enum -
    # without this, it won't work in python 3.11 and above
    def __str__(self):
        return self.value
