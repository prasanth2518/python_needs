from rapidfuzz import fuzz

from cev_ai_core.activity import Activity
from cev_ai_core.llm_config.output_types.extraction.base import BaseExtractionSchema
from cev_ai_core.llm_config.output_types.extraction.common import Subject
from cev_ai_core.requests import SubmitterData
from cev_ai_core.results import Check, Validation

NAME_MATCH_THRESHOLD = 85


def _build_full_name(
    first: str | None, middle: str | None, last: str | None
) -> str | None:
    parts = [p for p in (first, middle, last) if p]
    return " ".join(parts) if parts else None


def validate_document_validity(invalid_reason: str | None) -> Check:
    return Check(
        check_id="document_validity_check",
        status="FAIL",
        code=2000,
        details={"invalid_reason": invalid_reason},
    )


def validate_activity_type_match(
    declared_activity: Activity, classified_activity: Activity
) -> Check:
    return Check(
        check_id="doc_activity_match",
        status="PASS" if declared_activity == classified_activity else "FAIL",
        code=1000 if declared_activity == classified_activity else 2000,
        details={
            "declared_activity_type": str(declared_activity),
            "classified_activity_type": str(classified_activity),
        },
    )


def validate_submitter_name(submitter_data: SubmitterData, subject: Subject) -> Check:
    submitter_name = _build_full_name(
        submitter_data.first_name, submitter_data.middle_name, submitter_data.last_name
    )
    extracted_name = subject.extracted_name
    if submitter_name and extracted_name:
        name_score = fuzz.token_sort_ratio(
            submitter_name.lower(), extracted_name.lower()
        )
    else:
        name_score = 0.0
    name_match = name_score >= NAME_MATCH_THRESHOLD
    status = "PASS" if name_match else "FAIL"

    return Check(
        check_id="submitter_name_match",
        status=status,
        code=1000 if status == "PASS" else 2000,
        details={
            "submitter_name": submitter_name,
            "extracted_name": extracted_name,
        },
        name_score=name_score,
    )


def validate_submitter_dob(submitter_data: SubmitterData, subject: Subject) -> Check:
    dob_match = submitter_data.date_of_birth == subject.extracted_dob
    status = "PASS" if dob_match else "FAIL"

    return Check(
        check_id="submitter_dob_match",
        status=status,
        code=1000 if status == "PASS" else 2000,
        details={
            "submitter_dob": str(submitter_data.date_of_birth)
            if submitter_data.date_of_birth
            else None,
            "extracted_dob": str(subject.extracted_dob)
            if subject.extracted_dob
            else None,
        },
    )


def build_validation(
    submitter_data: SubmitterData,
    declared_activity: Activity,
    classified_activity: Activity,
    extraction: BaseExtractionSchema,
) -> Validation:
    checks: list[Check] = []
    errors: list[Check] = []

    activity_check = validate_activity_type_match(
        declared_activity, classified_activity
    )
    checks.append(activity_check)
    if activity_check.status == "FAIL":
        errors.append(activity_check)

    name_check = validate_submitter_name(submitter_data, extraction.subject)
    checks.append(name_check)
    if name_check.status == "FAIL":
        errors.append(name_check)

    dob_check = validate_submitter_dob(submitter_data, extraction.subject)
    checks.append(dob_check)
    if dob_check.status == "FAIL":
        errors.append(dob_check)

    return Validation(errors=errors, checks=checks)
