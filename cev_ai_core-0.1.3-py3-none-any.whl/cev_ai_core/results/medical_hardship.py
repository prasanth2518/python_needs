from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import MedicalHardshipDocType
from cev_ai_core.llm_config.output_types import MedicalHardshipExtractionOutputType
from cev_ai_core.llm_config.output_types.extraction.medical_hardship import HardshipType
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class MedicalHardshipClassificationResult(
    BaseClassificationResult[MedicalHardshipDocType]
):
    hardship_type: HardshipType | None


class MedicalHardshipFinalResult(
    BaseFinalResult[
        MedicalHardshipExtractionOutputType, MedicalHardshipClassificationResult
    ]
):
    @computed_field
    @property
    def classification(self) -> MedicalHardshipClassificationResult:
        return MedicalHardshipClassificationResult(
            activity_type=Activity.MEDICAL_HARDSHIP,
            document_type=self.extraction.document_type,
            hardship_type=self.extraction.medical_exemption.hardship_type,
        )
