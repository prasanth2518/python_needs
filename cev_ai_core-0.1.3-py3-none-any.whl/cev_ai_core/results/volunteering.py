from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import VolunteeringDocType
from cev_ai_core.llm_config.output_types import VolunteeringExtractionOutputType
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class VolunteeringClassificationResult(BaseClassificationResult[VolunteeringDocType]):
    pass


class VolunteeringFinalResult(
    BaseFinalResult[VolunteeringExtractionOutputType, VolunteeringClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> VolunteeringClassificationResult:
        return VolunteeringClassificationResult(
            activity_type=Activity.VOLUNTEERING,
            document_type=self.extraction.document_type,
        )
