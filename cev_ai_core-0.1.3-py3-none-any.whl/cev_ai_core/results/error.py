from pydantic import Field, computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class ErrorFinalResult(BaseFinalResult):
    extraction: None = None
    activity_type: Activity | None = Field(default=None, exclude=True)

    @computed_field
    @property
    def classification(self) -> BaseClassificationResult:
        return BaseClassificationResult(
            activity_type=self.activity_type,
            document_type=None,
        )
