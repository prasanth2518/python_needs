from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import WorkDocType
from cev_ai_core.llm_config.output_types import WorkExtractionOutputType
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class WorkClassificationResult(BaseClassificationResult[WorkDocType]):
    pass


class WorkFinalResult(
    BaseFinalResult[WorkExtractionOutputType, WorkClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> WorkClassificationResult:
        return WorkClassificationResult(
            activity_type=Activity.WORK,
            document_type=self.extraction.document_type,
        )
