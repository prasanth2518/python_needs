from typing import Generic, Literal, TypeVar

from pydantic import Field, computed_field, model_serializer
from pydantic.alias_generators import to_camel

from cev_ai_core.activity import Activity
from cev_ai_core.camel_case_base import CamelCaseModel
from cev_ai_core.doc_types.base import BaseDocType
from cev_ai_core.llm_config.output_types.extraction.base import BaseExtractionSchema


def _camelize_dict(d: dict) -> dict:
    return {to_camel(k): v for k, v in d.items()}


class Check(CamelCaseModel):
    check_id: str
    status: Literal["PASS", "FAIL"]
    code: int
    details: dict
    name_score: float | None = Field(default=None, exclude=True)

    @model_serializer(mode="wrap")
    def _serialize(self, handler):
        data = handler(self)
        if "details" in data:
            data["details"] = _camelize_dict(data["details"])
        return data


class Validation(CamelCaseModel):
    errors: list[Check]
    checks: list[Check]

    @model_serializer(mode="wrap")
    def _serialize(self, handler):
        data = handler(self)
        if "errors" in data:
            data["errors"] = sorted(data["errors"], key=lambda c: c["checkId"])
        if "checks" in data:
            data["checks"] = sorted(data["checks"], key=lambda c: c["checkId"])
        return data


T1 = TypeVar("T1", bound=BaseDocType)


class BaseClassificationResult(CamelCaseModel, Generic[T1]):
    activity_type: Activity | None
    document_type: T1 | None


T2 = TypeVar("T2", bound=BaseExtractionSchema)
T3 = TypeVar("T3", bound=BaseClassificationResult)


class BaseFinalResult(CamelCaseModel, Generic[T2, T3]):
    validation: Validation
    extraction: T2

    @computed_field
    @property
    def classification(self) -> T3:
        raise NotImplementedError
