from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import JobTrainingDocType
from cev_ai_core.llm_config.output_types import JobTrainingExtractionOutputType
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class JobTrainingClassificationResult(BaseClassificationResult[JobTrainingDocType]):
    pass


class JobTrainingFinalResult(
    BaseFinalResult[JobTrainingExtractionOutputType, JobTrainingClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> JobTrainingClassificationResult:
        return JobTrainingClassificationResult(
            activity_type=Activity.JOB_TRAINING,
            document_type=self.extraction.document_type,
        )
