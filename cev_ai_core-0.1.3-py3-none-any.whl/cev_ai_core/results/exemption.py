from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import ExemptionDocType
from cev_ai_core.llm_config.output_types.extraction.exemption import (
    ExemptionExtractionOutputType,
)
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class ExemptionClassificationResult(BaseClassificationResult[ExemptionDocType]):
    pass


class ExemptionFinalResult(
    BaseFinalResult[ExemptionExtractionOutputType, ExemptionClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> ExemptionClassificationResult:
        return ExemptionClassificationResult(
            activity_type=Activity.EXEMPTION,
            document_type=self.extraction.document_type,
        )
