from pydantic import computed_field

from cev_ai_core.activity import Activity
from cev_ai_core.doc_types import SchoolDocType
from cev_ai_core.llm_config.output_types import SchoolExtractionOutputType
from cev_ai_core.results.base import BaseClassificationResult, BaseFinalResult


class SchoolClassificationResult(BaseClassificationResult[SchoolDocType]):
    pass


class SchoolFinalResult(
    BaseFinalResult[SchoolExtractionOutputType, SchoolClassificationResult]
):
    @computed_field
    @property
    def classification(self) -> SchoolClassificationResult:
        return SchoolClassificationResult(
            activity_type=Activity.SCHOOL,
            document_type=self.extraction.document_type,
        )
