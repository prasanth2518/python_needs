from cev_ai_core.doc_types.base import BaseDocType


class WorkDocType(BaseDocType):
    PAYSTUB = ("paystub", "A pay stub showing wages earned during a pay period")
    EMPLOYER_LETTER = (
        "employer_letter",
        "A letter from the employer verifying employment details",
    )
    TIMESHEET = ("timesheet", "A record of hours worked during a pay period")
    W2 = (
        "w2",
        "A W-2 Wage and Tax Statement issued by an employer showing annual wages and taxes withheld. "
        "The start and end date should be the first and last day of the tax year.",
    )
    FORM_1099 = (
        "1099",
        "A 1099 tax form (e.g. 1099-NEC, 1099-MISC) reporting nonemployee compensation or miscellaneous income. "
        "The start and end date should be the first and last day of the calendar year reported.",
    )
