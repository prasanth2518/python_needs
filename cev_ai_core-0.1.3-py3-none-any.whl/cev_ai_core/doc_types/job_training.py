from cev_ai_core.doc_types.base import BaseDocType


class JobTrainingDocType(BaseDocType):
    CERTIFICATE_OF_COMPLETION = (
        "certificate_of_completion",
        "A certificate awarded upon completing a training program",
    )
    JOB_TRAINING_ATTESTATION_LETTER = (
        "job_training_attestation_letter",
        "A letter or verification form attesting to the trainee's attendance, "
        "progress, or completion for a job training program, on-the-job training "
        "(OJT) program, or workforce development program. Often issued by "
        "workforce development boards (e.g., Employ Milwaukee, WIOA programs)",
    )
    ACTIVITY_LOG = ("activity_log", "A log of training activities and hours completed")
