from cev_ai_core.doc_types.base import BaseDocType


class MedicalHardshipDocType(BaseDocType):
    # TODO: Placeholder values until we get specifics on what Medical Hardship entails
    DOCTOR_LETTER = (
        "doctor_letter",
        "A letter from a doctor describing a medical condition or hardship",
    )
    MEDICAL_REPORT = (
        "medical_report",
        "Report on medical condition(s) that would prevent one from being able to work",
    )
