from cev_ai_core.doc_types.base import BaseDocType


class VolunteeringDocType(BaseDocType):
    VOLUNTEERING_FORM = (
        "volunteering_form",
        "A signed form from an organization confirming volunteer participation",
    )
    ORGANIZATION_STATEMENT = (
        "organization_statement",
        "A letter or statement from the organization verifying community service",
    )
