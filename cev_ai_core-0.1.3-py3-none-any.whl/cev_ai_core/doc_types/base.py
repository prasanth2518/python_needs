from enum import Enum


class BaseDocType(str, Enum):
    """A custom str enum class with a description attached to it"""

    description: str

    def __new__(cls, value, description):
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj.description = description
        return obj
