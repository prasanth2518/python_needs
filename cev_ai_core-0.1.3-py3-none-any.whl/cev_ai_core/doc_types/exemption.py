from cev_ai_core.doc_types.base import BaseDocType


class ExemptionDocType(BaseDocType):
    LETTER_OF_GUARDIANSHIP = (
        "letter_of_guardianship",
        "A court-issued letter of guardianship (e.g. California GC-250) indicating "
        "that a person is under legal guardianship and therefore exempt from "
        "community engagement requirements. The subject (extracted name) should be "
        "the ward (person under guardianship), not the guardian.",
    )
