from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class CamelCaseModel(BaseModel):
    # a BaseModel to allow for camel case conversion
    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
    )
