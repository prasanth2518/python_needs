from datetime import date

from pydantic import BaseModel

from cev_ai_core.activity import Activity


class SubmitterData(BaseModel):
    """Basic member information for validation purposes."""

    first_name: str
    middle_name: str | None = None
    last_name: str
    date_of_birth: date | None = None


class ReviewCycle(BaseModel):
    start_date: date
    end_date: date


class SubmittedDocumentMetadata(BaseModel):
    """Metadata about a document submitted for verification."""

    declared_activity: Activity
    review_cycle: ReviewCycle | None = None
