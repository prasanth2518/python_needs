from os import getenv

from typing import Any

from pydantic_ai import Agent, BinaryImage

from cev_ai_core.activity import Activity
from cev_ai_core.llm_config import DEFAULT_LLM
from cev_ai_core.llm_config.output_types import (
    ExemptionExtractionOutputType,
    JobTrainingExtractionOutputType,
    MedicalHardshipExtractionOutputType,
    SchoolExtractionOutputType,
    VolunteeringExtractionOutputType,
    WorkExtractionOutputType,
)
from cev_ai_core.llm_config.output_types.classification import ClassificationOutput
from cev_ai_core.llm_config.prompts import (
    CLASSIFICATION_SYSTEM_PROMPT,
    EXEMPTION_EXTRACTION_SYSTEM_PROMPT,
    JOB_TRAINING_EXTRACTION_SYSTEM_PROMPT,
    MEDICAL_HARDSHIP_EXTRACTION_SYSTEM_PROMPT,
    SCHOOL_EXTRACTION_SYSTEM_PROMPT,
    VOLUNTEERING_EXTRACTION_SYSTEM_PROMPT,
    WORK_EXTRACTION_SYSTEM_PROMPT,
)
from cev_ai_core.requests import SubmittedDocumentMetadata, SubmitterData
from cev_ai_core.results import (
    ErrorFinalResult,
    ExemptionFinalResult,
    JobTrainingFinalResult,
    MedicalHardshipFinalResult,
    SchoolFinalResult,
    Validation,
    VolunteeringFinalResult,
    WorkFinalResult,
)
from cev_ai_core.results.base import BaseFinalResult
from cev_ai_core.validation_checks import (
    build_validation,
    validate_activity_type_match,
    validate_document_validity,
)


def sum_hours(values: list[float]) -> float:
    """Sum a list of hour values. Use this tool to calculate total hours worked in a time period by summing individual daily hour entries."""
    return sum(values)


async def classify_document(images: list[bytes]) -> ClassificationOutput:

    agent = Agent(
        system_prompt=CLASSIFICATION_SYSTEM_PROMPT,
        model=getenv("CLASSIFIER_MODEL", DEFAULT_LLM),
    )
    result = await agent.run(
        user_prompt=[
            BinaryImage(data=image, media_type="image/png") for image in images
        ],
        output_type=ClassificationOutput,
    )
    return result.output


async def extract_document_data(activity: Activity, images: list[bytes]):
    tools: list[Any] = []

    match activity:
        case Activity.WORK:
            system_prompt = WORK_EXTRACTION_SYSTEM_PROMPT
            output_type = WorkExtractionOutputType
            tools = [sum_hours]
        case Activity.SCHOOL:
            system_prompt = SCHOOL_EXTRACTION_SYSTEM_PROMPT
            output_type = SchoolExtractionOutputType
        case Activity.JOB_TRAINING:
            system_prompt = JOB_TRAINING_EXTRACTION_SYSTEM_PROMPT
            output_type = JobTrainingExtractionOutputType
        case Activity.VOLUNTEERING:
            system_prompt = VOLUNTEERING_EXTRACTION_SYSTEM_PROMPT
            output_type = VolunteeringExtractionOutputType
        case Activity.MEDICAL_HARDSHIP:
            system_prompt = MEDICAL_HARDSHIP_EXTRACTION_SYSTEM_PROMPT
            output_type = MedicalHardshipExtractionOutputType
        case Activity.EXEMPTION:
            system_prompt = EXEMPTION_EXTRACTION_SYSTEM_PROMPT
            output_type = ExemptionExtractionOutputType

    agent = Agent(
        system_prompt=system_prompt,
        model=getenv("EXTRACTOR_MODEL", DEFAULT_LLM),
        tools=tools,
    )

    user_prompt: list[Any] = []
    if len(images) == 1:
        user_prompt.append(BinaryImage(data=images[0], media_type="image/png"))
    else:
        for i, image in enumerate(images, 1):
            user_prompt.append(f"--- Page {i} of {len(images)} ---")
            user_prompt.append(BinaryImage(data=image, media_type="image/png"))

    result = await agent.run(
        user_prompt=user_prompt,
        output_type=output_type,
    )

    return result.output


ACTIVITY_TO_FINAL_RESULT: dict[Activity, type[BaseFinalResult]] = {
    Activity.WORK: WorkFinalResult,
    Activity.SCHOOL: SchoolFinalResult,
    Activity.JOB_TRAINING: JobTrainingFinalResult,
    Activity.VOLUNTEERING: VolunteeringFinalResult,
    Activity.MEDICAL_HARDSHIP: MedicalHardshipFinalResult,
    Activity.EXEMPTION: ExemptionFinalResult,
}


def invalid_document_response(
    invalid_reason: str | None,
) -> ErrorFinalResult:
    check = validate_document_validity(invalid_reason)
    return ErrorFinalResult(
        validation=Validation(errors=[check], checks=[]),
    )


def activity_mismatch_response(
    declared_activity: Activity,
    predicted_activity_type: Activity,
) -> ErrorFinalResult:
    check = validate_activity_type_match(declared_activity, predicted_activity_type)
    return ErrorFinalResult(
        validation=Validation(errors=[check], checks=[]),
        activity_type=predicted_activity_type,
    )


async def process_document(
    submitter_data: SubmitterData,
    submitted_document_metadata: SubmittedDocumentMetadata,
    images: list[bytes],
    as_json: bool = True,
) -> BaseFinalResult | dict:
    declared_activity = submitted_document_metadata.declared_activity

    classification_output = await classify_document(images)
    predicted_activity_type = classification_output.activity

    if not classification_output.is_valid:
        result = invalid_document_response(classification_output.invalid_reason)
        return result.model_dump(by_alias=True, mode="json") if as_json else result

    if not predicted_activity_type:
        result = invalid_document_response("unclassifiable")
        return result.model_dump(by_alias=True, mode="json") if as_json else result

    if predicted_activity_type != declared_activity:
        result = activity_mismatch_response(declared_activity, predicted_activity_type)
        return result.model_dump(by_alias=True, mode="json") if as_json else result

    extraction = await extract_document_data(predicted_activity_type, images)

    validation = build_validation(
        submitter_data, declared_activity, predicted_activity_type, extraction
    )

    result_cls = ACTIVITY_TO_FINAL_RESULT[predicted_activity_type]
    result = result_cls(validation=validation, extraction=extraction)
    return result.model_dump(by_alias=True, mode="json") if as_json else result
