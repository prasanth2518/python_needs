DEFAULT_LLM = "openai:gpt-5-mini"
