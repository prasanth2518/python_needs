from cev_ai_core.doc_types import (
    ExemptionDocType,
    JobTrainingDocType,
    MedicalHardshipDocType,
    SchoolDocType,
    VolunteeringDocType,
    WorkDocType,
)
from cev_ai_core.llm_config.output_types import (
    ExemptionExtractionOutputType,
    JobTrainingExtractionOutputType,
    MedicalHardshipExtractionOutputType,
    SchoolExtractionOutputType,
    VolunteeringExtractionOutputType,
    WorkExtractionOutputType,
)
from cev_ai_core.llm_config.prompts._prompt_builders import (
    _build_classifier_prompt,
    _build_extractor_prompt,
)

CLASSIFICATION_SYSTEM_PROMPT = _build_classifier_prompt()
WORK_EXTRACTION_SYSTEM_PROMPT = _build_extractor_prompt(
    WorkExtractionOutputType.__doc__, WorkDocType
)
SCHOOL_EXTRACTION_SYSTEM_PROMPT = _build_extractor_prompt(
    SchoolExtractionOutputType.__doc__, SchoolDocType
)
JOB_TRAINING_EXTRACTION_SYSTEM_PROMPT = _build_extractor_prompt(
    JobTrainingExtractionOutputType.__doc__, JobTrainingDocType
)
VOLUNTEERING_EXTRACTION_SYSTEM_PROMPT = _build_extractor_prompt(
    VolunteeringExtractionOutputType.__doc__, VolunteeringDocType
)
MEDICAL_HARDSHIP_EXTRACTION_SYSTEM_PROMPT = _build_extractor_prompt(
    MedicalHardshipExtractionOutputType.__doc__, MedicalHardshipDocType
)
EXEMPTION_EXTRACTION_SYSTEM_PROMPT = _build_extractor_prompt(
    ExemptionExtractionOutputType.__doc__, ExemptionDocType
)
