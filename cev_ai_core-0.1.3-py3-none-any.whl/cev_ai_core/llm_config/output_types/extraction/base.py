from pydantic import Field

from cev_ai_core.camel_case_base import CamelCaseModel


class BaseExtractionSchema(CamelCaseModel):
    reasoning: str = Field(
        description=(
            "Show your reasoning and working out here for any calculation. "
            "This will be used for auditing on how certain decisions are made "
            "and how certain numbers are generated"
        ),
        exclude=True,
    )
    is_relevant: bool = Field(
        description="Determine whether the document presented is relevant to the provided list of document types",
        exclude=True,
    )
