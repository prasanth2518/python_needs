from typing import Literal

from pydantic import Field

from cev_ai_core.doc_types import JobTrainingDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class ActivityMetrics(CamelCaseModel):
    unit: Literal["hours", "minutes"] | None = Field(
        default=None,
        description="The unit that the time of training is calculated in",
    )
    quantity: float | None = Field(
        default=None,
        description="Aggregated quantity of the unit of training time shown on the document",
    )


class JobTrainingExtractionOutputType(BaseExtractionSchema):
    """Documents proving participation in workforce development, skills training, or on-the-job training (OJT) programs. These are NOT regular employment — they are issued by workforce development boards, training agencies, or programs like WIOA/OJT. Even if the document mentions an employer or hours worked, if it is issued by or references a training program or workforce development agency, it belongs here."""

    document_type: JobTrainingDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    document_date: DocumentDates
    document_source: DocumentSource
    activity_metrics: ActivityMetrics
