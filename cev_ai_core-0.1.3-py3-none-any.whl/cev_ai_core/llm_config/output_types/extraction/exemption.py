from typing import Literal

from pydantic import Field

from cev_ai_core.doc_types import ExemptionDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    Subject,
)

ExemptionType = Literal["guardianship"]


class ExemptionExtractionOutputType(BaseExtractionSchema):
    """Documents proving an exemption from community engagement requirements. This includes court-issued letters of guardianship indicating that a person is under legal guardianship and therefore exempt from participation requirements."""

    document_type: ExemptionDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )

    subject: Subject
    document_dates: DocumentDates
    exemption_type: ExemptionType | None = Field(
        default=None,
        description="The type of exemption claimed in the document",
    )
