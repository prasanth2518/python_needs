from typing import Literal

from pydantic import Field

from cev_ai_core.doc_types import VolunteeringDocType
from cev_ai_core.llm_config.output_types.extraction.base import (
    BaseExtractionSchema,
    CamelCaseModel,
)
from cev_ai_core.llm_config.output_types.extraction.common import (
    DocumentDates,
    DocumentSource,
    Subject,
)


class ActivityMetrics(CamelCaseModel):
    unit: Literal["hours", "minutes"] | None = Field(
        default=None,
        description="The unit that the time of volunteering is calculated in",
    )
    quantity: float | None = Field(
        default=None,
        description="Aggregated quantity of the unit of training time shown on the document",
    )


class VolunteeringExtractionOutputType(BaseExtractionSchema):
    """Documents proving unpaid volunteer or community service participation"""

    document_type: VolunteeringDocType | None = Field(
        default=None,
        description="Determine the type of document this belongs to",
        exclude=True,
    )
    subject: Subject
    document_date: DocumentDates
    document_source: DocumentSource
    activity_metrics: ActivityMetrics
