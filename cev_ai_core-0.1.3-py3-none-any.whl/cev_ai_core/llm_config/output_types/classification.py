from typing import Literal

from pydantic import BaseModel, Field

from cev_ai_core.activity import Activity


class ClassificationOutput(BaseModel):
    reasoning: str = Field(
        description="Write down your reasoning for your classifiction for audit"
    )
    invalid_reason: Literal["multi_doc", "multi_activity", "irrelevant"] | None = Field(
        default=None,
        description="Determine, if any, which reason caused the document to be invalid",
    )
    is_valid: bool = Field(description="Determine whether the document is valid or not")
    activity: Activity | None = Field(
        default=None,
        description=(
            "Identify the activity of the provided document if the document is valid. "
            "If the document is not valid, then return with default value"
        ),
    )
