import io
from pathlib import Path

from PIL import Image


def render_pdf_as_bytes(path: Path, scale: float = 4.0) -> list[bytes]:
    """Render PDF pages to PNG bytes using pypdfium2."""
    try:
        import pypdfium2 as pdfium
    except ImportError as exc:
        raise RuntimeError(
            "pypdfium2 is required for PDF rendering but is not installed"
        ) from exc

    images: list[bytes] = []
    pdf = pdfium.PdfDocument(str(path))
    if pdf.get_formtype():
        pdf.init_forms()

    for page in pdf:
        bitmap = page.render(scale=scale, draw_annots=True)
        pil_image = bitmap.to_pil()

        buf = io.BytesIO()
        pil_image.save(buf, format="PNG")
        images.append(buf.getvalue())

    return images


def render_png_as_bytes(path: Path, scale: float = 2.0) -> list[bytes]:
    """Render a PNG image to PNG bytes, optionally rescaled."""
    img = Image.open(path)
    img.load()

    if scale != 1.0:
        new_width = int(img.width * scale)
        new_height = int(img.height * scale)
        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return [buf.getvalue()]


def render_jpg_as_bytes(path: Path, scale: float = 2.0) -> list[bytes]:
    """Render a JPG image to PNG bytes, optionally rescaled."""
    img = Image.open(path)
    img.load()

    # JPEGs can be palette or CMYK; convert to RGB for consistent PNG output
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGB")

    if scale != 1.0:
        new_width = int(img.width * scale)
        new_height = int(img.height * scale)
        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return [buf.getvalue()]
