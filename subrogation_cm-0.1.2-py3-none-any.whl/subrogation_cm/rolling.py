from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from dv_agent_core import create_classifier, create_extractor

from subrogation_cm.models import TypeCandidate
from subrogation_cm.tools import priority_rank
from subrogation_cm.utils import document_to_base64_images, normalize_doc_type


@dataclass
class RollingWindowResult:
    """Aggregated rolling-window classification output."""

    type: Optional[str]
    confidence: Optional[float]
    reasoning: Optional[str]
    possible_types: List[Dict[str, Any]]
    window_results: List[Dict[str, Any]]


def build_windows(
    images: Sequence[str], *, window_size: int = 5, overlap: int = 2
) -> List[List[str]]:
    """Split image payloads into overlapping rolling windows."""
    if window_size <= 0:
        raise ValueError("window_size must be > 0")
    if overlap < 0:
        raise ValueError("overlap must be >= 0")
    if overlap >= window_size:
        raise ValueError("overlap must be < window_size")

    stride = window_size - overlap
    windows: List[List[str]] = []
    for start in range(0, len(images), stride):
        window = list(images[start : start + window_size])
        if not window:
            break
        windows.append(window)
        if start + window_size >= len(images):
            break
    return windows


def _candidate_from_payload(raw: Any) -> Optional[TypeCandidate]:
    """Parse/normalize one possible-type payload into a model."""
    if isinstance(raw, TypeCandidate):
        return raw
    if not isinstance(raw, dict):
        return None

    candidate_type = _normalize_type_label(raw.get("type"))
    if not candidate_type:
        return None

    confidence = raw.get("confidence")
    if not isinstance(confidence, (int, float)):
        confidence = None

    return TypeCandidate(type=candidate_type, confidence=confidence)


def _extract_possible_types(payload: Dict[str, Any]) -> List[TypeCandidate]:
    """Return a candidate-type list from classifier payload."""
    docs = payload.get("documents") or []
    if not docs:
        return []

    top = docs[0] or {}
    possible = top.get("possible_types") or []
    if possible:
        normalized: List[TypeCandidate] = []
        for candidate in possible:
            parsed = _candidate_from_payload(candidate)
            if parsed:
                normalized.append(parsed)
        return normalized

    top_type = _normalize_type_label(top.get("type"))
    if top_type:
        confidence = top.get("confidence")
        if not isinstance(confidence, (int, float)):
            confidence = 0.0
        return [TypeCandidate(type=top_type, confidence=confidence)]
    return []


def _normalize_type_label(value: Any) -> Optional[str]:
    """Normalize type labels to canonical snake_case."""
    if value is None:
        return None
    normalized = normalize_doc_type(str(value))
    return normalized or None


def aggregate_possible_types(
    window_candidates: Iterable[Iterable[Any]],
) -> List[Dict[str, Any]]:
    """Union candidate types across windows, keeping max confidence per type."""
    by_type: Dict[str, TypeCandidate] = {}
    for candidates in window_candidates:
        for raw_candidate in candidates:
            candidate = _candidate_from_payload(raw_candidate)
            if candidate is None:
                continue

            type_name = candidate.type
            confidence = candidate.confidence
            existing = by_type.get(type_name)
            if existing is None:
                by_type[type_name] = candidate
                continue

            existing_conf = existing.confidence
            if isinstance(confidence, (int, float)) and (
                not isinstance(existing_conf, (int, float))
                or confidence > existing_conf
            ):
                by_type[type_name] = candidate

    def _confidence_sort_key(candidate: TypeCandidate) -> float:
        value = candidate.confidence
        if isinstance(value, (int, float)):
            return float(value)
        return -1.0

    aggregated_models = list(by_type.values())
    aggregated_models.sort(key=_confidence_sort_key, reverse=True)
    return [candidate.model_dump() for candidate in aggregated_models]


def _select_by_priority(
    possible_types: List[Dict[str, Any]], priority_list: Optional[Any]
) -> Dict[str, Any]:
    """Pick winning candidate using priority tool when a priority list is provided."""
    if not possible_types:
        return {"selected": None, "candidates": [], "tool_used": False}
    if not priority_list or priority_list == "None":
        return {
            "selected": possible_types[0],
            "candidates": possible_types,
            "tool_used": False,
        }

    ranked = priority_rank(possible_types, priority_list)
    ranked["tool_used"] = True
    return ranked


async def classify_document_rolling(
    *,
    document_path: Optional[Path] = None,
    base64_images: Optional[Sequence[str]] = None,
    config: Optional[Dict[str, Any]] = None,
    context: Optional[Dict[str, Any]] = None,
    window_size: int = 5,
    overlap: int = 2,
    classifier: Optional[Any] = None,
) -> RollingWindowResult:
    """Classify a document over rolling image windows and aggregate the final result."""
    if base64_images is None:
        if document_path is None:
            raise ValueError("document_path or base64_images is required")
        base64_images = document_to_base64_images(Path(document_path))

    windows = build_windows(base64_images, window_size=window_size, overlap=overlap)
    if not windows:
        return RollingWindowResult(
            type=None,
            confidence=None,
            reasoning=None,
            possible_types=[],
            window_results=[],
        )

    if classifier is None:
        if config is None:
            raise ValueError("config is required when classifier is not provided")
        classifier = create_classifier(config)

    window_candidates: List[List[TypeCandidate]] = []
    reasoning_by_type: Dict[str, str] = {}
    window_results: List[Dict[str, Any]] = []

    for window in windows:
        result = await classifier.classify(base64_images=list(window), context=context)
        payload = result.model_dump() if hasattr(result, "model_dump") else dict(result)
        window_candidates.append(_extract_possible_types(payload))

        docs = payload.get("documents") or []
        if docs:
            top = docs[0] or {}
            doc_type = _normalize_type_label(top.get("type"))
            reasoning = top.get("reasoning")
            confidence = top.get("confidence")
            window_summary: Dict[str, Any] = {
                "type": doc_type,
                "reasoning": reasoning if isinstance(reasoning, str) else None,
            }
            if isinstance(confidence, (int, float)):
                window_summary["confidence"] = float(confidence)
            window_results.append(window_summary)
            if isinstance(doc_type, str) and isinstance(reasoning, str):
                reasoning_by_type.setdefault(doc_type, reasoning)
        else:
            window_results.append({})

    aggregated = aggregate_possible_types(window_candidates)
    priority_list = (context or {}).get("priority_list")
    selection = _select_by_priority(aggregated, priority_list)
    selected = selection.get("selected") or (aggregated[0] if aggregated else None)

    selected_type: Optional[str] = None
    selected_confidence: Optional[float] = None
    if selected:
        selected_type = _normalize_type_label(
            selected.get("type") or selected.get("label")
        )
        confidence = selected.get("confidence")
        if isinstance(confidence, (int, float)):
            selected_confidence = float(confidence)

    if selected_type:
        reasoning = reasoning_by_type.get(selected_type)
        if selection.get("tool_used"):
            candidates = selection.get("candidates") or []
            labels = ", ".join(
                c.get("label") or c.get("type")
                for c in candidates
                if c.get("label") or c.get("type")
            )
            selected_rank = (selection.get("selected", {}) or {}).get("priority_rank")
            suffix = (
                "Priority tool used to resolve candidates "
                f"[{labels}]; selected '{selected_type}' (rank {selected_rank})."
            )
            reasoning = f"{reasoning}\n{suffix}" if reasoning else suffix

        ordered_models = [
            TypeCandidate(type=selected_type, confidence=selected_confidence)
        ]
        for candidate in aggregated:
            parsed = _candidate_from_payload(candidate)
            if parsed and parsed.type != selected_type:
                ordered_models.append(parsed)
        ordered = [candidate.model_dump() for candidate in ordered_models]
    else:
        reasoning = None
        ordered = aggregated

    return RollingWindowResult(
        type=selected_type,
        confidence=selected_confidence,
        reasoning=reasoning,
        possible_types=ordered,
        window_results=window_results,
    )


def _is_empty_value(value: Any) -> bool:
    """Return True when a value should be treated as absent during merges."""
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip() == ""
    if isinstance(value, (list, tuple, set, dict)):
        return len(value) == 0
    return False


def _stable_key(value: Any) -> str:
    """Create a deterministic key for deduplication/frequency operations."""
    try:
        return json.dumps(value, sort_keys=True, default=str)
    except TypeError:
        return repr(value)


def _merge_scalar_values(values: Sequence[Any]) -> Any:
    """Select scalar by most-frequent vote; tie-break by first-seen order."""
    meaningful = [value for value in values if not _is_empty_value(value)]
    if not meaningful:
        return None

    counts: Dict[str, int] = {}
    first_seen: Dict[str, int] = {}
    originals: Dict[str, Any] = {}

    for idx, value in enumerate(meaningful):
        key = _stable_key(value)
        counts[key] = counts.get(key, 0) + 1
        if key not in first_seen:
            first_seen[key] = idx
            originals[key] = value

    winner = min(counts.keys(), key=lambda key: (-counts[key], first_seen[key]))
    return originals[winner]


def _merge_list_values(values: Sequence[List[Any]]) -> List[Any]:
    """Merge list fields with stable union and deduplication."""
    merged: List[Any] = []
    seen: set[str] = set()

    for value_list in values:
        for item in value_list:
            if _is_empty_value(item):
                continue
            key = _stable_key(item)
            if key in seen:
                continue
            seen.add(key)
            merged.append(item)

    return merged


def _merge_dict_values(values: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Recursively merge dict payloads field-by-field."""
    merged: Dict[str, Any] = {}
    ordered_keys: List[str] = []

    for payload in values:
        for key in payload:
            if key not in ordered_keys:
                ordered_keys.append(key)

    for key in ordered_keys:
        key_values = [payload[key] for payload in values if key in payload]
        resolved = _merge_values(key_values)
        if not _is_empty_value(resolved):
            merged[key] = resolved

    return merged


def _merge_values(values: Sequence[Any]) -> Any:
    """Merge homogeneous value types recursively; fallback to scalar vote."""
    meaningful = [value for value in values if not _is_empty_value(value)]
    if not meaningful:
        return None

    if all(isinstance(value, dict) for value in meaningful):
        dict_values = [value for value in meaningful if isinstance(value, dict)]
        return _merge_dict_values(dict_values)

    if all(isinstance(value, list) for value in meaningful):
        list_values = [value for value in meaningful if isinstance(value, list)]
        return _merge_list_values(list_values)

    return _merge_scalar_values(meaningful)


def merge_extraction_payloads(payloads: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge extraction payloads across windows.

    Rules:
    - Scalars: choose most frequent non-null value; ties break by first-seen order.
    - Lists: stable union + dedupe.
    - Dicts: recursive field-wise merge.
    - Empty/null values do not override meaningful values.
    """
    dict_payloads = [payload for payload in payloads if isinstance(payload, dict)]
    if not dict_payloads:
        return {}
    return _merge_dict_values(dict_payloads)


async def extract_document_rolling(
    *,
    document_path: Optional[Path] = None,
    base64_images: Optional[Sequence[str]] = None,
    config: Optional[Dict[str, Any]] = None,
    context: Optional[Dict[str, Any]] = None,
    window_size: int = 5,
    overlap: int = 2,
    extractor: Optional[Any] = None,
) -> Dict[str, Any]:
    """Extract over rolling windows and merge the resulting payloads."""
    if base64_images is None:
        if document_path is None:
            raise ValueError("document_path or base64_images is required")
        base64_images = document_to_base64_images(Path(document_path))

    windows = build_windows(base64_images, window_size=window_size, overlap=overlap)
    if not windows:
        return {}

    if extractor is None:
        if config is None:
            raise ValueError("config is required when extractor is not provided")
        extractor = create_extractor(config)

    payloads: List[Dict[str, Any]] = []
    for window in windows:
        result = await extractor.extract(base64_images=list(window), context=context)
        payload = result.model_dump() if hasattr(result, "model_dump") else dict(result)
        if isinstance(payload, dict):
            payloads.append(payload)

    return merge_extraction_payloads(payloads)
