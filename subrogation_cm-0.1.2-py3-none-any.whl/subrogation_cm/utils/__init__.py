from __future__ import annotations

from collections import defaultdict
import json
import re
import sys
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import yaml
from loguru import logger
from openpyxl.cell import cell as openpyxl_cell
import pandas as pd
from subrogation_cm.configs import SAMPLE_DOC_ROOT, SUPPORTED_EXTENSIONS
from subrogation_cm.models import (
    ClassificationRecord,
    DEFAULT_PRIORITY_TYPES,
    PipelineEntry,
    PRIORITY_TYPE_ALIASES,
    PriorityContextPayload,
    SecondPassMappingRow,
)
from subrogation_cm.prompts import (
    SECOND_PASS_HARD_RULE_LINES,
    SecondPassInstructionMode,
    SECOND_PASS_PROMPT_APPEND_TEMPLATE,
    SECOND_PASS_INTERIM_KEYWORD_HEADER,
    SECOND_PASS_MED_RELEASE_CONFLICT_RULES,
    SECOND_PASS_PROMPT_TEMPLATE,
)


def collect_documents(
    inputs: Sequence[Path | str], *, recursive: bool = True
) -> List[Path]:
    """
    Expand any mix of files or directories into a sorted list of document paths.
    """
    documents: List[Path] = []
    seen: set[Path] = set()

    for item in inputs:
        path = Path(item).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"Input path does not exist: {path}")

        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS:
            if path not in seen:
                documents.append(path)
                seen.add(path)
            continue

        if path.is_dir():
            candidates: Iterable[Path] = (
                path.rglob("*") if recursive else path.iterdir()
            )
            for candidate in sorted(candidates):
                if (
                    candidate.is_file()
                    and candidate.suffix.lower() in SUPPORTED_EXTENSIONS
                ):
                    if candidate not in seen:
                        documents.append(candidate)
                        seen.add(candidate)
            continue

        raise ValueError(f"Unsupported input: {path}")

    return documents


def write_json(payload, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2))


def load_tiff_as_images(path: Path) -> List[bytes]:
    """
    Load a multi-page TIFF and return PNG bytes per page.
    """
    try:
        from PIL import Image, ImageSequence
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise RuntimeError("Pillow is required to read TIFF files.") from exc

    images: List[bytes] = []
    try:
        with Image.open(path) as img:
            for frame in ImageSequence.Iterator(img):
                if frame.mode not in ("RGB", "L"):
                    frame = frame.convert("RGB")
                buf = BytesIO()
                frame.save(buf, format="PNG")
                images.append(buf.getvalue())
    except Exception as exc:  # pragma: no cover - defensive guard
        raise RuntimeError(f"Failed to load TIFF {path}: {exc}") from exc

    return images


def document_to_base64_images(
    path: Path, max_images: Optional[int] = None
) -> List[str]:
    """
    Convert a document into a list of base64-encoded PNG data URIs.
    """
    from dv_agent_core.utils.document import (
        encode_image_to_base64,
        load_document_as_images,
    )

    suffix = path.suffix.lower()
    if suffix in {".tif", ".tiff"}:
        images = load_tiff_as_images(path)
    else:
        images = load_document_as_images(path)

    if max_images is not None and max_images > 0:
        images = images[:max_images]

    return [encode_image_to_base64(img) for img in images]


def build_base64_entry(
    path: Path, *, max_images: Optional[int] = None
) -> Dict[str, Any]:
    """
    Build a base64_images payload entry for classification.
    """
    return PipelineEntry(
        name=str(path),
        path=None,
        base64_images=document_to_base64_images(path, max_images=max_images),
    ).model_dump(exclude_none=True)


def default_inputs(inputs: List[Path]) -> List[Path]:
    if inputs:
        return inputs
    repo_root = Path(__file__).resolve().parent.parent.parent
    return [(repo_root / SAMPLE_DOC_ROOT).resolve()]


def load_type_map(classification_path: Path) -> Dict[str, str]:
    """
    Load a JSON list of classification records into a lookup of path -> lien_type.
    """
    raw_records = json.loads(classification_path.read_text())
    mapping: Dict[str, str] = {}
    for rec in raw_records:
        record = ClassificationRecord.model_validate(rec)
        if record.path and record.type:
            mapping[record.path] = record.type
    return mapping


def load_config(path: Optional[Path], *, fallback: Dict[str, Any]) -> Dict[str, Any]:
    """
    Load a JSON or YAML config file. Returns the fallback dict when path is None.
    """
    if path is None:
        return fallback

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    suffix = path.suffix.lower()
    if suffix in {".json"}:
        return json.loads(path.read_text())
    if suffix in {".yaml", ".yml"}:
        return yaml.safe_load(path.read_text())
    if suffix == ".py":
        import importlib.util

        spec = importlib.util.spec_from_file_location(path.stem, path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Failed to import config from {path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        cfg = getattr(module, "CLASSIFICATION_CONFIG", None)
        if cfg is None:
            raise RuntimeError(f"CLASSIFICATION_CONFIG not found in {path}")
        return cfg

    raise ValueError(
        f"Unsupported config format for {path} (expected .json/.yaml/.yml)"
    )


def normalize_doc_type(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip().lower())
    return value.strip("_")


def load_priority_map(path: Path) -> Dict[str, List[str]]:
    """
    Load priority list from the Excel workbook.

    Returns a mapping of context -> ordered list of raw document type names.
    """
    df = pd.read_excel(path, sheet_name="Priority List")
    df = df.rename(columns=lambda c: str(c).strip())
    required = {"Context", "Document Type", "Priority"}
    if not required.issubset(df.columns):
        raise ValueError(
            f"Priority List sheet must include columns: {sorted(required)}"
        )

    df = df.dropna(subset=["Context", "Document Type", "Priority"])
    df["Priority"] = pd.to_numeric(df["Priority"], errors="coerce")
    df = df.dropna(subset=["Priority"])
    df["Priority"] = df["Priority"].astype(int)

    priority_map: Dict[str, List[str]] = {}
    for context, group in df.groupby("Context"):
        ordered = group.sort_values("Priority")["Document Type"].tolist()
        priority_map[str(context).strip()] = [
            str(item).strip() for item in ordered if str(item).strip()
        ]
    return priority_map


def build_priority_context(
    *,
    priority_map: Dict[str, List[str]],
    context: str,
    type_names: Iterable[str],
    no_priority_contexts: Optional[Iterable[str]] = None,
) -> Dict[str, Any]:
    """
    Build context dict for classifier priority hints.
    """

    def _context_payload(
        priority_list: str, priority_types: Sequence[str]
    ) -> Dict[str, Any]:
        return PriorityContextPayload(
            priority_context=context,
            priority_list=priority_list,
            priority_hint=(
                f"No priority list provided for context {context}."
                if priority_list == "None"
                else f"For context {context}, if multiple types apply, choose the highest priority: {priority_list}."
            ),
            priority_types=list(priority_types),
        ).model_dump()

    if no_priority_contexts and context in set(no_priority_contexts):
        return _context_payload("None", [])

    normalized_types = {normalize_doc_type(t) for t in type_names if t}
    ordered: List[str] = []
    for raw in priority_map.get(context, []):
        normalized = normalize_doc_type(raw)
        normalized = PRIORITY_TYPE_ALIASES.get(normalized, normalized)
        if normalized in normalized_types and normalized not in ordered:
            ordered.append(normalized)

    if ordered:
        # Keep all priorities through the furthest default type that appears
        # in this context's ordered list.
        default_indices = [
            ordered.index(default_type)
            for default_type in DEFAULT_PRIORITY_TYPES
            if default_type in ordered
        ]
        if default_indices:
            cutoff_idx = max(default_indices)
            ordered = ordered[: cutoff_idx + 1]

    if ordered:
        listed = "; ".join(f"{idx + 1}) {name}" for idx, name in enumerate(ordered))
        return _context_payload(listed, ordered)

    return _context_payload("None", [])


def inline_priority_hint(
    config: Dict[str, Any], priority_hint: str | None
) -> Dict[str, Any]:
    """Inject resolved priority hint into instruction template placeholders."""
    if not priority_hint:
        return config

    instruction_template = config.get("instruction_template", "")
    if not instruction_template:
        return config

    updated = instruction_template.replace("${{priority_hint}}", priority_hint)
    updated = updated.replace("${priority_hint}", priority_hint)
    if updated == instruction_template:
        return config

    merged = dict(config)
    merged["instruction_template"] = updated
    return merged


def filter_types_by_priority(
    config: Dict[str, Any],
    priority_types: Sequence[str] | None,
) -> Dict[str, Any]:
    """Filter type catalog to the allowed normalized type names."""
    if not priority_types:
        return config
    allowed = {normalize_doc_type(t) for t in priority_types if t}
    if not allowed:
        return config
    types = [
        t
        for t in config.get("types", [])
        if normalize_doc_type(str(t.get("name", ""))) in allowed
    ]
    if not types:
        return config
    filtered = dict(config)
    filtered["types"] = types
    return filtered


def advance_progress(progress: Any, task_id: Any) -> None:
    """Advance a progress task when available."""
    if progress and task_id is not None:
        progress.advance(task_id)


def extract_type_names(config: Dict[str, Any]) -> set[str]:
    """Return normalized document type names from config."""
    names: set[str] = set()
    for item in config.get("types", []):
        if not isinstance(item, dict):
            continue
        normalized = normalize_doc_type(str(item.get("name", "")))
        if normalized:
            names.add(normalized)
    return names


def normalize_second_pass_label(value: Any) -> str | None:
    """Normalize second-pass mapping labels."""
    if value is None:
        return None
    normalized = normalize_doc_type(str(value))
    return normalized or None


def prepare_second_pass_mapping(
    mapping_rows: Any,
    *,
    allowed_types: set[str],
) -> Dict[str, List[SecondPassMappingRow]]:
    """Validate and group second-pass mapping rows by predicted type."""
    grouped: Dict[str, List[SecondPassMappingRow]] = defaultdict(list)
    if not isinstance(mapping_rows, Sequence) or isinstance(mapping_rows, (str, bytes)):
        return {}

    for row in mapping_rows:
        if isinstance(row, SecondPassMappingRow):
            row_data = row.model_dump()
        elif isinstance(row, dict):
            row_data = row
        else:
            continue

        predicted_type = normalize_second_pass_label(row_data.get("predicted_type"))
        correct_type = normalize_second_pass_label(row_data.get("correct_type"))

        raw_rationale = row_data.get("rationale")
        rationale: list[str] = []
        if isinstance(raw_rationale, Sequence) and not isinstance(
            raw_rationale, (str, bytes)
        ):
            for item in raw_rationale:
                text = str(item).strip()
                if text:
                    rationale.append(text)
        elif isinstance(raw_rationale, str):
            text = raw_rationale.strip()
            if text:
                rationale.append(text)

        if not predicted_type or not correct_type:
            continue
        if not rationale:
            continue
        if predicted_type == correct_type:
            continue
        # Keep mapping rows whose target (correct_type) is allowed for the active
        # context, even when predicted_type is outside the allowed catalog
        # (e.g., predicted_type="other" used only as a remap source).
        if correct_type not in allowed_types:
            continue

        grouped[predicted_type].append(
            SecondPassMappingRow(
                predicted_type=predicted_type,
                correct_type=correct_type,
                rationale=rationale,
            )
        )

    return dict(grouped)


def build_second_pass_focus(
    *,
    first_pass_type: str,
    mapping_rows: Sequence[SecondPassMappingRow],
) -> tuple[list[str], int, str]:
    """Build candidate types and guidance text for second pass."""
    rationale_by_type: Dict[str, list[str]] = defaultdict(list)
    for row in mapping_rows:
        correct_type = str(row.correct_type).strip()
        if not correct_type:
            continue
        for rationale in row.rationale:
            text = str(rationale).strip()
            if text and text not in rationale_by_type[correct_type]:
                rationale_by_type[correct_type].append(text)

    candidate_correct_types = list(rationale_by_type.keys())
    rationale_count = sum(len(items) for items in rationale_by_type.values())
    lines = [
        (
            "Second-pass focus: first pass predicted "
            f"'{first_pass_type}'. Re-evaluate only the candidate pairs below."
        ),
        (
            "Use the rationale evidence to explain why one candidate better fits "
            "the visible document text."
        ),
    ]
    for candidate in candidate_correct_types:
        lines.append(f"- Candidate correct type: {candidate}")
        for item in rationale_by_type[candidate]:
            lines.append(f"  - {item}")

    return candidate_correct_types, rationale_count, "\n".join(lines)


def escape_format_braces(value: str) -> str:
    """Escape braces so downstream str.format only resolves known placeholders."""
    return value.replace("{", "{{").replace("}", "}}")


def extract_override_keywords(rationales: Sequence[str]) -> List[str]:
    """Extract keyword-like phrases from rationale lines (quoted terms first)."""
    keywords: List[str] = []
    seen: set[str] = set()

    for rationale in rationales:
        text = str(rationale).strip()
        if not text:
            continue

        quoted_terms = re.findall(r'"([^"]+)"', text)
        candidates = quoted_terms if quoted_terms else [text]

        for candidate in candidates:
            cleaned = " ".join(str(candidate).strip().split()).strip(" .;:-")
            if len(cleaned) < 4:
                continue
            dedupe_key = cleaned.lower()
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            keywords.append(cleaned)

    return keywords


def build_second_pass_catalog(
    *,
    first_pass_type: str,
    focused_types: Sequence[str],
    focused_types_catalog: Sequence[Dict[str, str]],
    rationale_map: Dict[str, List[str]],
    catalog_mode: str | None = None,
) -> List[Dict[str, str]]:
    """Build second-pass catalog entries for either full or rationale-only modes."""
    mode = str(catalog_mode or "full").strip().lower()
    description_by_name = {
        normalize_doc_type(str(item.get("name", ""))): " ".join(
            str(item.get("description", "")).strip().split()
        )
        or "(no description provided)"
        for item in focused_types_catalog
        if isinstance(item, dict)
    }

    if mode != "rationale_only":
        return [
            {
                "name": type_name,
                "description": description_by_name.get(
                    type_name, "(no description provided)"
                ),
            }
            for type_name in focused_types
            if type_name
        ]

    rows: List[Dict[str, str]] = []
    for type_name in focused_types:
        if not type_name:
            continue
        if type_name == first_pass_type:
            description = (
                "Keep this label only when the visible document does not clearly "
                "match any mapped correction rationale."
            )
        else:
            rationale_keywords = extract_override_keywords(
                rationale_map.get(type_name, [])
            )
            keyword_block = (
                "; ".join(rationale_keywords[:4])
                if rationale_keywords
                else "mapped correction rationale"
            )
            description = (
                "Flip to this label only when the visible document clearly matches "
                f"these correction cues: {keyword_block}."
            )
        rows.append({"name": type_name, "description": description})
    return rows


def build_second_pass_instruction(
    *,
    first_pass_type: str,
    focused_types: Sequence[str],
    focused_types_catalog: Sequence[Dict[str, str]],
    rationale_map: Dict[str, List[str]],
    rationale_focus: str,
    base_instruction_template: str | None = None,
    instruction_mode: str | None = None,
) -> str:
    """Build dynamic second-pass instruction template."""
    focused = escape_format_braces(", ".join(focused_types))
    first_pass_type_safe = escape_format_braces(first_pass_type)
    focused_set = set(focused_types)
    types_block = escape_format_braces(
        json.dumps({"types": list(focused_types_catalog)}, indent=2, ensure_ascii=False)
    )
    mapping_payload = {
        "predicted_type": first_pass_type,
        "focused_types": list(focused_types),
        "rationale_by_correct_type": rationale_map,
    }
    mapping_block = escape_format_braces(
        json.dumps(mapping_payload, indent=2, ensure_ascii=False)
    )
    rationale_focus_safe = escape_format_braces(rationale_focus)

    conflict_rules: List[str] = []
    if first_pass_type == "medical_release_received" and "interim_lien" in focused_set:
        interim_keywords = extract_override_keywords(
            rationale_map.get("interim_lien", [])
        )
        conflict_rules.extend(SECOND_PASS_MED_RELEASE_CONFLICT_RULES)
        if interim_keywords:
            conflict_rules.append(SECOND_PASS_INTERIM_KEYWORD_HEADER)
            for keyword in interim_keywords:
                conflict_rules.append(f'  - "{keyword}"')

    conflict_rule_block = (
        escape_format_braces("\n".join(conflict_rules)) if conflict_rules else ""
    )
    render_payload = {
        "first_pass_type": first_pass_type_safe,
        "focused_types": focused,
        "hard_rules": "\n".join(SECOND_PASS_HARD_RULE_LINES),
        "conflict_rules": conflict_rule_block,
        "types_block": types_block,
        "mapping_block": mapping_block,
        "rationale_focus": rationale_focus_safe,
    }
    append_block = SECOND_PASS_PROMPT_APPEND_TEMPLATE.format(**render_payload)
    mode = (
        str(instruction_mode or SecondPassInstructionMode.INHERIT_FIRST_PASS.value)
        .strip()
        .lower()
    )
    if mode not in {
        SecondPassInstructionMode.INHERIT_FIRST_PASS.value,
        SecondPassInstructionMode.STANDALONE.value,
    }:
        mode = SecondPassInstructionMode.INHERIT_FIRST_PASS.value

    if (
        mode == SecondPassInstructionMode.INHERIT_FIRST_PASS.value
        and isinstance(base_instruction_template, str)
        and base_instruction_template.strip()
    ):
        return f"{base_instruction_template.rstrip()}\n\n{append_block}"

    return SECOND_PASS_PROMPT_TEMPLATE.format(
        **render_payload,
    )


def ensure_priority_context(context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Ensure priority keys exist so template placeholders do not leak into prompts.
    """
    ctx = dict(context) if context else {}
    payload = PriorityContextPayload(
        priority_context=str(ctx.get("priority_context") or "N/A"),
        priority_list=str(ctx.get("priority_list") or "None"),
        priority_hint=str(ctx.get("priority_hint") or "No priority list provided."),
        priority_types=(
            [str(item) for item in ctx.get("priority_types", []) if str(item).strip()]
            if isinstance(ctx.get("priority_types"), Sequence)
            and not isinstance(ctx.get("priority_types"), (str, bytes))
            else []
        ),
    )
    ctx.update(payload.model_dump())
    return ctx


def setup_logging(level: str = "INFO") -> None:
    """
    Configure loguru to emit colorized console logs.
    """
    logger.remove()
    logger.add(
        sys.stderr,
        colorize=True,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
        level=level,
    )


def write_excel(
    data: List[Dict[str, Any]], path: Path, sheet_name: str = "results"
) -> None:
    """
    Write a list of dicts to an Excel file.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(data)
    if hasattr(df, "map"):
        df = df.map(_sanitize_excel_value)
    else:  # pragma: no cover - compatibility with older pandas
        df = df.apply(lambda col: col.map(_sanitize_excel_value))
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name)


def _sanitize_excel_value(value: Any) -> Any:
    """
    Strip characters that Excel rejects (illegal control chars).
    """
    if isinstance(value, str):
        return openpyxl_cell.ILLEGAL_CHARACTERS_RE.sub("", value)
    return value


def flatten_records(
    records: List[Dict[str, Any]],
    *,
    expand_keys: Tuple[str, ...] = ("data",),
) -> List[Dict[str, Any]]:
    """
    Flatten nested dict fields (e.g., 'data') into top-level columns for table/Excel export.
    """
    flattened: List[Dict[str, Any]] = []
    for rec in records:
        row = dict(rec)
        for key in expand_keys:
            nested = row.pop(key, None)
            if isinstance(nested, dict):
                for nk, nv in nested.items():
                    if isinstance(nv, list):
                        nv = ", ".join(map(str, nv))
                    row[nk] = nv
        flattened.append(row)
    return flattened
