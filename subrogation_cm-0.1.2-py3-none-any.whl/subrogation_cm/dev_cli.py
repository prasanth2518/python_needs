from __future__ import annotations

import importlib.util
from pathlib import Path

import typer


def _ensure_dev_install() -> None:
    try:
        import ipykernel  # noqa: F401
    except Exception as exc:  # pragma: no cover - runtime check
        raise SystemExit(
            "The subro-analysis CLI is a dev-only tool. "
            "Install with `uv sync --extra dev` to enable it."
        ) from exc


def _load_pipeline_module() -> object:
    repo_root = Path(__file__).resolve().parents[2]
    script_path = repo_root / "scripts" / "00_run_analysis_pipeline.py"
    if not script_path.exists():
        raise SystemExit(f"Pipeline script not found: {script_path}")

    spec = importlib.util.spec_from_file_location("run_analysis_pipeline", script_path)
    if spec is None or spec.loader is None:
        raise SystemExit("Failed to load analysis pipeline module.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    _ensure_dev_install()
    module = _load_pipeline_module()
    if not hasattr(module, "main"):
        raise SystemExit("Pipeline entrypoint not found in 00_run_analysis_pipeline.py")
    typer.run(module.main)


if __name__ == "__main__":
    main()
