from __future__ import annotations

import os
import warnings
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

from dv_agent_core import create_classifier, create_extractor
from dotenv import load_dotenv
from loguru import logger
from rich.progress import Progress, TaskID

from subrogation_cm.configs import CLASSIFICATION_CONFIG, EXTRACTION_CONFIG
from subrogation_cm.models import (
    ClassificationPassResult,
    ClassificationRecord,
    ExtractionRecord,
    FirstPassEvidenceMetadata,
    ProcessResult,
    RollingClassificationRaw,
    SecondPassExecutionResult,
    SecondPassMappingRow,
    SecondPassMetadata,
)
from subrogation_cm.pipeline_support import (
    PipelineEntry,
    build_agent_kwargs,
    build_value_map,
    prepare_entries,
    resolve_rolling_params,
)
from subrogation_cm.rolling import (
    aggregate_possible_types,
    build_windows,
    classify_document_rolling,
    extract_document_rolling,
)
from subrogation_cm.utils import (
    advance_progress,
    build_second_pass_catalog,
    build_second_pass_focus,
    build_second_pass_instruction,
    build_priority_context,
    collect_documents,
    document_to_base64_images,
    ensure_priority_context,
    extract_override_keywords,
    extract_type_names,
    filter_types_by_priority,
    inline_priority_hint,
    load_priority_map,
    normalize_doc_type,
    prepare_second_pass_mapping,
    write_json,
)


SECOND_PASS_REQUEST_CONTEXT_TYPES = {
    "compromise_request_received",
    "expedited_request_received",
    "interim_lien",
}


def _select_window_flip_candidate(
    *,
    window_results: Sequence[Dict[str, Any]],
    candidate_correct_types: Sequence[str],
    min_confidence: float,
) -> tuple[str | None, float | None]:
    """Pick a mapped flip label when any rolling window clears the threshold."""
    best_type: str | None = None
    best_confidence: float | None = None

    for index, window_result in enumerate(window_results):
        if not isinstance(window_result, dict):
            continue
        raw_window_type = window_result.get("type")
        if raw_window_type in (None, ""):
            continue
        window_type = normalize_doc_type(str(raw_window_type))
        if not window_type or window_type not in candidate_correct_types:
            continue

        confidence = window_result.get("confidence")
        if not isinstance(confidence, (int, float)):
            continue
        confidence_value = float(confidence)
        if confidence_value < min_confidence:
            continue

        if (
            best_confidence is None
            or confidence_value > best_confidence
            or (confidence_value == best_confidence and best_type is not None)
        ):
            best_type = window_type
            best_confidence = confidence_value

        if confidence_value >= min_confidence and index == 0:
            # Preserve the first decisive flip hit when confidence ties later.
            continue

    return best_type, best_confidence


def _build_second_pass_verbatim_confirmation_instruction(
    *,
    first_pass_type: str,
    candidate_correct_type: str,
    verbatim_phrases: Sequence[str],
) -> str:
    """Build the yes/no confirmation prompt for a proposed second-pass flip."""
    phrase_block = (
        "\n".join(
            f"- {str(item).strip()}" for item in verbatim_phrases if str(item).strip()
        )
        or "- (no verbatim phrases provided)"
    )
    normalized_candidate_type = normalize_doc_type(candidate_correct_type)
    candidate_specific_rule = ""
    if normalized_candidate_type == "final_lien_request_received":
        candidate_specific_rule = (
            "Special rule for final_lien_request_received: count a match when the "
            "document clearly refers to final lien information for the case, "
            "including on authorization or disclosure forms that identify final lien "
            "as information to be released. "
            "Use the surrounding sentence meaning and nearby action verbs to judge "
            "whether the phrase is functioning as final-lien content for the case. "
            "Treat minor "
            "OCR or scanning near-misses as valid matches when the request context is "
            "clear, for example if 'final line' is used in a sentence that clearly "
            "means 'final lien'.\n"
        )
    elif normalized_candidate_type == "interim_lien":
        candidate_specific_rule = (
            "Special rule for interim_lien: count a match only when the document is "
            "actually requesting, asking for, or checking lien/ledger information. "
            "Do not count authorization or disclosure forms that merely mention lien, "
            "itemized statements, or related records as the information to be released.\n"
        )
    elif normalized_candidate_type == "expedited_request_received":
        candidate_specific_rule = (
            "Special rule for expedited_request_received: count a match only when the "
            "document is actually requesting expedited handling, following up on an "
            "unanswered request, requesting an expedited non-member letter, or "
            "showing repeated failed-submission context such as attempted fax "
            "delivery several times, statements that the number provided did not "
            "work, or multiple unsuccessful attempts to send the same documents. Do "
            "not count resend-only or reference-only mentions that do not ask for "
            "action. Do not treat 'outstanding liens', 'outstanding balances', "
            "'outstanding medical bills', or settlement-statement escrow language "
            "about resolving liens as the same thing as an outstanding request. "
            "Those are lien/balance references, not follow-up request cues.\n"
        )
    elif normalized_candidate_type == "compromise_request_received":
        candidate_specific_rule = (
            "Special rule for compromise_request_received: count a match only when the "
            "document is actually requesting a lien reduction, waiver, compromise, or "
            "reduced payoff. Do not count references to compromise history, settlement, "
            "or prior decisions unless the document is asking for compromise action.\n"
        )
    request_context_instruction = ""
    if normalized_candidate_type in SECOND_PASS_REQUEST_CONTEXT_TYPES:
        request_context_instruction = (
            "Also return `is_request_context=true` only when the matched cue is being "
            "used in an actual request-for-action context. Return "
            "`is_request_context=false` when the phrase appears only inside an "
            "authorization, disclosure form, reference list, or other non-request "
            "context.\n"
        )
    return (
        "You are validating a proposed second-pass classification flip.\n\n"
        f"Current keep label: {first_pass_type}\n"
        f"Proposed flip label: {candidate_correct_type}\n\n"
        "Review the visible document text/pages and decide whether any listed "
        "verbatim cue for the proposed flip label is present verbatim or clearly "
        "matches the same meaning.\n"
        "Return `sees_verbatim=true` only when at least one listed phrase or its "
        "clear semantic equivalent is present in the document. Otherwise return "
        "`sees_verbatim=false`.\n"
        "Use surrounding sentence meaning and nearby request/action language, not "
        "exact phrase matching alone.\n"
        "Treat minor OCR or scanning errors as matches when the context clearly "
        "indicates the same intended meaning.\n"
        "If true, also return the matched phrase from the allowed verbatim list in "
        "`matched_verbatim`.\n"
        "If true, also return `matched_page_number` as the 1-based page number where "
        "the cue appears in the currently visible page set. When only a chunk/window "
        "of pages is visible, count pages within that chunk only.\n"
        "If false, leave `matched_verbatim` blank.\n"
        "If false, leave `matched_page_number` blank.\n"
        f"{request_context_instruction}"
        "Do not infer from general similarity or topic overlap.\n"
        f"{candidate_specific_rule}"
        "Call the `confirm_verbatim_match` tool once before returning.\n\n"
        "Allowed verbatim cues for the proposed flip label:\n"
        f"{phrase_block}"
    )


def _build_first_pass_evidence_instruction(
    *, predicted_type: str, classification_reasoning: str | None
) -> str:
    """Build an instruction that extracts structured first-pass supporting evidence."""
    reasoning_block = (
        f"Classifier reasoning to audit:\n{classification_reasoning.strip()}\n\n"
        if isinstance(classification_reasoning, str)
        and classification_reasoning.strip()
        else ""
    )
    return (
        "You are auditing the first-pass classification reasoning.\n\n"
        f"Chosen label: {predicted_type}\n\n"
        f"{reasoning_block}"
        "Review the visible document text/pages and identify one decisive supporting cue "
        "for the chosen label.\n"
        "Return `supporting_text` as an exact visible text fragment from the page you "
        "are relying on. Do not paraphrase it.\n"
        "Return `matched_verbatim` only when the decisive cue itself appears exactly in "
        "the document text. Otherwise leave `matched_verbatim` blank.\n"
        "Return `matched_page_number` as the 1-based page number where the supporting "
        "text appears in the currently visible page set. When only a chunk/window of "
        "pages is visible, count pages within that chunk only.\n"
        "Return `match_mode` as `exact` when `matched_verbatim` is truly visible as "
        "written, otherwise return `semantic` when the support is an in-document phrase "
        "with equivalent meaning.\n"
        "When `match_mode=semantic`, return a short `semantic_match_explanation` that "
        "explains why the exact visible supporting text supports the label. When "
        "`match_mode=exact`, leave `semantic_match_explanation` blank.\n"
        "Do not invent quoted text that is not visible in the document.\n"
    )


def _build_second_pass_verbatim_scan_instruction(
    *,
    first_pass_type: str,
    candidate_correct_type: str,
    verbatim_phrases: Sequence[str],
) -> str:
    """Build a lightweight prompt that only checks for verbatim/semantic matches."""
    phrase_block = (
        "\n".join(
            f"- {str(item).strip()}" for item in verbatim_phrases if str(item).strip()
        )
        or "- (no verbatim phrases provided)"
    )
    normalized_candidate_type = normalize_doc_type(candidate_correct_type)
    candidate_specific_rule = ""
    if normalized_candidate_type == "expedited_request_received":
        candidate_specific_rule = (
            "Special rule for expedited_request_received: treat phrases like "
            "'outstanding request' as follow-up/request-status language only when "
            "the document is referring to a prior unanswered request, repeated "
            "submission, or a request for prompt action. Do not treat 'outstanding "
            "liens', 'outstanding balances', 'outstanding medical bills', or "
            "settlement-statement escrow language about resolving liens as the same "
            "thing as an outstanding request. Those are lien/balance references, not "
            "follow-up request cues.\n"
        )
    return (
        "You are doing a lightweight verbatim pre-check for a proposed second-pass "
        "classification flip.\n\n"
        f"Current keep label: {first_pass_type}\n"
        f"Proposed flip label: {candidate_correct_type}\n\n"
        "Review the visible document text/pages and decide whether any listed "
        "verbatim cue for the proposed flip label is present verbatim or clearly "
        "matches the same meaning.\n"
        "Return `sees_verbatim=true` only when at least one listed phrase or its "
        "clear semantic equivalent is present in the document. Otherwise return "
        "`sees_verbatim=false`.\n"
        "Use surrounding sentence meaning and nearby request/action language, not "
        "exact phrase matching alone.\n"
        "Treat minor OCR or scanning errors as matches when the context clearly "
        "indicates the same intended meaning.\n"
        "For example, if a document appears to say 'final line' in a sentence that "
        "clearly requests the final lien for the case, that should count as a "
        "semantic match to a final-lien cue.\n"
        "If true, return the matched phrase from the allowed verbatim list in "
        "`matched_verbatim`.\n"
        "If true, also return `matched_page_number` as the 1-based page number where "
        "the cue appears in the currently visible page set. When only a chunk/window "
        "of pages is visible, count pages within that chunk only.\n"
        "If false, leave `matched_verbatim` blank.\n"
        "If false, leave `matched_page_number` blank.\n"
        "Do not decide request context in this step. Only decide whether the cue is "
        "present.\n"
        f"{candidate_specific_rule}"
        "Call the `confirm_verbatim_match` tool once before returning.\n\n"
        "Allowed verbatim cues for the proposed flip label:\n"
        f"{phrase_block}"
    )


def _normalize_matched_page_number(raw_value: Any) -> int | None:
    """Normalize a model-reported matched page number into a positive integer."""
    if isinstance(raw_value, bool) or raw_value is None:
        return None
    if isinstance(raw_value, int):
        return raw_value if raw_value > 0 else None
    if isinstance(raw_value, float):
        if raw_value.is_integer() and raw_value > 0:
            return int(raw_value)
        return None
    if isinstance(raw_value, str):
        stripped = raw_value.strip()
        if not stripped:
            return None
        try:
            parsed = float(stripped)
        except ValueError:
            return None
        if parsed.is_integer() and parsed > 0:
            return int(parsed)
    return None


def _normalize_match_mode(raw_value: Any) -> str | None:
    """Normalize exact-vs-semantic evidence labels."""
    if not isinstance(raw_value, str):
        return None
    normalized = raw_value.strip().lower()
    if normalized in {"exact", "semantic"}:
        return normalized
    return None


def _normalize_optional_text(raw_value: Any) -> str | None:
    """Normalize an optional text field to a stripped string or None."""
    if raw_value is None:
        return None
    text = str(raw_value).strip()
    return text or None


def _build_second_pass_request_context_instruction(
    *,
    first_pass_type: str,
    candidate_correct_type: str,
    matched_verbatim: str,
) -> str:
    """Build a focused prompt that checks whether a matched cue is a request."""
    normalized_candidate_type = normalize_doc_type(candidate_correct_type)
    candidate_specific_rule = ""
    if normalized_candidate_type == "final_lien_request_received":
        candidate_specific_rule = (
            "This counts as request context when the document is using the matched "
            "final-lien cue in a case-specific action context, including "
            "authorization or disclosure forms that identify final lien information "
            "to be released.\n"
        )
    elif normalized_candidate_type == "interim_lien":
        candidate_specific_rule = (
            "This counts as request context only when the document is actually "
            "requesting, asking for, or checking lien/ledger information. Do not "
            "count authorization or disclosure forms that merely mention lien, "
            "itemized statements, or related records as the information to be released.\n"
        )
    elif normalized_candidate_type == "expedited_request_received":
        candidate_specific_rule = (
            "This counts as request context only when the document is actually "
            "requesting expedited handling, following up on an unanswered request, or "
            "requesting an expedited non-member letter. Repeated failed-submission "
            "context such as attempted fax delivery several times, statements that "
            "the number provided did not work, or multiple unsuccessful attempts to "
            "send the same documents should count when the packet is asking for "
            "action, status, or prompt handling. Do not count resend-only or "
            "reference-only mentions that do not ask for action. Do not treat "
            "'outstanding liens', 'outstanding balances', 'outstanding medical "
            "bills', or settlement statement escrow language about unresolved liens "
            "as the same thing as a follow-up request.\n"
        )
    elif normalized_candidate_type == "compromise_request_received":
        candidate_specific_rule = (
            "This counts as request context only when the document is actually "
            "requesting a lien reduction, waiver, compromise, or reduced payoff. Do "
            "not count references to compromise history, settlement, or prior "
            "decisions unless the document is asking for compromise action.\n"
        )
    return (
        "You are validating request context for a matched second-pass cue.\n\n"
        f"Current keep label: {first_pass_type}\n"
        f"Proposed flip label: {candidate_correct_type}\n"
        f"Matched cue: {matched_verbatim}\n\n"
        "The matched cue is already known to be present in the document. Decide only "
        "whether it is being used in an actual request-for-action context.\n"
        "Return `is_request_context=true` only when the matched cue appears in a real "
        "request, follow-up request, status request, or request for action.\n"
        "Return `is_request_context=false` when the matched cue appears only in an "
        "authorization, disclosure form, reference list, attachment description, or "
        "other non-request context.\n"
        f"{candidate_specific_rule}"
        "Call the `confirm_verbatim_match` tool once before returning."
    )


def _get_type_priority_rank(
    *,
    doc_type: str,
    priority_types: Sequence[str],
) -> int:
    """Return the configured priority rank for a normalized document type."""
    normalized_type = normalize_doc_type(doc_type)
    for index, priority_type in enumerate(priority_types):
        if normalize_doc_type(priority_type) == normalized_type:
            return index
    return len(priority_types)


class SubroPipeline:
    """
    Encapsulates classification and extraction flows for lien documents.
    """

    def __init__(
        self,
        *,
        classification_config: Dict | None = None,
        extraction_config: Dict | None = None,
    ) -> None:
        load_dotenv()

        classification = dict(classification_config or CLASSIFICATION_CONFIG)
        extraction = dict(extraction_config or EXTRACTION_CONFIG)

        classification_model = os.getenv("SUBRO_CLASSIFICATION_MODEL") or os.getenv(
            "SUBRO_MODEL"
        )
        if classification_model:
            classification["model"] = classification_model

        extraction_model = os.getenv("SUBRO_EXTRACTION_MODEL") or os.getenv(
            "SUBRO_MODEL"
        )
        if extraction_model:
            extraction["model"] = extraction_model

        self.classification_config = classification
        self.extraction_config = extraction

    def _resolve_priority_context(
        self, context: Dict[str, Any] | None
    ) -> Dict[str, Any]:
        resolved_context: Dict[str, Any] = dict(context) if context else {}

        raw_no_contexts = self.classification_config.get("priority_no_contexts") or []
        if isinstance(raw_no_contexts, (str, bytes)):
            normalized_no_context = str(raw_no_contexts).strip()
            priority_no_contexts = (
                {normalized_no_context} if normalized_no_context else set()
            )
        elif isinstance(raw_no_contexts, Iterable):
            priority_no_contexts = {
                str(item).strip() for item in raw_no_contexts if str(item).strip()
            }
        else:
            priority_no_contexts = set()

        raw_priority_hint = resolved_context.get("priority_hint")
        priority_hint = (
            str(raw_priority_hint).strip() if raw_priority_hint is not None else ""
        )
        has_priority_hint = bool(
            priority_hint
            and not priority_hint.lower().startswith("no priority list provided")
        )

        raw_priority_context = resolved_context.get("priority_context")
        priority_context_override = None
        if isinstance(raw_priority_context, str):
            normalized_priority_context = raw_priority_context.strip()
            if (
                normalized_priority_context
                and normalized_priority_context.lower()
                not in {
                    "n/a",
                    "na",
                    "none",
                    "null",
                }
            ):
                priority_context_override = normalized_priority_context
        elif raw_priority_context is not None:
            priority_context_override = raw_priority_context

        # New default workflow: when configured, always use the in-config
        # default context doc-type ordering instead of workbook/state priority lists.
        raw_default_priority_types = self.classification_config.get(
            "default_context_doc_types"
        )
        if isinstance(raw_default_priority_types, Iterable) and not isinstance(
            raw_default_priority_types, (str, bytes)
        ):
            default_priority_types = [
                str(item).strip()
                for item in raw_default_priority_types
                if str(item).strip()
            ]
            if default_priority_types:
                priority_context = (
                    priority_context_override
                    or self.classification_config.get("priority_context")
                    or os.getenv("SUBRO_PRIORITY_CONTEXT")
                    or "DEFAULT"
                )
                if isinstance(priority_context, str):
                    type_names = [
                        str(t.get("name"))
                        for t in self.classification_config.get("types", [])
                        if t.get("name")
                    ]
                    priority_ctx = build_priority_context(
                        priority_map={priority_context: default_priority_types},
                        context=priority_context,
                        type_names=type_names,
                        no_priority_contexts=priority_no_contexts,
                    )
                    resolved_context.update(priority_ctx)
                    return ensure_priority_context(resolved_context)

        if not has_priority_hint:
            priority_context = (
                priority_context_override
                or self.classification_config.get("priority_context")
                or os.getenv("SUBRO_PRIORITY_CONTEXT")
            )

            priority_map = None
            config_priority_list = self.classification_config.get("priority_list")
            if config_priority_list and isinstance(config_priority_list, dict):
                priority_map = config_priority_list

            if priority_map is None:
                priority_list_path = (
                    resolved_context.get("priority_list_path")
                    or self.classification_config.get("priority_list_path")
                    or os.getenv("SUBRO_PRIORITY_LIST_PATH")
                )
                if priority_list_path and isinstance(priority_list_path, (str, Path)):
                    try:
                        priority_map = load_priority_map(Path(priority_list_path))
                    except Exception as exc:
                        logger.warning("Failed to load priority list: {}", exc)

            if priority_map:
                if not priority_context and len(priority_map) == 1:
                    priority_context = next(iter(priority_map.keys()))
                if priority_context and isinstance(priority_context, str):
                    type_names = [
                        str(t.get("name"))
                        for t in self.classification_config.get("types", [])
                        if t.get("name")
                    ]
                    priority_ctx = build_priority_context(
                        priority_map=priority_map,
                        context=priority_context,
                        type_names=type_names,
                        no_priority_contexts=priority_no_contexts,
                    )
                    resolved_context.update(priority_ctx)

        return ensure_priority_context(resolved_context)

    def _resolve_second_pass_settings(
        self,
        *,
        active_config: Dict[str, Any],
        second_pass_enabled: bool | None,
        second_pass_mapping: Sequence[Dict[str, Any] | SecondPassMappingRow] | None,
    ) -> tuple[bool, Dict[str, List[SecondPassMappingRow]]]:
        """
        Resolve second-pass settings from method kwargs and classification config.
        """
        config_block = active_config.get("classification_second_pass")
        config_enabled = False
        config_mapping: Any = None
        if isinstance(config_block, dict):
            config_enabled = bool(config_block.get("enabled", False))
            config_mapping = config_block.get("mapping")

        resolved_enabled = (
            config_enabled if second_pass_enabled is None else second_pass_enabled
        )
        raw_mapping = (
            config_mapping if second_pass_mapping is None else second_pass_mapping
        )
        allowed_types = extract_type_names(active_config) | extract_type_names(
            self.classification_config
        )
        mapping_by_predicted = prepare_second_pass_mapping(
            raw_mapping,
            allowed_types=allowed_types,
        )
        if resolved_enabled and not mapping_by_predicted:
            raise ValueError(
                "Second-pass classification is enabled but mapping is missing or empty."
            )
        return resolved_enabled, mapping_by_predicted

    async def _classify_entry(
        self,
        *,
        entry: PipelineEntry,
        classifier: Any,
        context: Dict[str, Any] | None,
        use_rolling: bool,
        resolved_window_size: int,
        resolved_overlap: int,
    ) -> ClassificationPassResult:
        """Classify one entry and normalize the output payload."""
        entry_label = entry.name
        entry_images = entry.base64_images or []
        if use_rolling:
            window_count = len(
                build_windows(
                    entry_images,
                    window_size=resolved_window_size,
                    overlap=resolved_overlap,
                )
            )
            logger.debug(
                "First pass rolling start for {}: pages/images={}, windows={}, window_size={}, overlap={}",
                entry_label,
                len(entry_images),
                window_count,
                resolved_window_size,
                resolved_overlap,
            )
            rolling_result = await classify_document_rolling(
                document_path=entry.path,
                base64_images=entry.base64_images,
                context=context,
                window_size=resolved_window_size,
                overlap=resolved_overlap,
                classifier=classifier,
            )
            possible_types = (
                rolling_result.possible_types if rolling_result.possible_types else None
            )
            return ClassificationPassResult(
                type=rolling_result.type,
                confidence=rolling_result.confidence,
                reasoning=rolling_result.reasoning,
                possible_types=possible_types,
                raw=RollingClassificationRaw(
                    rolling=True,
                    window_size=resolved_window_size,
                    overlap=resolved_overlap,
                    window_results=rolling_result.window_results,
                ).model_dump(),
            )

        classify_kwargs = build_agent_kwargs(entry=entry, context=context)
        result = await classifier.classify(**classify_kwargs)
        logger.debug("First pass single-shot complete for {}", entry_label)
        payload = result.model_dump() if hasattr(result, "model_dump") else {}
        top = payload.get("documents", [{}])[0] if payload else {}
        normalized_type = None
        if top.get("type"):
            candidate_type = normalize_doc_type(str(top.get("type")))
            normalized_type = candidate_type or None

        normalized_possible_types = aggregate_possible_types(
            [top.get("possible_types") or []]
        )
        return ClassificationPassResult(
            type=normalized_type,
            confidence=top.get("confidence"),
            reasoning=top.get("reasoning"),
            possible_types=(
                normalized_possible_types if normalized_possible_types else None
            ),
            raw=payload if isinstance(payload, dict) else {},
        )

    async def _extract_entry(
        self,
        *,
        entry: PipelineEntry,
        extractor: Any,
        context: Dict[str, Any] | None,
        use_rolling: bool,
        resolved_window_size: int,
        resolved_overlap: int,
    ) -> Dict[str, Any]:
        """Extract a structured payload for one entry."""
        if use_rolling:
            payload = await extract_document_rolling(
                document_path=entry.path,
                base64_images=entry.base64_images,
                context=context,
                window_size=resolved_window_size,
                overlap=resolved_overlap,
                extractor=extractor,
            )
            return payload if isinstance(payload, dict) else {}

        extract_kwargs = build_agent_kwargs(entry=entry, context=context)
        result = await extractor.extract(**extract_kwargs)
        payload = result.model_dump() if hasattr(result, "model_dump") else {}
        return payload if isinstance(payload, dict) else {}

    async def _capture_first_pass_evidence(
        self,
        *,
        entry: PipelineEntry,
        predicted_type: str | None,
        classification_reasoning: str | None,
        active_config: Dict[str, Any],
        use_rolling: bool,
        resolved_window_size: int,
        resolved_overlap: int,
    ) -> FirstPassEvidenceMetadata:
        """Capture structured supporting evidence for the first-pass label."""
        if not isinstance(predicted_type, str) or not predicted_type.strip():
            return FirstPassEvidenceMetadata()

        evidence_extractor = create_extractor(
            {
                "model": active_config.get("model"),
                "max_images": None,
                "instruction_template": _build_first_pass_evidence_instruction(
                    predicted_type=predicted_type,
                    classification_reasoning=classification_reasoning,
                ),
                "fields": [
                    {
                        "name": "supporting_text",
                        "type": "string",
                        "description": (
                            "Exact visible supporting text fragment from the cited page."
                        ),
                    },
                    {
                        "name": "matched_verbatim",
                        "type": "string",
                        "description": (
                            "Exact visible cue only when the decisive phrase appears "
                            "verbatim in the document."
                        ),
                    },
                    {
                        "name": "matched_page_number",
                        "type": "float",
                        "description": (
                            "1-based page number where the supporting text appears "
                            "within the currently visible page set."
                        ),
                    },
                    {
                        "name": "match_mode",
                        "type": "string",
                        "description": (
                            "Use `exact` for literal visible cue text, otherwise "
                            "`semantic` for an equivalent in-document phrase."
                        ),
                    },
                    {
                        "name": "semantic_match_explanation",
                        "type": "string",
                        "description": (
                            "Short explanation for why the visible supporting text is "
                            "a semantic match. Leave blank for exact matches."
                        ),
                    },
                ],
            }
        )

        def _metadata_from_payload(
            payload: Dict[str, Any],
            *,
            page_offset: int = 0,
            page_limit: int | None = None,
        ) -> FirstPassEvidenceMetadata:
            supporting_text = _normalize_optional_text(payload.get("supporting_text"))
            matched_verbatim = _normalize_optional_text(payload.get("matched_verbatim"))
            matched_page_number = _normalize_matched_page_number(
                payload.get("matched_page_number")
            )
            match_mode = _normalize_match_mode(payload.get("match_mode"))
            semantic_match_explanation = _normalize_optional_text(
                payload.get("semantic_match_explanation")
            )

            absolute_page_number = None
            if matched_page_number is not None:
                if page_limit is None or matched_page_number <= page_limit:
                    absolute_page_number = page_offset + matched_page_number

            if supporting_text is None and matched_verbatim is not None:
                supporting_text = matched_verbatim

            if supporting_text is None and match_mode is None:
                return FirstPassEvidenceMetadata()

            return FirstPassEvidenceMetadata(
                first_pass_supporting_text=supporting_text,
                first_pass_matched_verbatim=matched_verbatim,
                first_pass_matched_page_number=absolute_page_number,
                first_pass_match_mode=match_mode,
                first_pass_semantic_match_explanation=semantic_match_explanation,
            )

        if use_rolling:
            entry_images = entry.base64_images or []
            windows = build_windows(
                entry_images,
                window_size=resolved_window_size,
                overlap=resolved_overlap,
            )
            window_stride = max(1, resolved_window_size - resolved_overlap)
            best_semantic: FirstPassEvidenceMetadata | None = None
            for window_index, window in enumerate(windows):
                result = await evidence_extractor.extract(
                    base64_images=list(window),
                    context=None,
                )
                payload = (
                    result.model_dump()
                    if hasattr(result, "model_dump")
                    else dict(result)
                )
                metadata = _metadata_from_payload(
                    payload,
                    page_offset=window_index * window_stride,
                    page_limit=len(window),
                )
                if metadata.first_pass_match_mode == "exact":
                    return metadata
                if (
                    metadata.first_pass_match_mode == "semantic"
                    and best_semantic is None
                ):
                    best_semantic = metadata
            return best_semantic or FirstPassEvidenceMetadata()

        payload = await self._extract_entry(
            entry=entry,
            extractor=evidence_extractor,
            context=None,
            use_rolling=False,
            resolved_window_size=resolved_window_size,
            resolved_overlap=resolved_overlap,
        )
        return _metadata_from_payload(payload)

    async def _run_second_pass(
        self,
        *,
        entry: PipelineEntry,
        first_pass: ClassificationPassResult,
        active_config: Dict[str, Any],
        second_pass_enabled: bool,
        second_pass_mapping_by_predicted: Dict[str, List[SecondPassMappingRow]],
        use_rolling: bool,
        resolved_window_size: int,
        resolved_overlap: int,
    ) -> SecondPassExecutionResult:
        """Run mapping-guided second-pass classification for one entry."""
        entry_label = entry.name
        final_result = first_pass.model_copy(deep=True)
        first_type = first_pass.type

        metadata = SecondPassMetadata(
            second_pass_enabled=second_pass_enabled,
            second_pass_first_type=(
                first_type if isinstance(first_type, str) else None
            ),
        )

        if not second_pass_enabled:
            return SecondPassExecutionResult(
                final_result=final_result, metadata=metadata
            )

        second_pass_block = active_config.get("classification_second_pass")
        trigger_from_possible_types = True
        trigger_min_confidence = 0.0
        window_flip_min_confidence = 0.0
        verbatim_confirmation_enabled = True
        verbatim_max_candidates: int | None = None
        allowed_non_priority_routes: set[tuple[str, str]] = set()
        second_pass_instruction_mode = "inherit_first_pass"
        second_pass_catalog_mode = "full"
        second_pass_base_instruction = active_config.get("instruction_template")
        if isinstance(second_pass_block, dict):
            trigger_from_possible_types = bool(
                second_pass_block.get("trigger_from_possible_types", True)
            )
            raw_min_conf = second_pass_block.get(
                "trigger_possible_types_min_confidence", 0.0
            )
            if isinstance(raw_min_conf, (int, float)):
                trigger_min_confidence = float(raw_min_conf)
            raw_window_flip_min_conf = second_pass_block.get(
                "window_flip_min_confidence", 0.0
            )
            if isinstance(raw_window_flip_min_conf, (int, float)):
                window_flip_min_confidence = float(raw_window_flip_min_conf)
            verbatim_confirmation_enabled = bool(
                second_pass_block.get("verbatim_confirmation_enabled", True)
            )
            raw_verbatim_max_candidates = second_pass_block.get(
                "verbatim_max_candidates"
            )
            if isinstance(raw_verbatim_max_candidates, int):
                if raw_verbatim_max_candidates > 0:
                    verbatim_max_candidates = raw_verbatim_max_candidates
            elif isinstance(raw_verbatim_max_candidates, float):
                if (
                    raw_verbatim_max_candidates.is_integer()
                    and raw_verbatim_max_candidates > 0
                ):
                    verbatim_max_candidates = int(raw_verbatim_max_candidates)
            raw_allowed_non_priority_routes = second_pass_block.get(
                "allowed_non_priority_routes"
            )
            if isinstance(raw_allowed_non_priority_routes, Sequence) and not isinstance(
                raw_allowed_non_priority_routes, (str, bytes)
            ):
                for route in raw_allowed_non_priority_routes:
                    if not isinstance(route, dict):
                        continue
                    predicted_type = normalize_doc_type(
                        str(route.get("predicted_type", ""))
                    )
                    correct_type = normalize_doc_type(
                        str(route.get("correct_type", ""))
                    )
                    if predicted_type and correct_type:
                        allowed_non_priority_routes.add((predicted_type, correct_type))
            raw_mode = second_pass_block.get("instruction_mode")
            if isinstance(raw_mode, str) and raw_mode.strip():
                second_pass_instruction_mode = raw_mode.strip().lower()
            raw_catalog_mode = second_pass_block.get("catalog_mode")
            if isinstance(raw_catalog_mode, str) and raw_catalog_mode.strip():
                second_pass_catalog_mode = raw_catalog_mode.strip().lower()
            raw_base_instruction = second_pass_block.get("base_instruction_template")
            if isinstance(raw_base_instruction, str) and raw_base_instruction.strip():
                second_pass_base_instruction = raw_base_instruction

        mapping_predicted_types: List[str] = []
        if (
            isinstance(first_type, str)
            and first_type in second_pass_mapping_by_predicted
        ):
            mapping_predicted_types.append(first_type)

        if trigger_from_possible_types and first_pass.possible_types:
            for candidate in first_pass.possible_types:
                if not isinstance(candidate, dict):
                    continue
                candidate_type = normalize_doc_type(str(candidate.get("type", "")))
                if (
                    not candidate_type
                    or candidate_type in mapping_predicted_types
                    or candidate_type not in second_pass_mapping_by_predicted
                ):
                    continue

                confidence = candidate.get("confidence")
                if isinstance(confidence, (int, float)):
                    if float(confidence) < trigger_min_confidence:
                        continue
                elif trigger_min_confidence > 0.0:
                    continue

                mapping_predicted_types.append(candidate_type)

        if not mapping_predicted_types:
            logger.debug(
                "Second pass skipped for {}: no mapping trigger types", entry_label
            )
            return SecondPassExecutionResult(
                final_result=final_result, metadata=metadata
            )

        metadata.second_pass_triggered = True
        logger.debug(
            "Second pass triggered for {} from first_pass={} and triggers={}",
            entry_label,
            first_type,
            mapping_predicted_types,
        )
        mapping_rows: List[SecondPassMappingRow] = []
        for predicted_type in mapping_predicted_types:
            mapping_rows.extend(second_pass_mapping_by_predicted[predicted_type])

        first_pass_label = (
            first_type if isinstance(first_type, str) else mapping_predicted_types[0]
        )
        entry_images = entry.base64_images or []
        candidate_correct_types, rationale_count, reclass_focus = (
            build_second_pass_focus(
                first_pass_type=first_pass_label,
                mapping_rows=mapping_rows,
            )
        )

        raw_priority_types = (
            active_config.get("default_context_doc_types")
            or self.classification_config.get("default_context_doc_types")
            or CLASSIFICATION_CONFIG.get("default_context_doc_types")
            or []
        )
        priority_types = (
            [str(item) for item in raw_priority_types if str(item).strip()]
            if isinstance(raw_priority_types, Sequence)
            and not isinstance(raw_priority_types, (str, bytes))
            else []
        )
        first_pass_rank = _get_type_priority_rank(
            doc_type=first_pass_label,
            priority_types=priority_types,
        )
        candidate_correct_types = [
            candidate_type
            for candidate_type in candidate_correct_types
            if (
                _get_type_priority_rank(
                    doc_type=candidate_type,
                    priority_types=priority_types,
                )
                < first_pass_rank
            )
            or (first_pass_label, candidate_type) in allowed_non_priority_routes
        ]
        candidate_correct_types.sort(
            key=lambda candidate_type: _get_type_priority_rank(
                doc_type=candidate_type,
                priority_types=priority_types,
            )
        )
        if not candidate_correct_types:
            logger.debug(
                "Second pass candidate list empty after priority filtering for {}",
                entry_label,
            )
            metadata.second_pass_triggered = False
            return SecondPassExecutionResult(
                final_result=final_result, metadata=metadata
            )

        rationale_count = sum(
            1
            for mapping_row in mapping_rows
            if mapping_row.correct_type in set(candidate_correct_types)
            for rationale in mapping_row.rationale
            if str(rationale).strip()
        )
        metadata.second_pass_candidate_correct_types = candidate_correct_types
        metadata.second_pass_rationale_count = rationale_count
        logger.debug(
            "Second pass candidates for {} -> {}",
            entry_label,
            candidate_correct_types,
        )

        allowed_types = [first_pass_label, *candidate_correct_types]
        allowed_set = {item for item in allowed_types if item}
        second_pass_config = filter_types_by_priority(
            active_config,
            allowed_types,
        )
        # Second pass intentionally avoids priority/context-tool inputs.
        second_pass_config = dict(second_pass_config)
        second_pass_config["tools"] = []

        base_focused_catalog: List[Dict[str, str]] = []
        for type_item in second_pass_config.get("types", []):
            if not isinstance(type_item, dict):
                continue
            type_name = normalize_doc_type(str(type_item.get("name", "")))
            if not type_name:
                continue
            description = str(type_item.get("description", "")).strip()
            description = (
                " ".join(description.split())
                if description
                else "(no description provided)"
            )
            base_focused_catalog.append({"name": type_name, "description": description})

        rationale_map: Dict[str, List[str]] = defaultdict(list)
        for mapping_row in mapping_rows:
            correct_type = str(mapping_row.correct_type).strip()
            if not correct_type:
                continue
            bucket = rationale_map[correct_type]
            for rationale in mapping_row.rationale:
                rationale_text = str(rationale).strip()
                if rationale_text and rationale_text not in bucket:
                    bucket.append(rationale_text)

        focused_type_names = list(dict.fromkeys([t for t in allowed_types if t]))
        focused_catalog = build_second_pass_catalog(
            first_pass_type=first_pass_label,
            focused_types=focused_type_names,
            focused_types_catalog=base_focused_catalog,
            rationale_map=dict(rationale_map),
            catalog_mode=second_pass_catalog_mode,
        )
        second_pass_config["types"] = focused_catalog

        second_pass_instruction = build_second_pass_instruction(
            first_pass_type=first_pass_label,
            focused_types=focused_type_names,
            focused_types_catalog=focused_catalog,
            rationale_map=dict(rationale_map),
            rationale_focus=reclass_focus,
            base_instruction_template=(
                second_pass_base_instruction
                if isinstance(second_pass_base_instruction, str)
                else None
            ),
            instruction_mode=second_pass_instruction_mode,
        )
        second_pass_config["instruction_template"] = second_pass_instruction

        async def _scan_candidate_flip(
            candidate_type: str,
        ) -> tuple[bool | None, str | None, int | None]:
            rationale_phrases = rationale_map.get(candidate_type) or []
            verbatim_phrases = extract_override_keywords(rationale_phrases)
            if not verbatim_phrases:
                return None, None, None

            confirmation_extractor = create_extractor(
                {
                    "model": active_config.get("model"),
                    "max_images": None,
                    "tools": [
                        {"function": "subrogation_cm.tools.confirm_verbatim_match"}
                    ],
                    "instruction_template": (
                        _build_second_pass_verbatim_scan_instruction(
                            first_pass_type=first_pass_label,
                            candidate_correct_type=candidate_type,
                            verbatim_phrases=verbatim_phrases,
                        )
                    ),
                    "fields": [
                        {
                            "name": "sees_verbatim",
                            "type": "bool",
                            "description": (
                                "True only when any mapped verbatim cue, or a clear "
                                "semantic match to it, is visible in the document."
                            ),
                        },
                        {
                            "name": "matched_verbatim",
                            "type": "string",
                            "description": (
                                "The listed verbatim phrase whose meaning was matched "
                                "in the document, or blank when none is visible."
                            ),
                        },
                        {
                            "name": "matched_page_number",
                            "type": "float",
                            "description": (
                                "1-based page number where the matched cue appears "
                                "within the currently visible page set."
                            ),
                        },
                        {
                            "name": "is_request_context",
                            "type": "bool",
                            "description": (
                                "Optional field ignored during verbatim pre-check."
                            ),
                        },
                    ],
                }
            )
            if use_rolling:
                windows = build_windows(
                    entry_images,
                    window_size=resolved_window_size,
                    overlap=resolved_overlap,
                )
                window_stride = max(1, resolved_window_size - resolved_overlap)
                saw_false = False
                for window_index, window in enumerate(windows):
                    result = await confirmation_extractor.extract(
                        base64_images=list(window),
                        context=None,
                    )
                    payload = (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else dict(result)
                    )
                    sees_verbatim = payload.get("sees_verbatim")
                    matched_verbatim = payload.get("matched_verbatim")
                    matched_page_number = _normalize_matched_page_number(
                        payload.get("matched_page_number")
                    )
                    if isinstance(sees_verbatim, bool):
                        matched_phrase = (
                            str(matched_verbatim).strip()
                            if matched_verbatim is not None
                            else None
                        )
                        if sees_verbatim:
                            absolute_page_number = None
                            if (
                                matched_page_number is not None
                                and matched_page_number <= len(window)
                            ):
                                absolute_page_number = (
                                    window_index * window_stride
                                ) + matched_page_number
                            return True, (matched_phrase or None), absolute_page_number
                        saw_false = True
                if saw_false:
                    return False, None, None
                return None, None, None

            payload = await self._extract_entry(
                entry=entry,
                extractor=confirmation_extractor,
                context=None,
                use_rolling=False,
                resolved_window_size=resolved_window_size,
                resolved_overlap=resolved_overlap,
            )
            sees_verbatim = payload.get("sees_verbatim")
            matched_verbatim = payload.get("matched_verbatim")
            matched_page_number = _normalize_matched_page_number(
                payload.get("matched_page_number")
            )
            if isinstance(sees_verbatim, bool):
                matched_phrase = (
                    str(matched_verbatim).strip()
                    if matched_verbatim is not None
                    else None
                )
                if sees_verbatim:
                    return True, (matched_phrase or None), matched_page_number
                return False, None, None
            return None, None, None

        async def _confirm_request_context(
            candidate_type: str,
            matched_verbatim: str,
        ) -> bool | None:
            confirmation_extractor = create_extractor(
                {
                    "model": active_config.get("model"),
                    "max_images": None,
                    "tools": [
                        {"function": "subrogation_cm.tools.confirm_verbatim_match"}
                    ],
                    "instruction_template": (
                        _build_second_pass_request_context_instruction(
                            first_pass_type=first_pass_label,
                            candidate_correct_type=candidate_type,
                            matched_verbatim=matched_verbatim,
                        )
                    ),
                    "fields": [
                        {
                            "name": "sees_verbatim",
                            "type": "bool",
                            "description": (
                                "Always true in this stage because the matched cue is "
                                "already known to be present."
                            ),
                        },
                        {
                            "name": "matched_verbatim",
                            "type": "string",
                            "description": ("Repeat the matched cue being evaluated."),
                        },
                        {
                            "name": "is_request_context",
                            "type": "bool",
                            "description": (
                                "True only when the matched cue is used in actual "
                                "request context."
                            ),
                        },
                    ],
                }
            )

            if use_rolling:
                windows = build_windows(
                    entry_images,
                    window_size=resolved_window_size,
                    overlap=resolved_overlap,
                )
                for window in windows:
                    result = await confirmation_extractor.extract(
                        base64_images=list(window),
                        context=None,
                    )
                    payload = (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else dict(result)
                    )
                    is_request_context = payload.get("is_request_context")
                    if isinstance(is_request_context, bool):
                        if is_request_context:
                            return True
                return False

            payload = await self._extract_entry(
                entry=entry,
                extractor=confirmation_extractor,
                context=None,
                use_rolling=False,
                resolved_window_size=resolved_window_size,
                resolved_overlap=resolved_overlap,
            )
            is_request_context = payload.get("is_request_context")
            if isinstance(is_request_context, bool):
                return is_request_context
            return None

        if verbatim_confirmation_enabled and candidate_correct_types:
            matched_candidates: List[tuple[str, str | None, int | None]] = []
            use_optimized_context_flow = len(candidate_correct_types) > 1
            for candidate_type in candidate_correct_types:
                metadata.second_pass_verbatim_check_type = candidate_type
                try:
                    (
                        sees_verbatim,
                        matched_verbatim,
                        matched_page_number,
                    ) = await _scan_candidate_flip(candidate_type)
                except Exception as confirmation_exc:  # pragma: no cover
                    metadata.second_pass_verbatim_seen = None
                    metadata.second_pass_verbatim_request_context = None
                    metadata.second_pass_verbatim_matched_phrase = None
                    metadata.second_pass_verbatim_page_number = None
                    metadata.second_pass_error = (
                        f"{metadata.second_pass_error}; verbatim confirmation: {confirmation_exc}"
                        if metadata.second_pass_error
                        else f"verbatim confirmation: {confirmation_exc}"
                    )
                    continue

                logger.debug(
                    "Second pass scan for {} candidate {} -> sees_verbatim={}, matched={}",
                    entry_label,
                    candidate_type,
                    sees_verbatim,
                    matched_verbatim,
                )
                metadata.second_pass_verbatim_seen = sees_verbatim
                metadata.second_pass_verbatim_request_context = None
                metadata.second_pass_verbatim_matched_phrase = matched_verbatim
                metadata.second_pass_verbatim_page_number = matched_page_number
                if sees_verbatim is not True:
                    continue

                if use_optimized_context_flow:
                    matched_candidates.append(
                        (candidate_type, matched_verbatim, matched_page_number)
                    )
                    if (
                        verbatim_max_candidates is not None
                        and len(matched_candidates) >= verbatim_max_candidates
                    ):
                        break
                    continue

                is_request_context: bool | None = None
                if (
                    normalize_doc_type(candidate_type)
                    in SECOND_PASS_REQUEST_CONTEXT_TYPES
                ):
                    try:
                        is_request_context = await _confirm_request_context(
                            candidate_type,
                            matched_verbatim or "",
                        )
                    except Exception as confirmation_exc:  # pragma: no cover
                        metadata.second_pass_verbatim_seen = True
                        metadata.second_pass_verbatim_request_context = None
                        metadata.second_pass_error = (
                            f"{metadata.second_pass_error}; request context confirmation: {confirmation_exc}"
                            if metadata.second_pass_error
                            else f"request context confirmation: {confirmation_exc}"
                        )
                        continue
                    logger.debug(
                        "Second pass request-context for {} candidate {} -> {}",
                        entry_label,
                        candidate_type,
                        is_request_context,
                    )
                    metadata.second_pass_verbatim_request_context = is_request_context
                    if is_request_context is not True:
                        continue

                forced_confidence = 1.0
                forced_reasoning = (
                    f'Matched verbatim for {candidate_type}: "{matched_verbatim}"'
                    if matched_verbatim
                    else f"Matched verbatim for {candidate_type}."
                )
                forced_possible_types = [
                    {"type": candidate_type, "confidence": forced_confidence},
                    {"type": first_pass_label, "confidence": 0.0},
                ]
                final_result = first_pass.model_copy(
                    update={
                        "type": candidate_type,
                        "confidence": forced_confidence,
                        "reasoning": forced_reasoning,
                        "possible_types": forced_possible_types,
                    }
                )
                metadata.second_pass_selected_type = candidate_type
                metadata.second_pass_selected_confidence = forced_confidence
                metadata.second_pass_selected_possible_types = forced_possible_types
                metadata.second_pass_applied = True
                return SecondPassExecutionResult(
                    final_result=final_result,
                    metadata=metadata,
                )

            if use_optimized_context_flow:
                for (
                    candidate_type,
                    matched_verbatim,
                    matched_page_number,
                ) in matched_candidates:
                    metadata.second_pass_verbatim_check_type = candidate_type
                    metadata.second_pass_verbatim_seen = True
                    metadata.second_pass_verbatim_matched_phrase = matched_verbatim
                    metadata.second_pass_verbatim_page_number = matched_page_number
                    request_context_result: bool | None = None
                    if (
                        normalize_doc_type(candidate_type)
                        in SECOND_PASS_REQUEST_CONTEXT_TYPES
                    ):
                        try:
                            request_context_result = await _confirm_request_context(
                                candidate_type,
                                matched_verbatim or "",
                            )
                        except Exception as confirmation_exc:  # pragma: no cover
                            metadata.second_pass_verbatim_request_context = None
                            metadata.second_pass_error = (
                                f"{metadata.second_pass_error}; request context confirmation: {confirmation_exc}"
                                if metadata.second_pass_error
                                else f"request context confirmation: {confirmation_exc}"
                            )
                            continue
                        metadata.second_pass_verbatim_request_context = (
                            request_context_result
                        )
                        if request_context_result is not True:
                            continue
                    else:
                        metadata.second_pass_verbatim_request_context = None

                    forced_confidence = 1.0
                    forced_reasoning = (
                        f'Matched verbatim for {candidate_type}: "{matched_verbatim}"'
                        if matched_verbatim
                        else f"Matched verbatim for {candidate_type}."
                    )
                    forced_possible_types = [
                        {"type": candidate_type, "confidence": forced_confidence},
                        {"type": first_pass_label, "confidence": 0.0},
                    ]
                    final_result = first_pass.model_copy(
                        update={
                            "type": candidate_type,
                            "confidence": forced_confidence,
                            "reasoning": forced_reasoning,
                            "possible_types": forced_possible_types,
                        }
                    )
                    metadata.second_pass_selected_type = candidate_type
                    metadata.second_pass_selected_confidence = forced_confidence
                    metadata.second_pass_selected_possible_types = forced_possible_types
                    metadata.second_pass_applied = True
                    logger.info(
                        "Second pass applied for {} -> {} via matched verbatim {}",
                        entry_label,
                        candidate_type,
                        matched_verbatim or "(none)",
                    )
                    return SecondPassExecutionResult(
                        final_result=final_result,
                        metadata=metadata,
                    )

            metadata.second_pass_selected_type = first_pass_label
            metadata.second_pass_selected_confidence = first_pass.confidence
            metadata.second_pass_selected_possible_types = first_pass.possible_types
            logger.debug(
                "Second pass kept first-pass result for {} -> {}",
                entry_label,
                first_pass_label,
            )
            return SecondPassExecutionResult(
                final_result=final_result,
                metadata=metadata,
            )

        try:
            second_classifier = create_classifier(second_pass_config)
            second_pass_result = await self._classify_entry(
                entry=entry,
                classifier=second_classifier,
                context={},
                use_rolling=use_rolling,
                resolved_window_size=resolved_window_size,
                resolved_overlap=resolved_overlap,
            )
            second_type = second_pass_result.type
            second_confidence = second_pass_result.confidence
            if window_flip_min_confidence > 0.0:
                window_results = second_pass_result.raw.get("window_results") or []
                window_flip_type, window_flip_confidence = (
                    _select_window_flip_candidate(
                        window_results=window_results,
                        candidate_correct_types=candidate_correct_types,
                        min_confidence=window_flip_min_confidence,
                    )
                )
                if window_flip_type:
                    second_type = window_flip_type
                    second_confidence = window_flip_confidence
                    second_pass_result = second_pass_result.model_copy(
                        update={
                            "type": window_flip_type,
                            "confidence": window_flip_confidence,
                        }
                    )
            metadata.second_pass_selected_type = second_type
            metadata.second_pass_selected_confidence = second_confidence
            metadata.second_pass_selected_possible_types = (
                second_pass_result.possible_types
            )

            if isinstance(second_type, str) and second_type in allowed_set:
                final_result = second_pass_result
                metadata.second_pass_applied = True
                logger.info(
                    "Second pass classifier result applied for {} -> {} ({})",
                    entry_label,
                    second_type,
                    second_confidence,
                )
        except Exception as second_pass_exc:  # pragma: no cover
            metadata.second_pass_error = str(second_pass_exc)
            logger.warning(
                "Second pass failed for {}: {}", entry_label, second_pass_exc
            )

        return SecondPassExecutionResult(final_result=final_result, metadata=metadata)

    async def classify_documents(
        self,
        documents: Sequence[Path | str],
        *,
        base64_documents: Sequence[Any] | None = None,
        context: Dict | None = None,
        rolling: bool | None = None,
        window_size: int | None = None,
        overlap: int | None = None,
        second_pass_enabled: bool | None = None,
        second_pass_mapping: (
            Sequence[Dict[str, Any] | SecondPassMappingRow] | None
        ) = None,
        progress: Progress | None = None,
        task_id: TaskID | None = None,
    ) -> List[ClassificationRecord]:
        records: List[ClassificationRecord] = []

        entries = prepare_entries(
            documents,
            base64_documents,
            image_loader=document_to_base64_images,
        )
        resolved_context = self._resolve_priority_context(context)
        config = inline_priority_hint(
            dict(self.classification_config),
            resolved_context.get("priority_hint"),
        )
        config = filter_types_by_priority(
            config,
            resolved_context.get("priority_types"),
        )
        use_rolling, resolved_window_size, resolved_overlap = resolve_rolling_params(
            section="classification",
            config=self.classification_config,
            rolling=rolling,
            window_size=window_size,
            overlap=overlap,
        )
        resolved_second_pass_enabled, second_pass_mapping_by_predicted = (
            self._resolve_second_pass_settings(
                active_config=config,
                second_pass_enabled=second_pass_enabled,
                second_pass_mapping=second_pass_mapping,
            )
        )

        classifier = create_classifier(config)
        for entry in entries:
            try:
                logger.info(
                    "Starting classification for {} ({} page/image(s))",
                    entry.name,
                    len(entry.base64_images or []),
                )
                first_pass = await self._classify_entry(
                    entry=entry,
                    classifier=classifier,
                    context=resolved_context,
                    use_rolling=use_rolling,
                    resolved_window_size=resolved_window_size,
                    resolved_overlap=resolved_overlap,
                )
                logger.info(
                    "First pass result for {} -> {} ({})",
                    entry.name,
                    first_pass.type,
                    first_pass.confidence,
                )
                try:
                    first_pass_evidence = await self._capture_first_pass_evidence(
                        entry=entry,
                        predicted_type=first_pass.type,
                        classification_reasoning=first_pass.reasoning,
                        active_config=config,
                        use_rolling=use_rolling,
                        resolved_window_size=resolved_window_size,
                        resolved_overlap=resolved_overlap,
                    )
                except Exception as evidence_exc:  # pragma: no cover
                    first_pass_evidence = FirstPassEvidenceMetadata(
                        first_pass_evidence_error=str(evidence_exc)
                    )
                if first_pass.raw is None:
                    first_pass.raw = {}
                first_pass.raw.update(first_pass_evidence.model_dump(exclude_none=True))
                second_pass_result = await self._run_second_pass(
                    entry=entry,
                    first_pass=first_pass,
                    active_config=config,
                    second_pass_enabled=resolved_second_pass_enabled,
                    second_pass_mapping_by_predicted=second_pass_mapping_by_predicted,
                    use_rolling=use_rolling,
                    resolved_window_size=resolved_window_size,
                    resolved_overlap=resolved_overlap,
                )
                final_result = second_pass_result.final_result
                second_pass_meta = second_pass_result.metadata

                merged_raw = dict(final_result.raw) if final_result.raw else {}
                merged_raw.update(second_pass_meta.model_dump(exclude_none=True))
                logger.info(
                    "Final classification for {} -> {} ({})",
                    entry.name,
                    final_result.type,
                    final_result.confidence,
                )

                records.append(
                    ClassificationRecord(
                        path=entry.name,
                        type=final_result.type,
                        confidence=final_result.confidence,
                        reasoning=final_result.reasoning,
                        possible_types=final_result.possible_types,
                        raw=merged_raw,
                    )
                )
            except Exception as exc:  # pragma: no cover - defensive guard
                logger.exception("Classification failed for {}: {}", entry.name, exc)
                records.append(ClassificationRecord(path=entry.name, error=str(exc)))

            advance_progress(progress, task_id)

        return records

    async def extract_documents(
        self,
        documents: Sequence[Path | str],
        *,
        base64_documents: Sequence[Any] | None = None,
        lien_type_by_path: Dict[str, str] | None = None,
        rolling: bool | None = None,
        window_size: int | None = None,
        overlap: int | None = None,
        progress: Progress | None = None,
        task_id: int | None = None,
    ) -> List[ExtractionRecord]:
        extractor = create_extractor(self.extraction_config)
        records: List[ExtractionRecord] = []
        use_rolling, resolved_window_size, resolved_overlap = resolve_rolling_params(
            section="extraction",
            config=self.extraction_config,
            rolling=rolling,
            window_size=window_size,
            overlap=overlap,
        )

        entries = prepare_entries(
            documents,
            base64_documents,
            image_loader=document_to_base64_images,
        )
        for entry in entries:
            lien_type = None
            if lien_type_by_path:
                lien_type = lien_type_by_path.get(entry.name)

            context = {"lien_type": lien_type} if lien_type else None

            try:
                if use_rolling:
                    payload = await extract_document_rolling(
                        document_path=entry.path,
                        base64_images=entry.base64_images,
                        context=context,
                        window_size=resolved_window_size,
                        overlap=resolved_overlap,
                        extractor=extractor,
                    )
                else:
                    extract_kwargs = build_agent_kwargs(entry=entry, context=context)
                    result = await extractor.extract(**extract_kwargs)
                    payload = (
                        result.model_dump() if hasattr(result, "model_dump") else {}
                    )
                records.append(
                    ExtractionRecord(
                        path=entry.name,
                        lien_type=lien_type,
                        data=payload,
                    )
                )
            except Exception as exc:  # pragma: no cover - defensive guard
                records.append(
                    ExtractionRecord(
                        path=entry.name,
                        lien_type=lien_type,
                        error=str(exc),
                    )
                )

            advance_progress(progress, task_id)

        return records

    async def process_documents(
        self,
        inputs: Sequence[Path | str] | None = None,
        *,
        output_dir: Path = Path("artifacts/lien_run"),
        base64_documents: Sequence[Any] | None = None,
        rolling: bool | None = None,
        window_size: int | None = None,
        overlap: int | None = None,
        second_pass_enabled: bool | None = None,
        second_pass_mapping: (
            Sequence[Dict[str, Any] | SecondPassMappingRow] | None
        ) = None,
        progress: Progress | None = None,
    ) -> ProcessResult:
        documents = collect_documents(inputs) if inputs else []
        entries = prepare_entries(
            documents,
            base64_documents,
            image_loader=document_to_base64_images,
        )
        total_docs = len(entries)
        if total_docs == 0:
            raise FileNotFoundError("No documents found for processing.")

        classification_task = extraction_task = None
        if progress:
            classification_task = progress.add_task("Classifying", total=total_docs)
            extraction_task = progress.add_task("Extracting", total=total_docs)

        classification = await self.classify_documents(
            documents,
            base64_documents=base64_documents,
            context=None,
            rolling=rolling,
            window_size=window_size,
            overlap=overlap,
            second_pass_enabled=second_pass_enabled,
            second_pass_mapping=second_pass_mapping,
            progress=progress,
            task_id=classification_task,
        )
        type_map = build_value_map(classification, value_field="type")
        extraction = await self.extract_documents(
            documents,
            base64_documents=base64_documents,
            lien_type_by_path=type_map,
            rolling=rolling,
            window_size=window_size,
            overlap=overlap,
            progress=progress,
            task_id=extraction_task,
        )

        output_dir.mkdir(parents=True, exist_ok=True)
        write_json(
            [c.model_dump(exclude_none=True) for c in classification],
            output_dir / "classification.json",
        )
        write_json(
            [e.model_dump(exclude_none=True) for e in extraction],
            output_dir / "extraction.json",
        )

        return ProcessResult(
            classification=[c.model_dump(exclude_none=True) for c in classification],
            extraction=[e.model_dump(exclude_none=True) for e in extraction],
        )


# Backward-compatibility shims (deprecated)
async def classify_documents(
    documents: Sequence[Path | str],
    *,
    config: Dict | None = None,
    base64_documents: Sequence[Any] | None = None,
    context: Dict | None = None,
    rolling: bool | None = None,
    window_size: int | None = None,
    overlap: int | None = None,
    second_pass_enabled: bool | None = None,
    second_pass_mapping: Sequence[Dict[str, Any]] | None = None,
) -> List[ClassificationRecord]:
    warnings.warn(
        "subrogation_cm.pipeline.classify_documents is deprecated and will be removed in a future release; "
        "it works as-is for now. Use subrogation_cm.entrypoints.classify_documents instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    from subrogation_cm.entrypoints import classify_documents as _classify_documents

    return await _classify_documents(
        documents,
        config=config,
        base64_documents=base64_documents,
        context=context,
        rolling=rolling,
        window_size=window_size,
        overlap=overlap,
        second_pass_enabled=second_pass_enabled,
        second_pass_mapping=second_pass_mapping,
    )


async def extract_documents(
    documents: Sequence[Path | str],
    *,
    config: Dict | None = None,
    base64_documents: Sequence[Any] | None = None,
    lien_type_by_path: Dict[str, str] | None = None,
    rolling: bool | None = None,
    window_size: int | None = None,
    overlap: int | None = None,
) -> List[ExtractionRecord]:
    warnings.warn(
        "subrogation_cm.pipeline.extract_documents is deprecated and will be removed in a future release; "
        "it works as-is for now. Use subrogation_cm.entrypoints.extract_documents instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    from subrogation_cm.entrypoints import extract_documents as _extract_documents

    return await _extract_documents(
        documents,
        config=config,
        base64_documents=base64_documents,
        lien_type_by_path=lien_type_by_path,
        rolling=rolling,
        window_size=window_size,
        overlap=overlap,
    )


async def process_documents(
    inputs: Sequence[Path | str] | None = None,
    *,
    output_dir: Path = Path("artifacts/lien_run"),
    classification_config: Dict | None = None,
    extraction_config: Dict | None = None,
    base64_documents: Sequence[Any] | None = None,
    rolling: bool | None = None,
    window_size: int | None = None,
    overlap: int | None = None,
    second_pass_enabled: bool | None = None,
    second_pass_mapping: Sequence[Dict[str, Any]] | None = None,
) -> Dict[str, List[Dict]]:
    warnings.warn(
        "subrogation_cm.pipeline.process_documents is deprecated and will be removed in a future release; "
        "it works as-is for now. Use subrogation_cm.entrypoints.process_documents instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    from subrogation_cm.entrypoints import process_documents as _process_documents

    return await _process_documents(
        inputs=inputs,
        output_dir=output_dir,
        classification_config=classification_config,
        extraction_config=extraction_config,
        base64_documents=base64_documents,
        rolling=rolling,
        window_size=window_size,
        overlap=overlap,
        second_pass_enabled=second_pass_enabled,
        second_pass_mapping=second_pass_mapping,
    )
