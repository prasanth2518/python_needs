from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Sequence

from subrogation_cm.models import ClassificationRecord, ExtractionRecord
from subrogation_cm.pipeline import SubroPipeline


async def classify_documents(
    documents: Sequence[Path | str],
    *,
    config: Dict | None = None,
    base64_documents: Sequence[Any] | None = None,
    context: Dict | None = None,
    rolling: bool | None = None,
    window_size: int | None = None,
    overlap: int | None = None,
    second_pass_enabled: bool | None = None,
    second_pass_mapping: Sequence[Dict[str, Any]] | None = None,
) -> List[ClassificationRecord]:
    pipeline = SubroPipeline(classification_config=config)
    return await pipeline.classify_documents(
        documents,
        base64_documents=base64_documents,
        context=context,
        rolling=rolling,
        window_size=window_size,
        overlap=overlap,
        second_pass_enabled=second_pass_enabled,
        second_pass_mapping=second_pass_mapping,
    )


async def extract_documents(
    documents: Sequence[Path | str],
    *,
    config: Dict | None = None,
    base64_documents: Sequence[Any] | None = None,
    lien_type_by_path: Dict[str, str] | None = None,
    rolling: bool | None = None,
    window_size: int | None = None,
    overlap: int | None = None,
) -> List[ExtractionRecord]:
    pipeline = SubroPipeline(extraction_config=config)
    return await pipeline.extract_documents(
        documents,
        base64_documents=base64_documents,
        lien_type_by_path=lien_type_by_path,
        rolling=rolling,
        window_size=window_size,
        overlap=overlap,
    )


async def process_documents(
    inputs: Sequence[Path | str] | None = None,
    *,
    output_dir: Path = Path("artifacts/lien_run"),
    classification_config: Dict | None = None,
    extraction_config: Dict | None = None,
    base64_documents: Sequence[Any] | None = None,
    rolling: bool | None = None,
    window_size: int | None = None,
    overlap: int | None = None,
    second_pass_enabled: bool | None = None,
    second_pass_mapping: Sequence[Dict[str, Any]] | None = None,
) -> Dict[str, List[Dict]]:
    pipeline = SubroPipeline(
        classification_config=classification_config,
        extraction_config=extraction_config,
    )
    result = await pipeline.process_documents(
        inputs,
        output_dir=output_dir,
        base64_documents=base64_documents,
        rolling=rolling,
        window_size=window_size,
        overlap=overlap,
        second_pass_enabled=second_pass_enabled,
        second_pass_mapping=second_pass_mapping,
    )
    return result.model_dump()
