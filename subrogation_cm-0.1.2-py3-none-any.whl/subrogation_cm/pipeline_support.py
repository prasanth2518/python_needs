from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Sequence

from subrogation_cm.models import ClassificationRecord, PipelineEntry


def build_value_map(
    classification_records: Sequence[ClassificationRecord | Mapping[str, Any]],
    *,
    value_field: str = "type",
) -> Dict[str, str]:
    """
    Build a lookup of document path -> arbitrary value from classification records.
    Defaults to the 'type' field.
    """
    mapping: Dict[str, str] = {}
    for rec in classification_records:
        doc_path: Optional[str] = None
        value: Optional[str] = None
        if isinstance(rec, ClassificationRecord):
            doc_path = rec.path
            value = getattr(rec, value_field, None)
        else:
            doc_path = rec.get("path")
            raw_value = rec.get(value_field)
            value = str(raw_value) if raw_value is not None else None
        if doc_path and value:
            mapping[doc_path] = value
    return mapping


def prepare_entries(
    documents: Optional[Sequence[Path | str]] = None,
    base64_documents: Optional[Sequence[Any]] = None,
    *,
    image_loader: Callable[[Path], Sequence[str]],
) -> list[PipelineEntry]:
    """
    Normalize mixed inputs into entries with either a filesystem path or base64 images.

    base64_documents can be one of:
    - list[str]: list of base64 images
    - tuple(name, list[str])
    - dict with keys: name (optional), images/base64_images/data
    """
    entries: list[PipelineEntry] = []

    if documents:
        for doc in documents:
            path_obj = Path(doc)
            if path_obj.suffix.lower() in {".tif", ".tiff"}:
                entries.append(
                    PipelineEntry(
                        name=str(path_obj),
                        path=None,
                        base64_images=list(image_loader(path_obj)),
                    )
                )
                continue
            entries.append(
                PipelineEntry(name=str(path_obj), path=path_obj, base64_images=None)
            )

    if base64_documents:
        for idx, item in enumerate(base64_documents):
            name = f"base64_doc_{idx}"
            images: Optional[list[str]] = None

            if isinstance(item, dict):
                raw_name = item.get("name")
                name = str(raw_name) if raw_name else name
                raw_images = (
                    item.get("images") or item.get("base64_images") or item.get("data")
                )
                images = list(raw_images) if raw_images else None
            elif isinstance(item, (list, tuple)):
                if (
                    len(item) == 2
                    and isinstance(item[0], str)
                    and isinstance(item[1], (list, tuple))
                ):
                    name = item[0]
                    images = list(item[1])
                else:
                    images = list(item)

            if images:
                entries.append(
                    PipelineEntry(name=name, path=None, base64_images=images)
                )

    return entries


def build_agent_kwargs(
    *,
    entry: PipelineEntry,
    context: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build kwargs for classifier/extractor single-pass calls."""
    kwargs: Dict[str, Any] = {
        "document_path": entry.path,
        "context": context,
    }
    if entry.base64_images is not None:
        kwargs["base64_images"] = entry.base64_images
    return kwargs


def resolve_rolling_params(
    *,
    section: str,
    config: Mapping[str, Any],
    rolling: Optional[bool],
    window_size: Optional[int],
    overlap: Optional[int],
) -> tuple[bool, int, int]:
    """Resolve rolling-window settings from method args and config defaults."""
    if section not in {"classification", "extraction"}:
        raise ValueError(f"Unsupported rolling section: {section}")

    rolling_config = config.get(f"{section}_rolling")

    default_enabled = True
    default_window_size = 5
    default_overlap = 2

    if isinstance(rolling_config, dict):
        enabled_default = bool(rolling_config.get("enabled", default_enabled))
        window_default = int(rolling_config.get("window_size", default_window_size))
        overlap_default = int(rolling_config.get("overlap", default_overlap))
    else:
        enabled_default = default_enabled
        window_default = default_window_size
        overlap_default = default_overlap

    resolved_rolling = enabled_default if rolling is None else rolling
    resolved_window_size = window_default if window_size is None else window_size
    resolved_overlap = overlap_default if overlap is None else overlap

    if resolved_window_size <= 0:
        raise ValueError("window_size must be > 0")
    if resolved_overlap < 0:
        raise ValueError("overlap must be >= 0")
    if resolved_overlap >= resolved_window_size:
        raise ValueError("overlap must be < window_size")

    return bool(resolved_rolling), resolved_window_size, resolved_overlap
