from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


PRIORITY_TYPE_ALIASES = {
    "letter_or_fax_from_attorney": "letter_or_fax_to_attorney",
    "final_lien": "final_lien_request_received",
    "final_lien_received": "final_lien_request_received",
    "final_lien_request": "final_lien_request_received",
    "final_lien_request_received": "final_lien_request_received",
    "interim_lien_request_received": "interim_lien",
    "interim_lien_request": "interim_lien",
    "interim_lien_received": "interim_lien",
    "med_red_auth_valid": "medical_release_received",
    "med_red_auth_invalid": "medical_release_received",
    "medical_release_received": "medical_release_received",
}

# Ordered list: lower entries have higher priority.
DEFAULT_PRIORITY_TYPES = [
    "interim_lien",
    "final_lien_request_received",
    "trauma_code_mailer_received",
    "medical_release_received",
]


class ClassificationRecord(BaseModel):
    """Result row for a single classified document."""

    path: str
    type: Optional[str] = Field(default=None, description="Predicted lien type.")
    confidence: Optional[float] = Field(
        default=None, description="Confidence score 0.0-1.0."
    )
    reasoning: Optional[str] = Field(
        default=None, description="LLM rationale for the classification."
    )
    possible_types: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Ranked list of possible document types with confidence scores.",
    )
    raw: Optional[Dict[str, Any]] = Field(
        default=None, description="Full dv-agent-core response."
    )
    error: Optional[str] = Field(
        default=None, description="Error string if classification failed."
    )

    @property
    def is_success(self) -> bool:
        return self.error is None


class PipelineEntry(BaseModel):
    """Normalized document input for pipeline execution."""

    name: str = Field(description="Document identifier/path-like name.")
    path: Optional[Path] = Field(
        default=None, description="Filesystem path when document is path-backed."
    )
    base64_images: Optional[List[str]] = Field(
        default=None, description="Base64 page images when in-memory payload is used."
    )


class SecondPassMetadata(BaseModel):
    """Metadata emitted for mapping-guided second-pass reclassification."""

    second_pass_enabled: bool = Field(
        default=False, description="Whether second-pass logic is enabled."
    )
    second_pass_triggered: bool = Field(
        default=False, description="Whether second pass ran for this document."
    )
    second_pass_first_type: Optional[str] = Field(
        default=None, description="First-pass predicted type."
    )
    second_pass_candidate_correct_types: List[str] = Field(
        default_factory=list,
        description="Mapped candidate correct types considered in second pass.",
    )
    second_pass_rationale_count: int = Field(
        default=0, description="Count of rationale bullets used in reclass guidance."
    )
    second_pass_selected_type: Optional[str] = Field(
        default=None, description="Second-pass selected type before final gate."
    )
    second_pass_selected_confidence: Optional[float] = Field(
        default=None, description="Second-pass confidence before final gate."
    )
    second_pass_selected_possible_types: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Second-pass possible types payload before final gate.",
    )
    second_pass_verbatim_check_type: Optional[str] = Field(
        default=None,
        description="Candidate flip type sent through yes/no verbatim confirmation.",
    )
    second_pass_verbatim_seen: Optional[bool] = Field(
        default=None,
        description="Whether the yes/no verbatim confirmation approved the flip.",
    )
    second_pass_verbatim_request_context: Optional[bool] = Field(
        default=None,
        description=(
            "Whether the matched cue was judged to be in actual request context."
        ),
    )
    second_pass_verbatim_matched_phrase: Optional[str] = Field(
        default=None,
        description="Exact phrase reported by the yes/no verbatim confirmation step.",
    )
    second_pass_verbatim_page_number: Optional[int] = Field(
        default=None,
        description=(
            "1-based document page number where the matched verbatim cue was found."
        ),
    )
    second_pass_applied: bool = Field(
        default=False, description="Whether second-pass type replaced first-pass type."
    )
    second_pass_error: Optional[str] = Field(
        default=None, description="Second-pass execution error if one occurred."
    )


class FirstPassEvidenceMetadata(BaseModel):
    """Structured evidence captured for the first-pass classification."""

    first_pass_supporting_text: Optional[str] = Field(
        default=None,
        description="Exact visible supporting text fragment used to justify the label.",
    )
    first_pass_matched_verbatim: Optional[str] = Field(
        default=None,
        description="Exact visible cue quoted verbatim when one is available.",
    )
    first_pass_matched_page_number: Optional[int] = Field(
        default=None,
        description="1-based document page number where the supporting text appears.",
    )
    first_pass_match_mode: Optional[str] = Field(
        default=None,
        description="Whether the support was an exact quote or a semantic match.",
    )
    first_pass_semantic_match_explanation: Optional[str] = Field(
        default=None,
        description="Short explanation when the support is semantic rather than exact.",
    )
    first_pass_evidence_error: Optional[str] = Field(
        default=None, description="Evidence extraction error, if any."
    )


class SecondPassExecutionResult(BaseModel):
    """Outcome of second-pass processing for a single document."""

    final_result: "ClassificationPassResult" = Field(
        description="Result to use after optional second-pass logic."
    )
    metadata: SecondPassMetadata = Field(
        description="Second-pass metadata captured for the document."
    )


class RollingClassificationRaw(BaseModel):
    """Structured raw metadata for rolling-window classification calls."""

    rolling: bool = Field(default=True, description="Rolling mode marker.")
    window_size: int = Field(description="Rolling window size used.")
    overlap: int = Field(description="Rolling overlap used.")
    window_results: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Top classification result captured for each rolling window.",
    )


class ClassificationPassResult(BaseModel):
    """Normalized internal classification payload used between pass stages."""

    type: Optional[str] = Field(default=None, description="Predicted document type.")
    confidence: Optional[float] = Field(default=None, description="Confidence score.")
    reasoning: Optional[str] = Field(default=None, description="Model reasoning.")
    possible_types: Optional[List[Dict[str, Any]]] = Field(
        default=None, description="Possible types payload."
    )
    raw: Dict[str, Any] = Field(
        default_factory=dict, description="Raw payload metadata."
    )


class TypeCandidate(BaseModel):
    """Normalized candidate type + confidence payload."""

    type: str = Field(description="Normalized candidate type label.")
    confidence: Optional[float] = Field(
        default=None, description="Candidate confidence score."
    )


class PriorityRankCandidate(BaseModel):
    """Candidate record emitted by priority ranking."""

    label: str = Field(description="Normalized candidate label.")
    priority_rank: Optional[int] = Field(
        default=None, description="1-based priority rank if present."
    )
    confidence: Optional[float] = Field(
        default=None, description="Candidate confidence score."
    )


class PriorityRankResult(BaseModel):
    """Priority tool output payload."""

    label: Optional[str] = Field(default=None, description="Selected/normalized label.")
    priority_rank: Optional[int] = Field(
        default=None, description="Selected label priority rank."
    )
    priority_list: List[str] = Field(
        default_factory=list, description="Normalized priority order."
    )
    candidates: List[PriorityRankCandidate] = Field(
        default_factory=list, description="Ranked candidate list."
    )
    selected: Optional[PriorityRankCandidate] = Field(
        default=None, description="Winning candidate."
    )


class PriorityContextPayload(BaseModel):
    """Resolved priority context values injected into classification context."""

    priority_context: str = Field(
        default="N/A", description="Priority context key (e.g., CTSCASID)."
    )
    priority_list: str = Field(
        default="None", description="Formatted priority list string."
    )
    priority_hint: str = Field(
        default="No priority list provided.",
        description="Rendered hint text injected into prompt templates.",
    )
    priority_types: List[str] = Field(
        default_factory=list,
        description="Normalized type names allowed by context priority filtering.",
    )


class SecondPassMappingRow(BaseModel):
    """Validated second-pass mapping row."""

    predicted_type: str = Field(description="First-pass predicted type.")
    correct_type: str = Field(description="Mapped correct type candidate.")
    rationale: List[str] = Field(
        default_factory=list, description="Rationale bullets for remapping."
    )


class ExtractionRecord(BaseModel):
    """Result row for a single extracted document."""

    path: str
    lien_type: Optional[str] = Field(
        default=None, description="Lien type from classification (if available)."
    )
    data: Optional[Dict[str, Any]] = Field(
        default=None, description="Extracted fields payload."
    )
    error: Optional[str] = Field(
        default=None, description="Error string if extraction failed."
    )

    @property
    def is_success(self) -> bool:
        return self.error is None


class ProcessResult(BaseModel):
    """Aggregate output for a full run."""

    classification: list[Dict[str, Any]]
    extraction: list[Dict[str, Any]]
