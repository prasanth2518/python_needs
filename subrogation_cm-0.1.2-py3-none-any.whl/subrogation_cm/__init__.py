"""
Subrogation case management helpers for lien document classification and extraction.
"""

from pathlib import Path

from subrogation_cm.configs import (
    CLASSIFICATION_CONFIG,
    DEFAULT_MODEL,
    EXTRACTION_CONFIG,
    SAMPLE_DOC_ROOT,
    SUPPORTED_EXTENSIONS,
)
from subrogation_cm.models import ClassificationRecord, ExtractionRecord
from subrogation_cm.pipeline import SubroPipeline
from subrogation_cm.entrypoints import (
    classify_documents,
    extract_documents,
    process_documents,
)
from subrogation_cm.utils import (
    collect_documents,
    default_inputs,
    flatten_records,
    load_config,
    load_type_map,
    write_excel,
    write_json,
)

PACKAGE_ROOT = Path(__file__).resolve().parent
REPO_ROOT = PACKAGE_ROOT.parent.parent
SAMPLE_DOC_PATH = (REPO_ROOT / SAMPLE_DOC_ROOT).resolve()

__all__ = [
    "CLASSIFICATION_CONFIG",
    "DEFAULT_MODEL",
    "EXTRACTION_CONFIG",
    "SAMPLE_DOC_ROOT",
    "SAMPLE_DOC_PATH",
    "PACKAGE_ROOT",
    "REPO_ROOT",
    "SUPPORTED_EXTENSIONS",
    "ClassificationRecord",
    "ExtractionRecord",
    "SubroPipeline",
    "classify_documents",
    "collect_documents",
    "default_inputs",
    "extract_documents",
    "flatten_records",
    "load_type_map",
    "load_config",
    "write_excel",
    "process_documents",
    "write_json",
]
