from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, cast

import typer
from loguru import logger
from rich.console import Console
from rich.table import Table
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

from subrogation_cm.configs import CLASSIFICATION_CONFIG, EXTRACTION_CONFIG
from subrogation_cm.models import ClassificationRecord, ExtractionRecord
from subrogation_cm.pipeline import SubroPipeline
from subrogation_cm.utils import (
    collect_documents,
    default_inputs,
    load_priority_map,
    load_config,
    load_type_map,
    setup_logging,
    build_priority_context,
    ensure_priority_context,
    write_json,
    write_excel,
    flatten_records,
)

console = Console()
app = typer.Typer(
    help="Classify and extract lien documents using dv-agent-core.",
    add_completion=False,
)


class SubroCLI:
    EXTRACTION_PREVIEW_KEYS: tuple[str, ...] = (
        "client_name",
        "first_name",
        "last_name",
        "medicaid_id",
        "ma_number",
        "claim_number",
        "case_id",
        "settlement_amount",
        "requested_items",
        "ssn",
    )
    EXTRACTION_PREVIEW_FALLBACK_LIMIT: int = 5

    @staticmethod
    def _as_dict(rec):
        if hasattr(rec, "model_dump"):
            return rec.model_dump()
        return dict(rec)

    @staticmethod
    def _format_possible_types(possible_types: Any) -> str:
        """Render possible type candidates as a compact table-friendly string."""
        if not isinstance(possible_types, Sequence) or isinstance(
            possible_types, (str, bytes)
        ):
            return "-"

        formatted: list[str] = []
        for candidate in possible_types:
            if not isinstance(candidate, dict):
                continue
            doc_type = candidate.get("type")
            if not doc_type:
                continue
            confidence = candidate.get("confidence")
            if isinstance(confidence, (int, float)):
                formatted.append(f"{doc_type} ({confidence:.2f})")
            else:
                formatted.append(str(doc_type))

        return ", ".join(formatted) if formatted else "-"

    @classmethod
    def _render_classification_table(
        cls, records: Sequence[ClassificationRecord | Dict[str, Any]]
    ) -> None:
        table = Table(title="Classification Summary", show_lines=False)
        table.add_column("Document", style="cyan", overflow="fold")
        table.add_column("Type", style="green")
        table.add_column("Possible Types", style="magenta", overflow="fold")
        table.add_column("Confidence", style="yellow")
        table.add_column("Status/Reason", style="red")

        for raw in records:
            rec = cls._as_dict(raw)
            error = rec.get("error")
            doc = Path(rec.get("path", "")).name
            if error:
                table.add_row(doc, "-", "-", "-", error)
                continue
            conf = rec.get("confidence")
            conf_display = f"{conf:.2f}" if isinstance(conf, (int, float)) else "-"
            possible_types_display = cls._format_possible_types(
                rec.get("possible_types")
            )
            table.add_row(
                doc,
                rec.get("type", "-"),
                possible_types_display,
                conf_display,
                rec.get("reasoning", ""),
            )
        console.print(table)

    @classmethod
    def _render_extraction_table(
        cls, records: Sequence[ExtractionRecord | Dict[str, Any]]
    ) -> None:
        table = Table(title="Extraction Summary", show_lines=False)
        table.add_column("Document", style="cyan", overflow="fold")
        table.add_column("Lien Type", style="green")
        table.add_column("Status", style="yellow")
        table.add_column("Extracted (preview)", style="magenta", overflow="fold")

        for raw in records:
            rec = cls._as_dict(raw)
            error = rec.get("error")
            doc = Path(rec.get("path", "")).name
            lien_type = (
                rec.get("lien_type") or rec.get("data", {}).get("lien_type") or "-"
            )
            status = error or "ok"
            data_preview = ""
            data = rec.get("data") or {}
            if data:
                preview_parts = []
                seen_keys: set[str] = set()
                for key in cls.EXTRACTION_PREVIEW_KEYS:
                    val = data.get(key)
                    if val is None:
                        continue
                    if isinstance(val, list):
                        val = ", ".join(map(str, val))
                    preview_parts.append(f"{key}={val}")
                    seen_keys.add(key)

                # Fallback: if preferred keys are missing, show first few non-null fields.
                if not preview_parts:
                    for key, val in data.items():
                        if key in seen_keys or val is None:
                            continue
                        if isinstance(val, list):
                            val = ", ".join(map(str, val))
                        preview_parts.append(f"{key}={val}")
                        if len(preview_parts) >= cls.EXTRACTION_PREVIEW_FALLBACK_LIMIT:
                            break
                data_preview = "; ".join(preview_parts)
            table.add_row(doc, lien_type, status, data_preview)
        console.print(table)

    @classmethod
    def _render_extraction_details(
        cls, records: Sequence[ExtractionRecord | Dict[str, Any]]
    ) -> None:
        for raw in records:
            rec = cls._as_dict(raw)
            error = rec.get("error")
            doc = Path(rec.get("path", "")).name
            title = f"Extraction Detail - {doc}"
            table = Table(title=title, show_lines=False)
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="green", overflow="fold")
            if error:
                table.add_row("error", error)
                console.print(table)
                continue
            data = rec.get("data") or {}
            if not data:
                table.add_row("status", "No data extracted")
            else:
                for key, val in data.items():
                    if val is None:
                        continue
                    if isinstance(val, list):
                        val = ", ".join(map(str, val))
                    table.add_row(key, str(val))
            console.print(table)

    def classify(
        self,
        inputs: List[Path] = typer.Argument(
            [],
            help="Files or folders to process (defaults to sample synthetic docs).",
            metavar="PATH",
        ),
        config: Optional[Path] = typer.Option(
            None,
            "--config",
            "-c",
            help="Classification config file (.json/.yaml). Defaults to built-in config.",
            metavar="FILE",
        ),
        priority_list: Optional[Path] = typer.Option(
            None,
            "--priority-list",
            help="Optional Excel file with document type priority rules.",
            metavar="FILE",
        ),
        priority_context: Optional[str] = typer.Option(
            None,
            "--priority-context",
            help="Context key to select a priority list (e.g., CTSCASAL).",
            metavar="CONTEXT",
        ),
        output: Path = typer.Option(
            Path("artifacts/classification.json"),
            "--output",
            "-o",
            help="Where to write classification results.",
        ),
        rolling: Optional[bool] = typer.Option(
            None,
            "--rolling/--no-rolling",
            help="Enable or disable rolling-window processing.",
        ),
        window_size: Optional[int] = typer.Option(
            None,
            "--window-size",
            help="Images per rolling window.",
        ),
        overlap: Optional[int] = typer.Option(
            None,
            "--overlap",
            help="Overlap between rolling windows.",
        ),
        second_pass: Optional[bool] = typer.Option(
            None,
            "--second-pass/--no-second-pass",
            help="Enable or disable mapping-guided second-pass reclassification.",
        ),
        log_level: str = typer.Option(
            "INFO",
            "--log-level",
            help="Console log level (e.g. INFO, DEBUG).",
        ),
    ) -> None:
        """Classify lien documents."""
        setup_logging(log_level.upper())
        documents = collect_documents(default_inputs(inputs))
        logger.info("Classifying {} document(s)...", len(documents))
        cfg = load_config(config, fallback=CLASSIFICATION_CONFIG)
        pipeline = SubroPipeline(classification_config=cfg)
        context: Dict[str, str] | None = None
        if priority_list and priority_context:
            try:
                priority_map = load_priority_map(priority_list)
                type_names = [
                    t.get("name") for t in cfg.get("types", []) if t.get("name")
                ]
                context = build_priority_context(
                    priority_map=priority_map,
                    context=priority_context,
                    type_names=type_names,
                )
                logger.info("Loaded priority list for context {}", priority_context)
            except Exception as exc:
                logger.warning("Failed to load priority list: {}", exc)
        context = ensure_priority_context(context)
        progress = Progress(
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        )
        with progress:
            task_id = progress.add_task("Classifying", total=len(documents))
            results = asyncio.run(
                pipeline.classify_documents(
                    documents,
                    context=context,
                    rolling=rolling,
                    window_size=window_size,
                    overlap=overlap,
                    second_pass_enabled=second_pass,
                    progress=progress,
                    task_id=task_id,
                )
            )
        write_json([r.model_dump(exclude_none=True) for r in results], output)
        self._render_classification_table(results)
        logger.info("Saved classification results to {}", output)

    def extract(
        self,
        inputs: List[Path] = typer.Argument(
            [],
            help="Files or folders to process (defaults to sample synthetic docs).",
            metavar="PATH",
        ),
        config: Optional[Path] = typer.Option(
            None,
            "--config",
            "-c",
            help="Extraction config file (.json/.yaml). Defaults to built-in config.",
            metavar="FILE",
        ),
        classification: Optional[Path] = typer.Option(
            None,
            "--classification",
            "-C",
            help="Optional classification JSON to seed lien_type context.",
        ),
        output: Path = typer.Option(
            Path("artifacts/extraction.json"),
            "--output",
            "-o",
            help="Where to write extraction results.",
        ),
        rolling: Optional[bool] = typer.Option(
            None,
            "--rolling/--no-rolling",
            help="Enable or disable rolling-window processing.",
        ),
        window_size: Optional[int] = typer.Option(
            None,
            "--window-size",
            help="Images per rolling window.",
        ),
        overlap: Optional[int] = typer.Option(
            None,
            "--overlap",
            help="Overlap between rolling windows.",
        ),
        second_pass: Optional[bool] = typer.Option(
            None,
            "--second-pass/--no-second-pass",
            help="Enable or disable mapping-guided second-pass reclassification.",
        ),
        log_level: str = typer.Option(
            "INFO",
            "--log-level",
            help="Console log level (e.g. INFO, DEBUG).",
        ),
    ) -> None:
        """Extract structured fields from lien documents."""
        setup_logging(log_level.upper())
        documents = collect_documents(default_inputs(inputs))
        lien_type_map: Dict[str, str] | None = None
        if classification:
            lien_type_map = load_type_map(classification)
            logger.info("Loaded classification hints from {}", classification)

        logger.info("Extracting {} document(s)...", len(documents))
        cfg = load_config(config, fallback=EXTRACTION_CONFIG)
        pipeline = SubroPipeline(extraction_config=cfg)
        progress = Progress(
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        )
        with progress:
            task_id = progress.add_task("Extracting", total=len(documents))
            results = asyncio.run(
                pipeline.extract_documents(
                    documents,
                    lien_type_by_path=lien_type_map,
                    rolling=rolling,
                    window_size=window_size,
                    overlap=overlap,
                    progress=progress,
                    task_id=task_id,
                )
            )
        write_json([r.model_dump(exclude_none=True) for r in results], output)
        self._render_extraction_table(results)
        logger.info("Saved extraction results to {}", output)

    def process(
        self,
        inputs: List[Path] = typer.Argument(
            [],
            help="Files or folders to process (defaults to sample synthetic docs).",
            metavar="PATH",
        ),
        classification_config: Optional[Path] = typer.Option(
            None,
            "--classification-config",
            "-c",
            help="Classification config file (.json/.yaml). Defaults to built-in config.",
            metavar="FILE",
        ),
        extraction_config: Optional[Path] = typer.Option(
            None,
            "--extraction-config",
            "-e",
            help="Extraction config file (.json/.yaml). Defaults to built-in config.",
            metavar="FILE",
        ),
        show_details: bool = typer.Option(
            False,
            "--show-details",
            help="Render per-document extraction details in a table.",
        ),
        save_xlsx: bool = typer.Option(
            False,
            "--save-xlsx",
            help="Also write classification.xlsx and extraction.xlsx next to JSON outputs.",
        ),
        output_dir: Path = typer.Option(
            Path("artifacts/lien_run"),
            "--output-dir",
            "-o",
            help="Directory for classification.json and extraction.json outputs.",
        ),
        rolling: Optional[bool] = typer.Option(
            None,
            "--rolling/--no-rolling",
            help="Enable or disable rolling-window processing.",
        ),
        window_size: Optional[int] = typer.Option(
            None,
            "--window-size",
            help="Images per rolling window.",
        ),
        overlap: Optional[int] = typer.Option(
            None,
            "--overlap",
            help="Overlap between rolling windows.",
        ),
        second_pass: Optional[bool] = typer.Option(
            None,
            "--second-pass/--no-second-pass",
            help="Enable or disable mapping-guided second-pass reclassification.",
        ),
        log_level: str = typer.Option(
            "INFO",
            "--log-level",
            help="Console log level (e.g. INFO, DEBUG).",
        ),
    ) -> None:
        """Classify then extract in one pass."""
        setup_logging(log_level.upper())
        documents = collect_documents(default_inputs(inputs))
        logger.info("Running end-to-end on {} document(s)...", len(documents))
        cls_cfg = load_config(classification_config, fallback=CLASSIFICATION_CONFIG)
        ext_cfg = load_config(extraction_config, fallback=EXTRACTION_CONFIG)
        pipeline = SubroPipeline(
            classification_config=cls_cfg, extraction_config=ext_cfg
        )
        progress = Progress(
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        )
        with progress:
            result = asyncio.run(
                pipeline.process_documents(
                    documents,
                    output_dir=output_dir,
                    rolling=rolling,
                    window_size=window_size,
                    overlap=overlap,
                    second_pass_enabled=second_pass,
                    progress=progress,
                )
            )
        logger.info("Finished. Results saved under {}", output_dir)
        # Print summaries plus file paths
        payload: Dict[str, Any] = (
            result.model_dump()
            if hasattr(result, "model_dump")
            else cast(Dict[str, Any], result)
        )
        classification = payload.get("classification", [])
        extraction = payload.get("extraction", [])
        if classification:
            console.print("[bold green]Classification results[/bold green]")
            self._render_classification_table(classification)
        if extraction:
            console.print("[bold blue]Extraction results[/bold blue]")
            self._render_extraction_table(extraction)
            if show_details:
                self._render_extraction_details(extraction)
        console.print(
            f"[bold green]classification file:[/bold green] {output_dir / 'classification.json'}"
        )
        console.print(
            f"[bold blue]extraction file:[/bold blue]     {output_dir / 'extraction.json'}"
        )
        if save_xlsx:
            write_excel(
                classification,
                output_dir / "classification.xlsx",
                sheet_name="classification",
            )
            flattened_extraction = flatten_records(extraction, expand_keys=("data",))
            write_excel(
                flattened_extraction,
                output_dir / "extraction.xlsx",
                sheet_name="extraction",
            )
            console.print(
                f"[bold green]classification xlsx:[/bold green] {output_dir / 'classification.xlsx'}"
            )
            console.print(
                f"[bold blue]extraction xlsx:[/bold blue]     {output_dir / 'extraction.xlsx'}"
            )


cli = SubroCLI()
app.command()(cli.classify)
app.command()(cli.extract)
app.command()(cli.process)


def main(argv: Optional[List[str]] = None) -> None:
    app(prog_name="subro-cm", args=argv)


if __name__ == "__main__":  # pragma: no cover
    main()
