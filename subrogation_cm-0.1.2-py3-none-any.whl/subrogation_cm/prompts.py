from __future__ import annotations

import json
from enum import Enum

import typer
from loguru import logger
from rich.console import Console
from rich.panel import Panel


class SecondPassPromptSection(str, Enum):
    """Stable section headings for second-pass instruction templates."""

    INTRO = "You classify Medicaid lien correspondence from law firms."
    CLASSIFICATION_HINTS = "Classification hints:"
    PRIORITY_GUIDANCE = (
        "Priority guidance (if provided): second-pass priority tools are disabled."
    )
    CONFLICT_RULES = "Conflict rules:"
    FOCUSED_TYPES = "Focused types (dict-like):"
    MISCLASSIFICATION_MAPPING = "Misclassification mapping (dict-like):"
    RATIONALE_GUIDANCE = "Rationale guidance:"


class SecondPassInstructionMode(str, Enum):
    """Supported composition modes for second-pass instructions."""

    INHERIT_FIRST_PASS = "inherit_first_pass"
    STANDALONE = "standalone"


SECOND_PASS_HARD_RULE_LINES: tuple[str, ...] = (
    "- Return exactly one label from the focused types only.",
    "- TOP-PRIORITY OVERRIDE: If document text contains cues that match a candidate correct_type rationale (verbatim or close in meaning), you MUST assign that candidate correct_type.",
    "- This cue-match override takes precedence over first-pass type, focused-type preference hints, and any other config instructions.",
    "- HARD RULE: Treat rationale phrases as deterministic routing rules.",
    "- If document text includes rationale terms for a candidate correct_type, you MUST choose that correct_type.",
    "- This rule overrides first-pass type and generic type descriptions.",
    "- Keep first_pass_predicted_type only when no rationale terms match any candidate correct_type.",
    "- If multiple candidate correct_types match, choose the strongest lexical match (most distinct rationale hits; most specific phrase) and explain tie-break.",
    "- Do not rely on non-focused type heuristics.",
)


SECOND_PASS_MED_RELEASE_CONFLICT_RULES: tuple[str, ...] = (
    "- CONFLICT OVERRIDE (medical_release_received vs interim_lien): do NOT choose medical_release_received solely because signed HIPAA/authorization pages are present.",
    "- If the correspondence asks to confirm/provide/update a lien, payment ledger, itemized claims/paid amounts, or subrogation reimbursement status, you MUST choose interim_lien.",
    "- In mixed packets (cover email/letter + HIPAA attachment), prioritize request intent in the correspondence over attachment dominance.",
    "- If any overriding keyword trigger (or close lexical variant) appears in correspondence text, you MUST choose interim_lien.",
)


SECOND_PASS_INTERIM_KEYWORD_HEADER = (
    "- OVERRIDING KEYWORD TRIGGERS for interim_lien (from mapping):"
)


SECOND_PASS_PROMPT_APPEND_TEMPLATE = (
    "Second-pass override rules:\n"
    "- first_pass_predicted_type: {first_pass_type}\n"
    "- focused_types: {focused_types}\n"
    "{hard_rules}\n\n"
    f"{SecondPassPromptSection.CONFLICT_RULES.value}\n"
    "{conflict_rules}\n\n"
    f"{SecondPassPromptSection.FOCUSED_TYPES.value}\n"
    "{types_block}\n\n"
    f"{SecondPassPromptSection.MISCLASSIFICATION_MAPPING.value}\n"
    "{mapping_block}\n\n"
    f"{SecondPassPromptSection.RATIONALE_GUIDANCE.value}\n"
    "{rationale_focus}"
)


SECOND_PASS_PROMPT_TEMPLATE = (
    f"{SecondPassPromptSection.INTRO.value}\n\n"
    "{{catalog}}\n\n"
    f"{SecondPassPromptSection.CLASSIFICATION_HINTS.value}\n"
    f"{SecondPassPromptSection.PRIORITY_GUIDANCE.value}\n"
    f"{SECOND_PASS_PROMPT_APPEND_TEMPLATE}\n\n"
    "{{fallback_instruction}}"
)


def _escape_format_braces(value: str) -> str:
    """Escape braces so nested format calls are safe."""
    return value.replace("{", "{{").replace("}", "}}")


def _render_catalog_block(types: list[dict[str, str]]) -> str:
    """Render a catalog-like block for prompt preview output."""
    lines = ["Type catalog:"]
    for item in types:
        name = str(item.get("name", "")).strip()
        description = " ".join(str(item.get("description", "")).strip().split())
        lines.append(f"- {name}: {description}")
    return "\n".join(lines)


def render_second_pass_prompt_example(
    *,
    first_pass_type: str = "medical_release_received",
) -> tuple[str, str]:
    """Return a runtime-rendered example second-pass prompt."""
    catalog_types = [
        {
            "name": "medical_release_received",
            "description": "Signed HIPAA authorization pages dominate.",
        },
        {
            "name": "interim_lien",
            "description": "Request for lien info/itemization/payment ledger.",
        },
        {
            "name": "final_lien_request_received",
            "description": "Explicit request for final lien amount.",
        },
    ]
    focused_types = [item["name"] for item in catalog_types]
    hard_rules = "\n".join(SECOND_PASS_HARD_RULE_LINES)
    conflict_rules = "\n".join(
        [
            *SECOND_PASS_MED_RELEASE_CONFLICT_RULES,
            SECOND_PASS_INTERIM_KEYWORD_HEADER,
            '  - "our office represents"',
            '  - "asking for payment ledger"',
        ]
    )
    types_block = _escape_format_braces(
        json.dumps(
            {"types": catalog_types},
            indent=2,
            ensure_ascii=False,
        )
    )
    mapping_block = _escape_format_braces(
        json.dumps(
            {
                "predicted_type": first_pass_type,
                "focused_types": focused_types,
                "rationale_by_correct_type": {
                    "interim_lien": [
                        'wording: "our office represents"',
                        "asking for payment ledger",
                    ],
                    "final_lien_request_received": ['asking for the "final lien"'],
                },
            },
            indent=2,
            ensure_ascii=False,
        )
    )
    rationale_focus = (
        f"Second-pass focus: first pass predicted '{first_pass_type}'.\n"
        "- Candidate correct type: interim_lien\n"
        '  - wording: "our office represents"\n'
        "  - asking for payment ledger\n"
        "- Candidate correct type: final_lien_request_received\n"
        '  - asking for the "final lien"'
    )
    prompt_template = SECOND_PASS_PROMPT_TEMPLATE.format(
        first_pass_type=first_pass_type,
        focused_types=", ".join(focused_types),
        hard_rules=hard_rules,
        conflict_rules=conflict_rules,
        types_block=types_block,
        mapping_block=mapping_block,
        rationale_focus=rationale_focus,
    )
    catalog_block = _render_catalog_block(catalog_types)
    prompt = prompt_template.format(
        catalog=catalog_block,
        fallback_instruction="<fallback_instruction rendered at runtime>",
    )
    return prompt, catalog_block


app = typer.Typer(add_completion=False, help="Prompt rendering helpers.")
console = Console()


@app.command()
def render(
    first_pass_type: str = typer.Option(
        "medical_release_received",
        "--first-pass-type",
        help="First-pass predicted type to seed the example prompt.",
    ),
) -> None:
    """Print a runtime-rendered second-pass prompt example."""
    seed_type = str(first_pass_type).strip() or "medical_release_received"
    logger.info(f"Rendering second-pass prompt example for first_pass_type={seed_type}")
    prompt, catalog = render_second_pass_prompt_example(first_pass_type=seed_type)
    console.print(Panel.fit(catalog, title="Catalog (Preview)"))
    console.print(Panel.fit(prompt, title="Second-Pass Prompt Example"))


if __name__ == "__main__":
    app()
