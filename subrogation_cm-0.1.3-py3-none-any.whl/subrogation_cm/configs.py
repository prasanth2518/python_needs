"""
Configurations for lien document classification and extraction.
"""

from pathlib import Path

DEFAULT_MODEL = "gpt-4o"
SAMPLE_DOC_ROOT = Path("data/subro_sample_docs/synthetic")
SUPPORTED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}

PRIORITY_NO_CONTEXTS = {
    "CTSCASGA",
}


def _build_second_pass_type_mapping(
    *,
    type_verbatims: dict[str, list[str]],
    common_mismatches: list[dict[str, str]],
) -> list[dict[str, object]]:
    """Expand common mismatch routes into second-pass mapping rows."""
    rows: list[dict[str, object]] = []
    for mismatch in common_mismatches:
        predicted_type = str(mismatch.get("predicted_type", "")).strip()
        correct_type = str(mismatch.get("correct_type", "")).strip()
        rationale = list(type_verbatims.get(correct_type, []))
        if not predicted_type or not correct_type or not rationale:
            continue
        rows.append(
            {
                "correct_type": correct_type,
                "predicted_type": predicted_type,
                "rationale": rationale,
            }
        )
    return rows


# Default context baseline from:
# data/contexts/Casualty Standard_Document Type and Keywords.docx
# Keep this order as the canonical default context sequence.
DEFAULT_CONTEXT_DOC_TYPES = [
    "expedited_request_received",
    "subpoena",
    "claims_dispute_received",
    "final_lien_request_received",
    # Internal canonical label for "Interim Lien Request Received"
    "interim_lien",
    "compromise_request_received",
    "medical_records_request_received",
    "settlement_document",
    "attorney_withdrawal",
    "case_information_form",
    "medical_release_received",
    "legal_document_received",
    "letter_or_fax_from_attorney",
    "letter_or_fax_from_insurance_company",
    "birth_or_death_certificate",
    "certified_return_receipt",
    "undelivered_mail",
    "check",
]

SECOND_PASS_TYPE_VERBATIMS = {
    "claims_dispute_received": [
        "disputing the amounts of the final lien request",
        "remove unrelated charges",
        "remove duplicate charges",
    ],
    "expedited_request_received": [
        "following up on the attached",
        "Follow-Up for an Existing Request",
        "2ND NOTICE THIS IS NOT A NEW REQUEST",
        "THIS IS NOT A NEW REQUEST",
        "expedited request for a non member letter",
        "expedited non member ltr",
        "non member letter requested",
        "second request",
        "third request",
        "outstanding request",
        "have not received a response",
        "we have not received a response",
        "we have yet to receive a response",
        "still have not received a response",
        "no response to our prior request",
        "attempted to fax these documents several times",
        "attempted to fax these documents several times but the number did not work",
        "fax these documents several times",
        "several times but the number did not work",
        "multiple attempts with no response",
        "urgent",
    ],
    "final_lien_request_received": [
        "final lien",
        "final lien request",
        "final lien amount",
        "final itemized lien",
        "final ledger",
        "final copy of the ledger",
        "final copy of ledger",
        "need the final lien",
        "have the final lien",
        "send the final lien",
        "forward the final lien",
        "provide the final lien",
        "settlement statement",
        "case settled",
        "case closed",
        "final demand",
    ],
    "interim_lien": [
        "updated lien",
        "ledger and lien information",
        "please provide the lien within a reasonable timeframe",
        "please detail any liens",
        "amount and details of any claim for Medicaid reimbursement",
        "is asserting a reimbursement claim",
        "payment ledger",
        "itemized statement",
        "our office represents",
        "retained to represent the interests",
        "asking for any lien interest",
        "is pursuing a lien",
        "asserting any subrogation or lien rights",
        "confirm if a lien is present",
        "HMS lien",
        "request for payments made as a direct result of the accident",
        "please send us a statement of what has been paid as a direct result of this accident so we can reimburse you",
        "send us a statement of what has been paid by Medicaid as a direct result of this accident",
        "statement of what has been paid by Medicaid",
        "forward your payment log listing all payments",
    ],
    "letter_or_fax_from_attorney": [
        "attorney's office is not requesting anything",
        "providing case information",
        "providing updated information",
        "Letter of representation",
        "Our office has been retained",
        "email stub",
        "email correspondence",
        "please see attached",
        "see attached",
        "attached correspondence",
        "unknown attachment",
        "attachment only",
        "fax cover sheet",
        "asking for clarification about a lien request letter",
        "lien was already paid",
        "Contains original HMS header, no other attachments",
    ],
    "other": [
        "REQUEST FOR RELEASE OF PATIENT RECORDS",
        "Health Insurance Billing Records",
        "Request Letter Under the Hi-Tech Act of 2009",
        "drop the case",
        "Medical Records Request",
        "Request for STATUS",
        "FOLLOW-UP LETTER TO PROVIDER",
        "Billing Records with Certification",
        "retrieve any and all Medical Records and Billing Records",
        "Certification Statement",
        "record retrieval service",
        "produce the requested records",
        "request copies of clinical and medical records",
        "release of patient records",
        "UB04",
        "CMS 1500",
        "National Drug Codes",
        "package codes",
    ],
    "check": [
        "account no.",
        "case no.",
        "file no.",
        "scanned check",
        "check image",
        "check copy",
        "physical check",
        "dollar amount box",
        "written amount line",
        "MICR",
        "routing number",
        "endorsement",
    ],
    "subpoena": [
        "SUBPOENA",
        "SUBPOENA DUCES TECUM WITHOUT DEPOSITION",
        "SUBPOENA DUCES TECUM FROM NON-PARTY",
        "DUCES TECUM WITHOUT DEPOSITION",
        "RECORDS PRODUCTION ONLY",
        "YOU ARE COMMANDED",
        "YOU ARE HEREBY COMMANDED",
        "YOU MAY MAIL THESE RECORDS IN LIEU OF APPEARANCE",
        "YOU MAY MAIL OR DELIVER COPIES",
        "YOU MAY COMPLY WITH THIS SUBPOENA BY PROVIDING LEGIBLE COPIES",
        "CERTIFICATE OF NOTICE",
        "CERTIFICATE OF NON-OBJECTION",
        "CERTIFICATE OF NO OBJECTION TO SUBPOENAS DUCES TECUM WITHOUT DEPOSITION",
        "NOTICE OF PRODUCTION FROM NON-PARTY",
        "DEFENDANT'S NOTICE OF PRODUCTION FROM NON-PARTIES",
        "HIPAA DISCLOSURE",
        "CERTIFICATE OF HIPAA SATISFACTORY ASSURANCES CERTIFICATION",
        "STATEMENT OF ASSURANCE FOR SUBPOENAS",
        'SEE EXHIBIT "A" ATTACHED HERETO',
        "EXHIBIT A",
        "this will not be a deposition",
        "no testimony will be taken",
        "Records Custodian of",
        "MAIL-IN ONLY",
        "if you do not have records for this person",
        "Enclosed is a Subpoena Duces Tecum",
        "enclose a Subpoena Duces Tecum Without Deposition",
        "summons",
        "commanded to appear",
        "commanded to produce",
        "notice to produce",
        "respond to this subpoena",
        "HMS, HRA and OMIG listed as defendant",
    ],
    "attorney_withdrawal": [
        "no longer represents",
        "no longer represent",
        "no longer representing",
        "our office no longer represents",
        "we are no longer representing",
        "please direct all future correspondence directly to",
        "please directly send all correspondence to",
        "please address all future communications and correspondence directly to your patient",
        "please address all future correspondence directly to your insured client",
        "forward all future correspondence directly to",
        "no recovery was made in this case",
        "disengagement",
        "withdrawn representation",
        "withdraw as counsel",
        "terminated representation",
        "please update your records",
    ],
    "letter_or_fax_from_insurance_company": [
        "insurance company sender",
        "carrier letterhead",
        "Claim Documents",
        "attached is correspondence regarding your claim",
        "Bodily Injury claim",
        "we are contacting you regarding a bodily injury claim being presented",
        "Claim Development Processor",
        "PIP coverage exhausted",
        "UM coverage exhausted",
        "benefits have exhausted",
        "there is no remaining coverage",
        "will not be providing any coverage",
        "unable to locate a CLAIM",
        "unable to locate a POLICY",
        "Insufficient Information Provided",
        "Adjuster Of Record",
        "claim correspondence",
        "policyholder",
        "statement of insurance disclosure",
        "certified copy of the policy",
        "BI RELEASE",
        "tendered our insured's Bodily Injury limits",
        "medical payment coverage has been exhausted",
        "medical payments coverage has been exhausted",
        "claim is closed",
        "Insurance company is not requesting anything",
        "insurance company is providing case information",
        "insurance company is providing updated information",
        "claim approved",
        "claim denied",
        "claim status",
        "coverage determination",
        "insurance claim number",
        "adjuster",
        "claims representative",
    ],
    "settlement_document": [
        "NOTICE OF SETTLEMENT",
        "case settled",
        "this case settled",
        "settled on",
        "settlement date",
        "date case was settled",
        "settlement amount",
        "total amount of settlement",
        "settlement proceeds",
        "preparing to disburse funds",
        "notice of settlement for case",
        "tendered bodily injury limits",
        "claim has resolved",
        "settlement statement",
        "settlement sheet",
        "settlement breakdown of disbursement",
        "breakdown of disbursement",
        "final settlement",
        "case has settled",
        "case has reached settlement",
        "awaiting to disperse funds",
        "disbursement of funds",
    ],
}

SECOND_PASS_COMMON_MISMATCHES = [
    {
        "predicted_type": "final_lien_request_received",
        "correct_type": "claims_dispute_received",
    },
    {
        "predicted_type": "compromise_request_received",
        "correct_type": "final_lien_request_received",
    },
    {
        "predicted_type": "medical_release_received",
        "correct_type": "final_lien_request_received",
    },
    {
        "predicted_type": "medical_release_received",
        "correct_type": "other",
    },
    {
        "predicted_type": "case_information_form",
        "correct_type": "final_lien_request_received",
    },
    {
        "predicted_type": "case_information_form",
        "correct_type": "interim_lien",
    },
    {
        "predicted_type": "case_information_form",
        "correct_type": "other",
    },
    {
        "predicted_type": "letter_or_fax_from_attorney",
        "correct_type": "interim_lien",
    },
    {
        "predicted_type": "medical_release_received",
        "correct_type": "interim_lien",
    },
    {
        "predicted_type": "medical_release_received",
        "correct_type": "expedited_request_received",
    },
    {
        "predicted_type": "compromise_request_received",
        "correct_type": "letter_or_fax_from_attorney",
    },
    {
        "predicted_type": "final_lien_request_received",
        "correct_type": "letter_or_fax_from_attorney",
    },
    {
        "predicted_type": "interim_lien",
        "correct_type": "letter_or_fax_from_attorney",
    },
    {
        "predicted_type": "interim_lien",
        "correct_type": "final_lien_request_received",
    },
    {
        "predicted_type": "interim_lien",
        "correct_type": "expedited_request_received",
    },
    {
        "predicted_type": "other",
        "correct_type": "interim_lien",
    },
    {
        "predicted_type": "other",
        "correct_type": "letter_or_fax_from_attorney",
    },
    {
        "predicted_type": "other",
        "correct_type": "check",
    },
    {
        "predicted_type": "other",
        "correct_type": "subpoena",
    },
    {
        "predicted_type": "medical_release_received",
        "correct_type": "subpoena",
    },
    {
        "predicted_type": "other",
        "correct_type": "attorney_withdrawal",
    },
    {
        "predicted_type": "letter_or_fax_from_attorney",
        "correct_type": "attorney_withdrawal",
    },
    {
        "predicted_type": "other",
        "correct_type": "letter_or_fax_from_insurance_company",
    },
    {
        "predicted_type": "letter_or_fax_from_attorney",
        "correct_type": "letter_or_fax_from_insurance_company",
    },
    {
        "predicted_type": "other",
        "correct_type": "settlement_document",
    },
    {
        "predicted_type": "letter_or_fax_from_attorney",
        "correct_type": "settlement_document",
    },
    {
        "predicted_type": "letter_or_fax_from_insurance_company",
        "correct_type": "settlement_document",
    },
    {
        "predicted_type": "letter_or_fax_from_insurance_company",
        "correct_type": "interim_lien",
    },
    {
        "predicted_type": "letter_or_fax_from_attorney",
        "correct_type": "check",
    },
    {
        "predicted_type": "letter_or_fax_from_attorney",
        "correct_type": "subpoena",
    },
]

SECOND_PASS_TYPE_MAPPING = _build_second_pass_type_mapping(
    type_verbatims=SECOND_PASS_TYPE_VERBATIMS,
    common_mismatches=SECOND_PASS_COMMON_MISMATCHES,
)

CLASSIFICATION_CONFIG = {
    "model": DEFAULT_MODEL,
    "retries": 2,
    "classification_rolling": {
        "enabled": True,
        "window_size": 5,
        "overlap": 2,
    },
    "classification_second_pass": {
        "enabled": True,
        "mapping": SECOND_PASS_TYPE_MAPPING,
        "allowed_non_priority_routes": [
            {
                "predicted_type": "medical_release_received",
                "correct_type": "other",
            },
            {
                "predicted_type": "case_information_form",
                "correct_type": "other",
            },
        ],
        "instruction_mode": "standalone",
        "catalog_mode": "rationale_only",
        "window_flip_min_confidence": 0.85,
        "verbatim_confirmation_enabled": False,
        "verbatim_max_candidates": 2,
    },
    "possible_types_min_confidence": 0.0,
    "default_context_doc_types": DEFAULT_CONTEXT_DOC_TYPES,
    "priority_list_path": None,
    "priority_no_contexts": PRIORITY_NO_CONTEXTS,
    "priority_context": "CTSCASID",
    "tools": [{"function": "subrogation_cm.tools.priority_rank"}],
    "types": [
        {
            "name": "expedited_request_received",
            "description": "Distinguishing cues: expedite/expedited/urgent request language; explicit follow-up indicators such as multiple requests, second request, third request, outstanding request, prior unanswered request, or following up on a prior unanswered request. Use for inbound correspondence asking Medicaid/HMS/Gainwell to expedite handling because prior requests were unanswered or delayed, including requests for expedited non-member letters. Common phrases: expedite; expedited; urgent; second request; third request; multiple requests; outstanding request; have not received a response; we have not received a response; we have yet to receive a response; still have not received a response; no response to our prior request; following up on the attached; Follow-Up for an Existing Request; 2ND NOTICE THIS IS NOT A NEW REQUEST; THIS IS NOT A NEW REQUEST; attempted to fax these documents several times; attempted to fax these documents several times but the number did not work; fax these documents several times; several times but the number did not work; multiple attempts with no response; expedited non member ltr; expedited request for a non member letter; non member letter requested; office does not and never has represented; does not and never has represented; have never represented; has never represented; never has represented; never have represented Required cues: expedite/urgent language; explicit follow-up or prior no-response context; or explicit expedited non-member-letter request Optional cues: prior request dates; repeated outreach count; deadline pressure; request for non-member letter; request for status on prior submission; failed fax attempts; repeated unsuccessful transmission language; asap language paired with prior failed attempts Negative cues: explicit final lien ask without follow-up language; updated/itemized lien/ledger ask without expedite/follow-up language; lien reduction/waiver request; resend-only wrappers such as 'resending the attached' without urgency, prior no-response, repeated-request language, or failed-transmission context; lien-balance phrases such as 'outstanding liens', 'outstanding balances', or settlement escrow language about unresolved liens, which are not the same as outstanding request. Avoid if: If explicit final lien request then NOT this type unless the cover email is clearly a follow-up/expedite request; If explicit updated/itemized ledger request then NOT this type unless the cover email explicitly frames it as an expedite/follow-up request; If compromise/reduction request then NOT this type; If the email merely says the sender is resending attached paperwork without any urgency, prior no-response, repeated-request cue, or failed-fax/failed-delivery history then NOT this type; If the document only says 'if we do not receive a response' or otherwise uses future conditional deadline language, then NOT this type by itself. Often confused with: final_lien_request_received; interim_lien; compromise_request_received; medical_release_received; other. Notes: If the cover email explicitly says it is following up on an unanswered request, is urgent, or requests an expedited non-member letter, prefer this type even when attached documents ask for lien ledgers or reimbursement details. Repeated-request wording like 'Follow-Up for an Existing Request' or '2ND NOTICE THIS IS NOT A NEW REQUEST' should also count as expedited follow-up context. Failed submission language such as repeated unsuccessful fax attempts or multiple attempts with no response should also count as expedited follow-up context when the packet is asking for action or status. Do not treat 'resending the attached' by itself as expedited. Do not treat future conditional language such as 'if we do not receive a response' as proof of a prior unanswered request. Do not treat 'outstanding liens', 'outstanding balances', or settlement-statement escrow language as proof of an outstanding request.",
        },
        {
            "name": "final_lien_request_received",
            "description": 'Distinguishing cues: explicit \'final lien request\'; settlement imminent/settled stated; ask \'final itemized lien\'; last treatment date mentioned; send final lien amount. Distinguishing cues: final lien request; final itemized lien; final subrogation balance; request lien breakdown; case settled/near settlement; last date of treatment; send final lien amount. Use for incoming correspondence (email/fax/letter attachment) that asks the Medicaid/HMS/Gainwell tort recovery or TPL unit to provide a final lien amount or final subrogation balance for a named client/patient and incident. Typically includes case number or claim identifiers, date of loss/incident, dates of service/last treatment, and language like "final lien request" or "final itemized lien"; may include notice of representation and settlement details and request a breakdown/itemization. Common phrases: final lien; final lien request; final itemized lien; final lien amount; need the final lien; have the final lien; send the final lien; forward the final lien; provide the final lien; final subrogation balance; notice of representation; to start the subrogation process; case number; date of loss; dates of service; last day of treatment; settlement details notice; case settled; bodily injury lien; request for information Required cues: final lien language; client/patient identified; incident or loss date Optional cues: HMS case number; TPL unit; tort recovery unit; settlement date; settlement amount; injured body parts; authorization attached; HIPAA authorization; attorney/law firm letterhead; fax cover sheet; insurance adjuster signature Common fields: patient/client name; date of birth; SSN (masked); case number; HMS case number; claim number; date of loss/incident; dates of service; last treatment date; settlement date; settlement amount; attorney/firm contact; insurer/adjuster contact; fax/email destinations Negative cues: itemized lien statement enclosed; final lien amount provided; payment remittance; release of lien; satisfaction of lien; lien reimbursement check; appeal/administrative hearing; medical records request only. Avoid if: If requesting lien reduction/waiver then NOT this type; If document is casualty intake questionnaire then NOT this type; If insurer acknowledgement only then NOT this type; If final lien amount provided already then NOT this type. Often confused with: case_information_form; letter_or_fax_from_attorney; compromise_request_received. Notes: Wrapper-email language like "need the final lien", "have the final lien", or "forward the final lien" should count when the email is requesting the final lien for the case. A final-lien mention on an authorization or disclosure form can also count when the form is case-specific and identifies final lien information to be released. Avoid if: If only fax cover sheet then NOT this type; If no \'final\' lien language then NOT this type; If just subrogation notice/intake then NOT this type; If email subject only name then NOT this type. Often confused with: interim_lien.',
        },
        {
            "name": "interim_lien",
            "description": "Distinguishing cues: explicit lien/ledger request; updated/final lien wording; settlement amount/date fields; government lien unit form; W-588AA style layout. Distinguishing cues: government subrogation rights letter; itemization requires signed authorization; claims history profile ordered; explicit lien amount request; updated/final lien wording; W-588AA style fields; lien ledger/itemization ask; settlement amount/date fields. Distinguishing cues: health insurance notice attached; letter of representation email; requests lien info implicitly; law firm case manager sender; public assistance recovery context; health insurance notice letter; letter of representation packet; acknowledge receipt request; inbound from claimant counsel; request acknowledge receipt. Distinguishing cues: updated lien request; interim lien/ledger; UPDATED / FINAL LIEN REQUEST; type of lien field; index/CIN/file number; settlement amount field; Division of Liens and Recovery. Document is an incoming lien request or correspondence for an interim/updated (or final) Medicaid/public assistance lien amount, typically from a government agency form or an email/portal submission. Includes claimant/plaintiff identifiers (name, DOB, partial SSN/CIN), incident/date of injury, legal case identifiers (index/case/file #), settlement status, and requesting attorney/firm contact details. Often references lien recovery/division, subrogation, waiver/compromise, and may include attachments (release, hearing notice). Common phrases: UPDATED / FINAL LIEN REQUEST; lien amount request; Type of Lien; Updated; Final; Plaintiff Name; Settlement Amount; Date of Incident; Index Number; Case # or CIN; Attorney requesting lien; Firm Name; Firm Address; Please send an updated lien; attached correspondence; Division of Liens and Recovery; Medicaid lien; Public Assistance lien; subrogation Required cues: lien request; Updated or Final; claimant/plaintiff name; incident date or injury; requesting attorney or agency contact Optional cues: SSN (full or partial); date of birth; settlement date; settlement amount; index number; NYC file #; CIN; fax form; fax number; conference date; insurance company info; waiver request; compromise form; release attachment; notice of hearing; external email warning Common fields: plaintiff/claimant name; SSN (or last 4); date of birth; date of incident; injury description; settlement amount; settlement date; index number; case number/CIN; file number; type of lien (updated/final); attorney name; law firm; firm address; phone; fax; email; insurance claim/file #; conference/hearing date Negative cues: lien satisfaction; lien release; final lien amount statement; payment confirmation; invoice/billing statement; court pleading; medical record progress note; policy declarations page. Avoid if: If signed HIPAA authorization dominates then NOT this type; If asking for reduction/waiver then NOT this type; If request says final lien only then NOT this type; If no lien/ledger request language then NOT this type. Often confused with: medical_release_received; letter_or_fax_from_attorney; final_lien_request_received. Notes: Common failure mode: classify as medical_release_received when authorization pages outweigh the lien-request form/letter. Avoid if: If standalone signed HIPAA form dominates then NOT this type; If only medical records release packet then NOT this type; If document is pure HIPAA form then NOT this type; If no lien/notice context then NOT this type; If HIPAA form dominates then NOT this type; If only signed authorization attached then NOT this type; If authorization content dominates pages then NOT this type; If only HIPAA form without lien/ledger ask then NOT this type; If purely medical records request then NOT this type; If only privilege cover sheet then NOT this type. Often confused with: medical_release_received; other; final_lien_request_received. Notes: Model over-weighted 'signed authorization' in email header; excerpt lacks HIPAA form cues. Interim lien should win when cover email transmits insurance notice/representation materials without actual authorization pages. | Prediction over-fired on 'signed authorization' in email body; excerpt lacks HIPAA form cues and instead signals an insurance notice/representation packet that should map to interim lien intake/notice workflow. | Predicted type over-fired on phrase 'signed authorization' in email cover; excerpt lacks HIPAA-form cues. Add rule: require actual authorization-page markers; treat representation/health-insurance notice packets as interim lien intake even without dollar amount. | Predicted type over-fired due to attachment name containing authorization; excerpt shows primary intent is requesting paid itemization/ledger (interim lien) with Medicaid context, not transmitting a signed HIPAA release. | Model over-weighted absence of 'updated/final lien request' form; this is still an interim lien/payment-ledger request to Medicaid recovery (itemization of payments) with subrogation/settlement cues and claimant identifiers. | Cover email is generic but references Medicaid notice of claim; treat NOC Medicaid as interim lien intake rather than other. | Model overweighted HIPAA mention in email cover; excerpt shows LOR/claim-initiation and acknowledgement request with insurance card, not an actual signed authorization page. Add rule that HIPAA mentioned in cover email without authorization-form structure should not trigger medical_release_received, and strengthen interim_lien cues for LOR-to-Medicaid packets. | Model overweighted HIPAA pages; lien-request cover sheet and Medicaid recipient should override attachments. | Final-lien type over-fired on law-firm subro contact; excerpt shows cover sheet/incident identifiers but no settlement or explicit final/updated lien request; route generic lien-info asks to interim_lien. Avoid if: If Casualty Recovery Information Form present then NOT this type; If intake questionnaire sections dominate then NOT this type; If body-part checkboxes present then NOT this type; If attorney LOR requests acknowledgment then NOT this type; If asks for adjuster name then NOT this type; If enclosed authorization mentioned without lien request then NOT this type; If document is LOR to HMS/Medicaid then NOT this type; If no lien/updated/final/ledger language then NOT this type. Often confused with: case_information_form; letter_or_fax_from_attorney. Avoid if: If law firm LOR then NOT this type; If asks adjuster name then NOT this type; If request is acknowledgment only then NOT this type; If no lien/ledger language then NOT this type; If enclosed authorization mentioned only then NOT this type. Often confused with: letter_or_fax_from_attorney.",
        },
        {
            "name": "letter_or_fax_from_attorney",
            "description": "Distinguishing cues: law firm sender signature; letter of representation; Re client + DOI + case ID; request written acknowledgment; request adjuster information; email header From/To/Sent; law firm fax cover sheet; attorney office sender branding; To: HMS-Medicaid fax; Re: client + MID. Distinguishing cues: law firm email header; letter of representation; Re: client + DOI; Case ID referenced; request written acknowledgment; request adjuster name; HMS Recovery Unit recipient; enclosed authorization mentioned; fax cover sheet fields; law firm sender branding. Distinguishing cues: letter of representation; law firm signature block; requests acknowledgment of representation; requests adjuster name; Re: client + DOI + case ID; email header with attachment; law firm sender/recipient; fax header metadata present; Fax To/From/Pages lines; RE: with MID/case number. Distinguishing cues: law firm as recipient; Fax To / Pages fields; Re: claimant and DOI; privileged/confidential fax notice; agency/vendor sender branding; subrogation rights reminder; instructions to attorney. Identify as letter/fax/email sent between an agency/subrogation vendor and an attorney/law firm about lien/subrogation or records. Typically shows fax header or email headers (From/To/Sent/Subject), 'Re:' with claimant/case number/DOI, and contains confidentiality/HIPAA notice plus requests for billing ledger, itemizations, SSN confirmation, insurance policy details, or lien request/settlement instructions. Common phrases: FAX; Fax To; From:; To:; Sent:; Subject:; RE:; Pages:; Page x of y; Date:; COMMENTS:; NOTICE: This fax is intended; privileged and/or confidential; HIPAA; IMPORTANT REMINDER; subrogation rights; Division of Liens & Recovery; lien request; billing ledger; Please see attached Required cues: attorney or law firm recipient; fax/email header metadata; Re: claimant and/or case number; confidentiality/HIPAA notice; request or notice about lien/subrogation; please review; for review; status update; request for update Optional cues: cover sheet page count; agency/vendor branding (HMS/Gainwell); request SSN confirmation; request insurance policy details; settlement payment instructions; attached form (e.g., W-588AA); contact update reminder; toll-free phone and fax; email external warning banner; simple request for review or status update without urgency/escalation language Common fields: case number; claimant/recipient name; date of incident/injury (DOI); fax numbers; phone numbers; sender name/title; law firm name/address; pages count; SSN; date of birth; settlement amount/date; index number; policyholder name; policy number; insurance company; CIN/file number Negative cues: court caption; complaint or petition; judgment or order; medical treatment notes; itemized medical bill as primary content; policy declarations page; detailed settlement agreement. Avoid if: If it is the attorney requesting updated/final lien then NOT this type; If the main page is W-588AA updated/final request then NOT this type; If it is a casualty intake questionnaire then NOT this type; If purely generic email thread then NOT this type; If attorney replies back to HMS/Gainwell and only attaches the original HMS/Gainwell letter then NOT this type (route to letter_or_fax_from_attorney unless there is an explicit lien request). Often confused with: interim_lien; letter_or_fax_from_attorney; case_information_form. Notes: Directionality matters: agency/vendor to law firm. Avoid if: If no attorney/law firm involved then NOT this type; If primary content is lien amount request/update then NOT this type; If purely internal vendor memo without Re: client/DOI then NOT this type; If court caption/pleading then NOT this type; If primary content is medical bills then NOT this type; If attorney is requesting final/updated lien (W-588AA) then NOT this type; If court caption present then NOT this type; If primary content is medical bill then NOT this type; If pure vendor form only then NOT this type; If only a standalone check then NOT this type. Often confused with: other. Notes: Other over-fired due to empty/loose definition; document clearly shows attorney email + attached representation letter with Re/client/DOI/case ID and request for acknowledgment/adjuster. | \u2018Other\u2019 over-fired because it lacks guardrails; document shows classic law-firm fax cover + HMS letter to attorney with claim amount and payment instructions, matching attorney-directed correspondence. | \u2018Other\u2019 over-fired due to empty definition; excerpt shows classic faxed attorney letter with fax header, law office branding, Re: line, case numbers/DOIs, and lien-case status/closure notice to HMS recovery unit. | Other over-fired due to payment/remittance content; treat attorney-to-vendor full-and-final settlement correspondence (with trust check, Re/DOI/ref#) as attorney letter category even without fax headers. | Other over-fired because recipient is vendor, not law firm; update definition to allow attorney involvement via law firm referenced/payee and lien-satisfaction language even when sent to recovery unit. Avoid if: If primary purpose is updated/final lien amount request then NOT this type; If W-588AA lien request form present then NOT this type; If includes lien amount statement/ledger pages then NOT this type; If sent from government lien unit (not law firm) then NOT this type; If only standalone check then NOT this type; If pure court pleading caption then NOT this type; If primary content is medical billing ledger then NOT this type; If attorney submits W-588AA lien request then NOT this type; If no attorney/law firm named then NOT this type; If purely internal vendor note then NOT this type. Often confused with: interim_lien; other. Notes: Interim_lien over-fired on Medicaid/HMS context; excerpt is a law-firm LOR initiating representation, asking acknowledgment/adjuster, with authorization mention but no lien/updated/final/ledger request. | Other over-fired due to empty/loose scope; document shows law firm fax cover + attorney-to-vendor correspondence plus attached HMS recovery letter with Re/MID/case and payment instructions, which should route to attorney/vendor fax type. | Other over-fired due to empty definition; excerpt shows faxed law-office letter to HMS with Re line, case numbers/DOIs, and closure confirmation. | Other over-fired due to empty definition; document is attorney-to-recovery-unit remittance/closure letter with Re/DOI/ref# and full-and-final satisfaction language plus trust check. | Other over-fired due to empty definition; letter discusses represented claimant, settlement, and payment issued to law firm with lien-satisfaction language, fitting attorney-directed correspondence even though addressed to HMS. Avoid if: If W-588AA lien request form then NOT this type; If primary purpose updated/final lien amount then NOT this type; If multi-page payment ledger dominates then NOT this type; If government unit requests authorization to itemize then NOT this type; If no law firm named then NOT this type; If purely vendor-to-attorney notice then NOT this type; If only fax receipt metadata then NOT this type; If no law firm named anywhere then NOT this type; If only standalone check then NOT this type; If primary purpose is lien amount request then NOT this type. Often confused with: interim_lien; letter_or_fax_from_attorney; other. Notes: Interim_lien over-fired on Medicaid/HMS + authorization mention; excerpt is law-firm LOR initiating representation, requesting acknowledgment/adjuster, with no lien/ledger/update/final request. | Other over-fired due to generic fax/attachment language; strong cues show attorney-office fax to HMS about Medicaid lien payment/remittance with Re line and MID. | Other over-fired on 'status update' cue; excerpt shows clear law office sender, facsimile header, Re line, case/DOI, and attorney-staff signature to recovery unit. | Other over-fired due to empty definition; excerpt is attorney-to-recovery-unit remittance/closure with Re/DOI/REF# and full-and-final satisfaction plus trust check. | Other over-fired due to empty scope; excerpt has Re line + named law firm + settlement/payment + lien-satisfaction responsibility/closure, which matches attorney-involved correspondence even though addressed to HMS.",
        },
        {
            "name": "medical_release_received",
            "description": "Distinguishing cues: actual HIPAA form text; 45 CFR 164.508 present; patient signature block; expiration date or event; revocation/redisclosure language; HIPAA form pages present; 45 CFR 164.508 language; patient signature/expiration; actual HIPAA form pages; revocation/redisclosure clauses. Distinguishing cues: HIPAA authorization title; 45 CFR 164.508; right to revoke; redisclosure warning; scope of PHI; recipient law firm; patient signature date; expiration date/event. Document is a signed HIPAA medical/health information authorization or medical records release, often attached to a law-firm request for subrogation/lien details. Look for an authorization title, patient identifiers, named disclosing entity and recipient (law firm/attorney), scope of records, purpose (personal injury/legal matter), revocation/redisclosure language, and signature/date/expiration. Common phrases: Authorization for release; Authorization to disclose; Release of medical records; Release of health information; Pursuant to HIPAA; 45 CFR 164.508; protected health information; medical authorization; right to revoke; redisclosure; does not apply to psychotherapy notes; expires; effective for; DocuSign Envelope ID; personal injury claim; legal matter; subrogation lien; itemized lien; payment log; liens information Required cues: authorization/release title; patient name; recipient attorney/law firm; records or health info scope; signature and date; expiration term/event Optional cues: date of birth; SSN last4; patient address; fax cover or email header; DocuSign; purpose: civil litigation; HIV/substance abuse checkboxes; psychotherapy notes exclusion; revocation instructions; copy as valid as original; settlement date expiration; case ID/DOI/DOL Common fields: patient name; DOB; SSN/last4; patient address; disclosing entity/provider; recipient name; law firm address; phone/fax/email; description of information; date range/DOS; purpose of disclosure; expiration date/event; revocation statement; signature; relationship/authority Negative cues: medical bill invoice; itemized treatment chart; court order/subpoena; insurance policy declarations; retainer agreement; demand package; settlement release agreement; Request for STATUS; FOLLOW-UP LETTER TO PROVIDER; Billing Records with Certification; Certification Statement; record retrieval service; request any and all Medical Records and Billing Records. Avoid if: If lien request form dominates then NOT this type; If only email cover with no authorization page then NOT this type; If estate asset/exemption questions then NOT this type; If the packet is primarily a medical-records retrieval request with an authorization attached then NOT this type. Often confused with: interim_lien; letter_or_fax_from_attorney; other. Notes: Use this only when the defining document is the authorization itself. If the packet's main purpose is obtaining medical or billing records and the authorization merely supports that request, prefer other. Avoid if: If email-only cover then NOT this type; If attachment-only mention then NOT this type; If no HIPAA form page then NOT this type; If only email cover then NOT this type; If attachment is notice letter then NOT this type; If no HIPAA terms visible then NOT this type; If mentions notice letter only then NOT this type; If no authorization text then NOT this type; If packet is representation+notice then NOT this type; If email requests paid itemization then NOT this type; If records-request letters, status requests, certification statements, or retrieval-vendor instructions dominate the packet then NOT this type.",
        },
        {
            "name": "case_information_form",
            "description": "Distinguishing cues: Casualty Recovery Information Form; Medicaid Beneficiary section; Accident/Incident questionnaire; injury body-part checklist; liable insurer adjuster fields; policy and claim numbers; plaintiff attorney block; lawsuit filed yes/no; case number + MID. Distinguishing cues: HMS Idaho Recovery Unit header; Casualty Recovery Information Form title; Medicaid Beneficiary section; Accident/Incident questionnaire; body-part injury checklist; liable insurer adjuster fields; lawsuit filed yes/no; attorney blocks plaintiff/defense. Distinguishing cues: HMS Idaho Recovery Unit; Case Number + MID; Casualty Recovery Information Form; Medicaid Beneficiary section; Accident/Incident questionnaire; injury body-part checkboxes; liable person + insurer; adjuster policy claim fields; plaintiff attorney block; lawsuit filed yes/no. Distinguishing cues: Casualty Recovery Information Form; member demographics block; accident/incident questionnaire; liable insurance/adjuster fields; plaintiff/defense attorney sections; checkbox injuries/body parts; multi-section intake layout. Document is an HMS/Gainwell casualty recovery required case information form or similar intake (often via email/fax) that requests preliminary case details for a subrogation/liens file. Look for headers like \"Casualty Recovery Information Form\" or \"Casualty Recovery Required Case Information\" plus sections for Medicaid beneficiary/injured party info, accident/incident date/type, injuries/body parts, liable party and insurance (claim/policy/adjuster), and attorney information; may reference case creation, lien notice, or attached questionnaire/form. Common phrases: Casualty Recovery Information Form; Casualty Recovery Required Case Information; Medicaid Beneficiary (Injured Party) Information; Accident/Incident Information; Date of Accident/Incident; Type of Injury; Describe the accident; Liable Person(s) Involved; Liable Insurance Company Information; Adjuster Name; Policy #; Claim #; Plaintiff Attorney Information; Defense Attorney Information; Has a lawsuit been filed?; Health Management Systems (HMS); P.O. Box; Fax Server; Please see attached form; completed questionnaire; Notice of Lien Required cues: casualty recovery form header; injured party/member section; accident/incident date; liable party or insurance section; attorney information section Optional cues: Medicaid ID/billing number; SSN; DOB; body part checklist; lawsuit filed yes/no; last date of medical service; case number; lien referenced; fax/phone contact lines; project website/email; external email disclaimer; attachment mention Common fields: member name; date of birth; social security number; Medicaid ID; address; phone/fax/email; accident/incident date; date of injury/DOI/DOL; accident type; injury description; body parts injured; medical provider/facility; dates of service; liable party name/address; liable insurer name/address; adjuster name; policy number; claim number; maximum liability; plaintiff attorney name/firm/contact; defense attorney name/firm/contact; case number Negative cues: billing invoice statement; medical record chart notes; court pleading or complaint; settlement agreement release; police crash report; EOB explanation of benefits only; demand letter narrative only. Avoid if: If only email transmittal then NOT this type; If primary ask is final lien amount then NOT this type; If primary ask is lien reduction/waiver then NOT this type; If signed HIPAA release dominates then NOT this type. Often confused with: letter_or_fax_from_attorney; final_lien_request_received. Notes: Treat as this type when the actual questionnaire/form pages are visible; attachment-only mentions stay letter_or_fax_from_attorney. Avoid if: If only lien-rights notice letter without form fields then NOT this type; If primary ask is itemization/final lien update with no intake sections then NOT this type. Often confused with: other. Notes: 'other' over-fired due to empty definition; packet includes explicit 'Casualty Recovery Information Form' with structured intake sections, so case_information_form should dominate even when preceded by a lien-rights notice letter. Avoid if: If only subrogation rights notice letter then NOT this type; If only updated/final lien amount request then NOT this type. Often confused with: interim_lien. Notes: Interim_lien over-fired on itemization/updated-claim language in rights letter; visible multi-section intake form with beneficiary, accident, injuries, liable insurance, and attorney fields should override. Avoid if: If only subrogation-rights notice letter then NOT this type; If only request for updated/itemized claim then NOT this type; If form not visible (attachment only) then NOT this type. Often confused with: other. Notes: Other over-fired because definition empty; packet includes explicit multi-section intake form that should override accompanying lien-rights notice letter.",
        },
        {
            "name": "claims_dispute_received",
            "description": "Distinguishing cues: explicit Medicaid/HMS lien named; dispute specific DOS/charges; request updated itemized ledger; request revised final lien letter; plaintiff counsel/paralegal request; attachments list of charge removals. Distinguishing cues: explicit Medicaid/HMS lien referenced; requests remove specific charges; requests revised itemized ledger; disputes dates of service; plaintiff counsel correspondence; itemized DOS/provider removals; duplicate/unrelated charge allegations; request revised lien letter; ledger correction specifics. Distinguishing cues: dispute lien charges; remove unrelated charges; remove duplicate charges; dates of service challenged; request revised lien; itemized ledger correction. Communications (email, fax cover, or dispute letter) from plaintiff counsel/paralegal to HMS/Gainwell requesting correction of a Medicaid lien/subrogation itemization. Typically disputes unrelated or duplicate charges, asks to remove specific dates of service/providers/amounts, and requests an updated/revised final lien letter or itemized ledger for settlement/payment processing; may mention interim vs final lien, case/file numbers, claimant details, and impending settlement deadlines. Common phrases: claim dispute follow up; dispute letter; requesting in writing; remove unrelated charges; remove duplicate charge; updated final itemized lien; revised lien; revised Final Lien Letter; payment ledger; interim lien response; final Medicaid lien; cannot be processed; notice of impending settlement; date of service; charges are not related; please see attached Required cues: dispute or remove charges; request revised/updated lien; Medicaid/HMS lien context; case/file number or client name Optional cues: duplicate claim mentioned; interim vs final lien; photo ID correction; ambulance notes attached; settlement timing mentioned; statute/deadline cited; itemized list of DOS/amount/provider; fax cover sheet Common fields: client/patient name; case number or file number; date of incident/loss; date(s) of service; provider name; charge amount; total paid amount; lien amount; Medicaid/AHCCCS ID; settlement date/amount; contact phone/fax/email; attachments list Negative cues: medical record narrative; insurance policy declarations; court pleadings; invoice for legal services; clinical progress note; EOB payment remittance; demand letter to insurer. Avoid if: If only requests final lien without corrections then NOT this type; If requests waiver/compromise/reduction then NOT this type; If provides lien amount or satisfaction then NOT this type. Often confused with: final_lien_request_received; compromise_request_received; letter_or_fax_from_attorney. Avoid if: If purely medical record narrative then NOT this type; If only requesting final lien status then NOT this type; If compromise/waiver request then NOT this type; If policy limits scarcity then NOT this type; If attorney fees/costs breakdown then NOT this type; If reduced amount as full satisfaction then NOT this type; If wrongful death heirs allocation then NOT this type; If settlement insufficiency argument then NOT this type. Often confused with: other; compromise_request_received. Notes: Document excerpt is IME medical report with injury history and treatment narrative; lacks any lien/Medicaid dispute language. Tighten 'other' to capture medical narrative and add stronger negative rules for claims_dispute_received requiring explicit lien dispute/revision cues. Avoid if: If IME/medical exam narrative then NOT this type; If clinical history and treatment summary then NOT this type; If provider report without lien terms then NOT this type. Often confused with: other. Notes: Overfire avoided by requiring explicit lien-dispute language; this document is IME medical narrative with no Medicaid/HMS lien correction request.",
        },
        {
            "name": "compromise_request_received",
            "description": "Distinguishing cues: limited settlement proceeds; policy limits only recovery; attorney fee percentage cited; heirs allocation discussion; request reduce/compromise lien; full satisfaction language. Distinguishing cues: reduce/waive lien request; full satisfaction offer; compromise approval language; net to client discussion; fees and costs breakdown; policy limits argument; final reduced lien. Document is an incoming communication to Medicaid lien recovery (HMS/Gainwell/state agency) requesting a lien waiver/compromise/reduction or final reduced lien amount. Often references a settlement with limited proceeds, attorney fees/costs, and asks the agency to accept a reduced dollar amount as full satisfaction; may include a compromise approval form or follow-up status inquiry. Common phrases: lien reduction request; waive in full; request a reduction; full satisfaction of lien; compromise offer; Medicaid lien amount; subrogation lien; final reduced lien; please confirm in writing; case number; date of accident; our client; attn case management; via fax; enclosures Required cues: request to reduce lien; Medicaid lien/subrogation; case or Medicaid ID Optional cues: settlement amount; policy limits; attorney fee percentage; costs/expenses; net recovery; compromise approval form; waiver request letter; follow up on attached request; certified mail; lump-sum offer; property address and title lien Common fields: beneficiary/client name; Medicaid ID; case number/HMS case number; date of accident/date of loss; lien amount; settlement amount; attorney fees; case expenses/costs; offer amount; law firm contact info; injury description; other liens; property address (MERP/real property lien cases) Negative cues: medical records request; itemized medical bill; EOB explanation of benefits; clinical treatment notes; lawsuit complaint/petition; police crash report; insurance policy declarations; HIPAA authorization form. Avoid if: If asking for final lien amount only then NOT this type; If requesting updated/interim ledger then NOT this type; If agency provides lien amount statement then NOT this type. Often confused with: final_lien_request_received; letter_or_fax_from_attorney. Notes: Keyword cue: reduction/waiver vs amount-request. Avoid if: If specific charges/DOS disputed then NOT this type; If asks to remove duplicate charges then NOT this type; If requests updated itemized ledger only then NOT this type. Often confused with: claims_dispute_received. Notes: Dispute title over-triggered; body argues limited UM settlement, fees, and insufficient proceeds\u2014classic compromise/waiver context, not charge-by-charge lien correction.",
        },
        {
            "name": "other",
            "description": "Distinguishing cues: request for release of patient records; health insurance billing records; dropped the case; request letter under the Hi-Tech Act of 2009; produce the requested records; clinical and medical records; release of patient records; UB04; CMS 1500; National Drug Codes; package codes. Distinguishing cues: Medical Records Request; Request for STATUS; FOLLOW-UP LETTER TO PROVIDER; Billing Records with Certification; Certification Statement; record retrieval service; retrieve any and all Medical Records and Billing Records. Use for packets that are primarily medical-records or billing-records retrieval requests and do not fit the active lien taxonomy. This includes attorney requests for copies of patient records, billing records, record-package codes, UB04/CMS-1500 forms, provider status follow-ups, certification statements, and retrieval-vendor record request packets even when a signed HIPAA authorization is attached. Common phrases: REQUEST FOR RELEASE OF PATIENT RECORDS; Health Insurance Billing Records; Request Letter Under the Hi-Tech Act of 2009; produce the requested records; clinical and medical records; release of patient records; UB04; CMS 1500; National Drug Codes; package codes; request any and all records; Medical Records Request; Request for STATUS; FOLLOW-UP LETTER TO PROVIDER; Billing Records with Certification; Certification Statement Required cues: records request language; request for billing/clinical records; packet primarily about obtaining medical or billing records rather than lien status, payment/remittance, subpoena compliance, or attorney withdrawal Optional cues: signed HIPAA authorization attached; fax cover sheet; attorney letterhead; itemized medical billing forms; HITECH reference; retrieval vendor or records custodian instructions Negative cues: explicit lien amount request; payment ledger; updated lien; final lien; compromise/reduction request; casualty recovery information form. Avoid if: If primary request is lien or reimbursement status then NOT this type; If packet is primarily a signed HIPAA authorization without a records-request letter then NOT this type. Often confused with: medical_release_received; check; subpoena; attorney_withdrawal. Notes: If a signed authorization is attached only to permit release of records, but the packet's main purpose is records retrieval, status follow-up on missing records, or billing-record certification, prefer other over medical_release_received.",
        },
        {
            "name": "check",
            "description": "Distinguishing cues: Should have an actual scanned physical check or a check-copy image with recognizable check structure. Text-only payment language is not enough by itself. ",
        },
        {
            "name": "subpoena",
            "description": "Distinguishing cues: SUBPOENA DUCES TECUM WITHOUT DEPOSITION; SUBPOENA DUCES TECUM FROM NON-PARTY; records production only; subpoena packet compelling records production; YOU ARE COMMANDED / YOU ARE HEREBY COMMANDED; court caption and case number; records custodian addressee; production deadline; CERTIFICATE OF NOTICE; CERTIFICATE OF NON-OBJECTION; CERTIFICATE OF NO OBJECTION TO SUBPOENAS DUCES TECUM WITHOUT DEPOSITION; CERTIFICATE OF SERVICE when tied to subpoena/non-party production pages; HIPAA DISCLOSURE; CERTIFICATE OF HIPAA SATISFACTORY ASSURANCES CERTIFICATION; STATEMENT OF ASSURANCE FOR SUBPOENAS AND NOTIFICATION FOR SUBPOENA OF PROTECTED HEALTH INFORMATION; NOTICE OF PRODUCTION FROM NON-PARTY; DEFENDANT'S NOTICE OF PRODUCTION FROM NON-PARTIES; EXHIBIT A; SEE EXHIBIT 'A' ATTACHED HERETO; subpoenaed records listed by category; attorney or court signature block; Florida Rule/HIPAA subpoena notice language; mail-in-only compliance language. Use for formal subpoena or subpoena-related legal process packets requiring production of records/documents for litigation, including multi-page mixed packets where some pages are subpoena face sheets and other pages are companion notice, certification, service, HIPAA-assurance, or exhibit pages tied to the same subpoenaed records-production event. This includes the subpoena itself, subpoena-from-non-party packets, records-production-only packets, notice-of-production packets, non-objection pages, HIPAA disclosure/assurance pages, Exhibit A record schedules, certificate-of-service pages, records-custodian lists, and attorney transmittal pages that explicitly enclose or refer to the subpoena for records production. Common phrases: SUBPOENA; SUBPOENA DUCES TECUM WITHOUT DEPOSITION; SUBPOENA DUCES TECUM FROM NON-PARTY; RECORDS PRODUCTION ONLY; YOU MAY MAIL THESE RECORDS IN LIEU OF APPEARANCE; YOU MAY MAIL OR DELIVER COPIES; YOU MAY COMPLY WITH THIS SUBPOENA BY PROVIDING LEGIBLE COPIES; YOU ARE COMMANDED; YOU ARE HEREBY COMMANDED; Records Custodian of; complete medical records; insurance claims; itemized statements, bills, patient account ledgers; if you fail to appear; contempt of court; HIPAA DISCLOSURE; CERTIFICATE OF NOTICE; CERTIFICATE OF NON-OBJECTION; CERTIFICATE OF NO OBJECTION TO SUBPOENAS DUCES TECUM WITHOUT DEPOSITION; CERTIFICATE OF HIPAA SATISFACTORY ASSURANCES CERTIFICATION; NOTICE OF PRODUCTION FROM NON-PARTY; DEFENDANT'S NOTICE OF PRODUCTION FROM NON-PARTIES; attached subpoena(s) directed to; protected health information is being subpoenaed; SEE EXHIBIT 'A' ATTACHED HERETO; MAIL-IN ONLY; this will not be a deposition; no testimony will be taken; enclosed is a Subpoena Duces Tecum for records production; if you do not have records for this person Required cues: formal subpoena, subpoena-from-non-party, notice-of-production, non-objection, or subpoena-companion legal-process language; court caption or subpoena/production form structure; command or notice to produce records/documents; records-custodian/legal recipient context Optional cues: case number; plaintiff/defendant caption; compliance date/time; production address; attorney name; law firm name; proof/certificate of notice or service; HIPAA notice language; non-party wording; Exhibit A record schedule; patient identifiers; itemized record categories; mailed/faxed/emailed compliance instructions; attorney transmittal letter explicitly enclosing subpoena Common fields: court name; case caption; case number; subpoena recipient; records custodian; patient name; DOB; SSN; Medicare/Medicaid ID; compliance deadline; production location/address; issuing attorney; law firm; service date; requested record categories Negative cues: simple records request letter; HITECH request; HIPAA authorization by itself; letter of representation; final lien request; interim lien request; compromise request; generic legal pleading, motion, complaint, or order without subpoena/non-party production language. Avoid if: If the document is only a general court filing or legal pleading without subpoena, non-party production, attached-subpoena, or subpoena-companion language then NOT this type; If it is only a records-retrieval cover letter without visible subpoena/non-party production context then NOT this type; If it is only a signed HIPAA authorization or ordinary medical-records request then NOT this type. Often confused with: other; medical_release_received. Notes: Many examples appear as a single 10-20 page packet rather than separate documents. Prefer subpoena when the packet as a whole is centered on subpoena-driven or non-party compulsory records production, even if some individual pages are only certificates, service pages, HIPAA assurance pages, records-custodian lists, or notice pages rather than the subpoena face page itself.",
        },
        {
            "name": "attorney_withdrawal",
            "description": "Distinguishing cues: attorney or law firm states it no longer represents the client/patient/insured; directs future correspondence or communications directly to the client/patient/insured; withdrawal/end-of-representation notice; no recovery made in this case; office asks recipient to update records and stop sending future lien or records correspondence to counsel. Use for inbound letters, faxes, or emails where prior counsel affirmatively states representation has ended or been withdrawn for the referenced matter and instructs the recipient to communicate directly with the client/patient/insured instead of the law firm. Common phrases: no longer represents; no longer represent; no longer representing; we are no longer representing; our office no longer represents; please direct all future correspondence directly to; please directly send all correspondence to; please address all future communications and correspondence directly to your patient; please address all future correspondence directly to your insured client; forward all future correspondence directly to the client; direct all future communications to your patient; we are no longer representing for the above referenced accident date; no recovery was made in this case Required cues: representation has ended or been withdrawn; identified client/patient/insured; instruction to send future correspondence directly to the client/patient/insured or clear statement that counsel no longer represents the matter Optional cues: law firm letterhead; Dear Providers ; date of accident / date of loss; DOB; case/file number; provider/Medicaid recipient address block; statement that no recovery was made; request to update records Common fields: client/patient name; date of birth; date of accident/loss; case/file number; law firm name; attorney/staff signature; provider/agency addressee Negative cues: active letter of representation; request for updated lien or payment ledger; final lien request; compromise/reduction request; medical-records request; HIPAA authorization; generic attorney transmittal without withdrawal language. Avoid if: If counsel is actively representing and requesting lien/records action then NOT this type; If the packet is only a medical-records or billing-records request then NOT this type; If the document merely references prior counsel or copied parties without stating representation ended then NOT this type. Often confused with: letter_or_fax_from_attorney; other. Notes: Prefer this type when the document’s main purpose is to terminate representation for the matter and redirect future contact to the client/patient/insured, even if it is on law-firm letterhead and includes case-identifying fields.",
        },
        {
            "name": "letter_or_fax_from_insurance_company",
            "description": "Distinguishing cues: named insurance carrier; insurance company sender; carrier letterhead or claims-system email; adjuster, claims department, claim team, or claim development processor correspondence; claims representative; claim representative; insurance adjuster; insurer-originated fax, email, or letter to Medicaid / HMS / Gainwell / TPL recovery unit or claimant/counsel; claim number, policyholder, insured, injured party, loss date, coverage status, settlement status, or claim-document transmittal; insurer response about claim information, exhausted coverage, no remaining coverage, no claim/policy match, tendered limits, claim closed, statement of insurance disclosure, policy copy, release, or insufficient information provided. Use for correspondence originating from an insurance carrier or claims administrator whose main purpose is communicating claim status, coverage details, settlement/tender position, claim-document transmittal, or requests for additional identifying information. This includes insurer letters, claims-team emails, insurer fax cover sheets, claim-document packets, statement-of-insurance-disclosure packets, BI release packets, and carrier notices returning documents for insufficient identifying information. Common phrases: Insurance Company; Claim Documents; attached is correspondence regarding your claim; PIP coverage exhausted; UM coverage exhausted; there is no remaining coverage; medical payment coverage has been exhausted; medical payments coverage has been exhausted; benefits have exhausted; will not be providing any coverage; unable to locate a claim; unable to locate a policy; insufficient information provided; tendered our insured's Bodily Injury limits; statement of insurance disclosure; certified copy of the policy; BI release; claim is closed Required cues: insurer/carrier sender or branding; claim/coverage/settlement correspondence format; communication about claim status, coverage, policy, settlement, release Optional cues: claim number; loss date; policyholder; insured; injured party; beneficiary; beneficiary DOB/SSN; case ID; adjuster name; no-reply claims email; attached correspondence note; coverage exhaustion dates; statement of insurance disclosure; policy copy; release form; tender letter Common fields: insurance company name; claim number; policyholder; insured/injured party/beneficiary; DOB/SSN; loss date/date of incident; case ID; adjuster/contact name; phone/fax/email; coverage type; exhaustion date; settlement amount; mailing address Negative cues: attorney letterhead; law-firm representation notice; explicit final lien request from counsel; structured interim-lien request form; subpoena/non-party production packet; attorney withdrawal notice; standalone claimant/customer forwarding email with insurer attachments but no insurer-originated correspondence Avoid if: If the document's main purpose is asking Medicaid/TPL for what has been paid, requesting a payment log, payment ledger, itemized payment summary, lien amount, reimbursement amount, or other lien-related payment details, then NOT this type even if the sender is an insurance company; prefer the appropriate lien-related category instead; If the document is primarily attorney-originated correspondence then NOT this type; If the document is an HMS/Gainwell/Medicaid notice to the insurer rather than insurer-originated correspondence then NOT this type; If the sender is a claimant, customer, or attorney merely forwarding insurer attachments, then NOT this type unless the insurer-originated correspondence itself is the dominant document; If the packet is primarily a records request, subpoena packet, or remittance packet then NOT this type. Often confused with: letter_or_fax_from_attorney; final_lien_request_received; other; check. Notes: Prefer this type when the sender is clearly an insurer or adjuster and the packet is communicating claim status, coverage position, settlement/tender information, claim-document transmittal, statement-of-insurance-disclosure materials, or insurer response to Medicaid/TPL correspondence. Do not let generic fax or email formatting push these into other when insurer branding and claim/coverage context are visible. Do not use this type for insurer letters that primarily request paid-amount details, payment logs, or lien-related reimbursement information from Medicaid/TPL; those should route to the lien-related category driven by the request content.",
        },
        {
            "name": "settlement_document",
            "description": "Distinguishing cues: notice of settlement; case settled; settlement date; settlement amount; settlement proceeds; settlement terms; preparing to disburse funds; pending confirmation of final lien before disbursement; settlement packet or transmittal explicitly centered on settlement status; insurer tender, release, or settlement materials included in packet. Use for documents whose main purpose is to notify, document, or transmit information about settlement of the underlying injury claim, including settlement notices, settlement-status letters, settlement transmittal emails/faxes, tender/disclosure packets, and mixed packets centered on settlement or disbursement status. Common phrases: NOTICE OF SETTLEMENT; this case settled; case settled on; settlement date; settlement amount; total amount of settlement; settlement proceeds; preparing to disburse funds; pending confirmation of your final lien in order to disburse funds; notice of settlement for case; tendered bodily injury limits; settlement detail; date case was settled Required cues: settlement-centered purpose; explicit statement that the case has settled, is settled, or that settlement/disbursement is underway Optional cues: date of settlement; insurer name; policy limits; bodily injury limits; release or tender materials; request to confirm no lien before disbursement; fax/email transmittal language; HIPAA authorization or supporting settlement materials attached Common fields: client name; case number; file number; date of loss; settlement date; settlement amount; insurer/carrier; policy limits; disbursement reference; contact information Negative cues: final lien amount request; please forward your final lien; final lien with reduction; reduction request; compromise request; payment ledger request; updated lien request; simple representation letter; subpoena/non-party production packet; check/remittance packet. Avoid if: If the main purpose is requesting the final lien amount or payment ledger, even though settlement is mentioned, then NOT this type and prefer final_lien_request_received; If the main purpose is asking for a reduction, compromise, or acceptance of a lower payoff amount, then NOT this type and prefer compromise_request_received; If the main purpose is transmitting payment or a check, then NOT this type and prefer check; If the document is primarily attorney representation/subrogation correspondence without a settlement-centered purpose, then NOT this type and prefer letter_or_fax_from_attorney. Often confused with: final_lien_request_received; compromise_request_received; letter_or_fax_from_attorney; check. Notes: Prefer settlement_document when settlement status or settlement/disbursement notice is the dominant purpose of the packet. Do not use it for every letter that mentions settlement; if the real ask is a final lien amount or reduction, classify by that request instead.",
        },
    ],
    "instruction_template": (
        "You classify Medicaid lien correspondence from law firms.\n\n{catalog}\n\n"
        "Classification hints:\n"
        "Priority guidance (if provided): ${{priority_hint}}\n"
        "When multiple types plausibly apply, choose the single best label using the priority list above (highest priority wins) and explicitly mention that priority resolved the tie.\n"
        'In reasoning, cite the 1-based page number for every quoted or decisive phrase you rely on, for example "final lien request" (page 2).\n'
        "If you quote text, only quote text that is actually visible on the cited page.\n"
        "If the document only contains a semantic equivalent rather than the exact words, do not present it as verbatim in quotes. Instead say it is a semantic match and cite the page, for example semantic match to a follow-up request cue (page 1).\n"
        "- expedited_request_received: Distinguishing cues: expedite/urgent follow-up, repeated requests, outstanding request, no response.\n"
        "- subpoena: Distinguishing cues: actual subpoena/summons/legal command requiring response, appearance, testimony, or document production; not generic attorney correspondence.\n"
        "- final_lien_request_received: Distinguishing cues: explicit 'final lien request'; settlement imminent/settled stated; ask 'final itemized lien'; last treatment date mentioned; send final lien amount.\n"
        "- interim_lien: Distinguishing cues: explicit lien/ledger request; insurer or attorney asks Medicaid/TPL/NCDHHS what has been paid, for payments made as a direct result of the accident, or for a payment log/ledger; updated/final lien wording; settlement amount/date fields; government lien unit form; W-588AA style layout.\n"
        "- letter_or_fax_from_attorney: Distinguishing cues: attorney/law-firm letters, faxes, email stubs, email threads, fax covers, generic transmittals, and unknown-attachment emails; prefer this over other unless visible content clearly matches a more specific active type.\n"
        "- letter_or_fax_from_insurance_company: Distinguishing cues: insurance-company letters, faxes, email stubs, claim-status correspondence, approval/denial/coverage updates, adjuster or claims-representative messages; not for documents asking Medicaid/TPL/NCDHHS what has been paid, for payments made as a direct result of the accident, for updated amount, lien amount, payment log, or payment ledger; prefer this over other unless visible content clearly matches a more specific active type.\n"
        "- attorney_withdrawal: Distinguishing cues: attorney/law firm says they no longer represent the client, have withdrawn, or are sending a disengagement notice.\n"
        "- medical_release_received: Distinguishing cues: actual HIPAA form text; 45 CFR 164.\n"
        "- other: Distinguishing cues: visible medical-records or billing-records retrieval packet only; avoid other for attorney/law-firm or insurance-company email stubs, fax covers, generic correspondence, or unknown attachments.\n"
        "- case_information_form: Distinguishing cues: Casualty Recovery Information Form; Medicaid Beneficiary section; Accident/Incident questionnaire; injury body-part checklist; liable insurer adjuster field...\n"
        "- claims_dispute_received: Distinguishing cues: explicit Medicaid/HMS lien named; dispute specific DOS/charges; request updated itemized ledger; request revised final lien letter; plaintiff counsel/parale...\n"
        "- compromise_request_received: Distinguishing cues: limited settlement proceeds; policy limits only recovery; attorney fee percentage cited; heirs allocation discussion; request reduce/compromise lien; full s...\n"
        "- settlement_document: Distinguishing cues: settlement statement/sheet or final settlement disbursement breakdown; no updated/interim/final lien request; final lien wins if there is any final-lien ask.\n"
        "- check: Distinguishing cues: must contain a visible scanned physical check or check-copy image with check structure such as payee line, amount box, bank, check number, MICR/routing line, memo, or endorsement; check mentions, remittance language, or cover letters alone are never enough.\n"
        "{fallback_instruction}"
    ),
}

EXTRACTION_CONFIG = {
    "model": "gpt-5-mini-2025-08-07",
    "retries": 2,
    "extraction_rolling": {
        "enabled": True,
        "window_size": 5,
        "overlap": 2,
    },
    "instruction_template": (
        "Extract key fields from Medicaid lien request correspondence. "
        "If context provides lien_type (final_lien_request_received or interim_lien), include it verbatim. "
        "Return null when a field is not stated or cannot be resolved from the document text."
    ),
    "general_guidelines": (
        "- Do not infer or guess values; use null when missing/unclear.\\n"
        "- If there is condraction or ambiguity, return null for that field.\\n"
        "- Normalize first_name, middle_name, and last_name to uppercase.\\n"
        "- Normalize date_of_birth, death_date, incident_date, case_open_date, and case_close_date to YYYY-MM-DD.\\n"
        "- For ssn, insurance_claim_number, wcb_case_number, case_id, and ma_number, return digits only (strip spaces, dashes, and punctuation).\\n"
        "- case_id strict rule: extract only when the normalized value is exactly 6 or 7 digits. If it is shorter, longer, mixed with letters, or uncertain, return null for case_id.\\n"
        "- For ssn, keep whatever is explicitly present (full SSN, last 6, or last 4), but digits only.\\n"
    ),
    "fields": [
        {
            "name": "last_name",
            "type": "string",
            "description": "Patient/client last name. Return uppercase text only.",
        },
        {
            "name": "first_name",
            "type": "string",
            "description": "Patient/client first name. Return uppercase text only.",
        },
        {
            "name": "middle_name",
            "type": "string",
            "description": "Patient/client middle name or initial if present. Return uppercase text only.",
        },
        {
            "name": "ssn",
            "type": "string",
            "description": "Social Security Number if stated (full, last 6, or last 4). Return digits only.",
        },
        {
            "name": "case_id",
            "type": "string",
            "description": "Primary case identifier from labels like Case ID, Case #, HMS Case ID, or File #. STRICT: return case_id only if it is exactly 6 or 7 digits. If more than 7 digits, fewer than 6 digits, contains letters, or is ambiguous, return null.",
        },
        {
            "name": "ma_number",
            "type": "string",
            "description": "Medical Assistance/Medicaid identifier (often labeled MA Number, Medicaid ID, Recipient ID, or Billing Number). Prefer 10-digit value when available. Return digits only.",
        },
        {
            "name": "wcb_case_number",
            "type": "string",
            "description": "Workers' Compensation Board case number when the case is workers comp related (labels like WCB Case # or Board Case #). Return digits only.",
        },
        {
            "name": "insurance_claim_number",
            "type": "string",
            "description": "Insurance claim number from labels like Claim #, Claim Number, Carrier Claim No., or Insurer Claim Number. Return digits only; length may vary.",
        },
        {
            "name": "date_of_birth",
            "type": "string",
            "description": "Date of birth (DOB). Return in YYYY-MM-DD format.",
        },
        {
            "name": "death_date",
            "type": "string",
            "description": "Date of death (DOD), when decedent-related information is present. Return in YYYY-MM-DD format.",
        },
        {
            "name": "incident_date",
            "type": "string",
            "description": "Date of incident/loss/injury (DOI/DOL). Return in YYYY-MM-DD format.",
        },
        {
            "name": "case_open_date",
            "type": "string",
            "description": "Date the case/lien was opened or created (labels like Open Date, Date Opened, or Created Date). Return in YYYY-MM-DD format.",
        },
        {
            "name": "case_close_date",
            "type": "string",
            "description": "Date the case/lien was closed or resolved (labels like Close Date, Closed Date, or Resolution Date). Return in YYYY-MM-DD format. Keep sentinel dates such as 9999-12-31 when explicitly shown.",
        },
        {
            "name": "himp_id",
            "type": "string",
            "description": "HIMP identifier when explicitly labeled HIMP ID/HIMP #/Health Insurance ID. Return the identifier exactly as shown except trim surrounding whitespace.",
        },
    ],
}
